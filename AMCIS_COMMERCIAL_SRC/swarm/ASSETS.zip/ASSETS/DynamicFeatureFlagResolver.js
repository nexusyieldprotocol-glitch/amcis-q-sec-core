const resolveFeature = (user, flag) => {
    const hash = Array.from(user.id).reduce((s, c) => s + c.charCodeAt(0), 0);
    return (hash % 100) < flag.percentage;
};

// VALUATION: $50,000 - $85,000 USD
// DESCRIPTION: Deterministic stateless feature flag for bucketed experimentation.
