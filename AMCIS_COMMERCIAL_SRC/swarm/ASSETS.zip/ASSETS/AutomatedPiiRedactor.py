import re
def redact_sensitive_data(text):
    patterns = {
        r'\b[\w\.-]+@[\w\.-]+\.\w{2,}\b': '[EMAIL]',
        r'\b\d{3}-\d{2}-\d{4}\b': '[SSN]',
        r'\b(?:\d{4}-){3}\d{4}\b': '[CC]'
    }
    for p, r in patterns.items(): text = re.sub(p, r, text)
    return text

# VALUATION: $75,000 - $110,000 USD
# DESCRIPTION: PII redaction engine for GDPR/HIPAA compliance.
