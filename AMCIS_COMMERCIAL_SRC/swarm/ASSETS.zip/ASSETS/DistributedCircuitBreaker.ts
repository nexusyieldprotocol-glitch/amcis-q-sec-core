class CircuitBreaker {
    private failures = 0; private lastFailure = 0;
    constructor(private threshold = 5, private timeout = 30000) { }
    async execute(fn: Function) {
        if (this.failures >= this.threshold && Date.now() - this.lastFailure < this.timeout) throw new Error("OPEN");
        try { const res = await fn(); this.failures = 0; return res; }
        catch (e) { this.failures++; this.lastFailure = Date.now(); throw e; }
    }
}

// VALUATION: $95,000 - $140,000 USD
// DESCRIPTION: Fault-tolerant circuit breaker for microservice stability.
