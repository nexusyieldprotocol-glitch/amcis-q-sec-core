def safe_execute(db, query, params):
    return db.execute(query, params) if all(isinstance(p, (int, str, float)) for p in params) else None

# VALUATION: $40,000 - $70,000 USD
# DESCRIPTION: Sanitized query proxy for absolute SQL injection defense.
