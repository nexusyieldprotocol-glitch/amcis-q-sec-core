export const validateAIResponse = (schema: any, response: string) => {
    try {
        const data = JSON.parse(response);
        const isValid = Object.keys(schema).every(k => typeof data[k] === schema[k]);
        return isValid ? data : null;
    } catch { return null; }
};

// VALUATION: $55,000 - $80,000 USD
// DESCRIPTION: Deterministic schema enforcer for stochastic LLM outputs.
