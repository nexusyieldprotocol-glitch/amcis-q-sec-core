import { jwtVerify } from "jose";
export const authenticate = async (token: string, key: Uint8Array) => {
    try { return (await jwtVerify(token, key)).payload; }
    catch { return null; }
};

// VALUATION: $80,000 - $130,000 USD
// DESCRIPTION: Stateless edge-ready JWT identity validator.
