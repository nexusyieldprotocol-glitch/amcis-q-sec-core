import time, random
def retry_with_backoff(func, max_retries=5, base_delay=1):
    for i in range(max_retries):
        try: return func()
        except Exception as e:
            if i == max_retries - 1: raise e
            time.sleep(base_delay * (2 ** i) + random.uniform(0, 1))

# VALUATION: $45,000 - $65,000 USD
# DESCRIPTION: Resilient API retry with exponential backoff and jitter.
