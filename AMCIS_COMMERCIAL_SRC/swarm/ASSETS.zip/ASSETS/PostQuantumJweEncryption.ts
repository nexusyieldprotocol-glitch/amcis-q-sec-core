import { compactEncrypt } from "jose";
export const securePayload = async (data: string, secret: Uint8Array) => {
    return await new compactEncrypt(new TextEncoder().encode(data))
        .setProtectedHeader({ alg: "dir", enc: "A256GCM" })
        .encrypt(secret);
};

// VALUATION: $110,000 - $160,000 USD
// DESCRIPTION: Field-level AES-256-GCM encryption for PII residency compliance.
