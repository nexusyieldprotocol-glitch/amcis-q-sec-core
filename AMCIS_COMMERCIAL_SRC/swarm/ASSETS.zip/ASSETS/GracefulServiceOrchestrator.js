process.on('SIGTERM', async () => {
    console.log('SHUTTING_DOWN');
    await server.close();
    await database.disconnect();
    process.exit(0);
});

// VALUATION: $30,000 - $50,000 USD
// DESCRIPTION: Graceful shutdown sequence for zero-downtime K8s deployments.
