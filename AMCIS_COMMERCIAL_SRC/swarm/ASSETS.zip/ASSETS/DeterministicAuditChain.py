def create_deterministic_audit_chain(events):
    import hashlib, json
    chain = []
    for i, e in enumerate(events):
        prev_hash = chain[i-1]['hash'] if i > 0 else '0'*64
        h = hashlib.sha256(f"{prev_hash}{json.dumps(e, sort_keys=True)}".encode()).hexdigest()
        chain.append({'data': e, 'hash': h})
    return chain

# VALUATION: $120,000 - $185,000 USD
# DESCRIPTION: Cryptographically-linked deterministic audit log for non-repudiation.
