def acquire_distributed_lock(redis, key, timeout=10):
    import uuid
    val = str(uuid.uuid4())
    if redis.set(key, val, nx=True, px=timeout * 1000): return val
    return None

# VALUATION: $65,000 - $95,000 USD
# DESCRIPTION: Atomic distributed lock to prevent multi-server race conditions.
