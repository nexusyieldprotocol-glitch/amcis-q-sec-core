import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Trash2, Save, Play } from 'lucide-react';
import { toast } from 'sonner';

export default function AlertConfigForm({ configs }) {
  const queryClient = useQueryClient();
  const [editingConfig, setEditingConfig] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    metric_type: 'battery_voltage',
    threshold_operator: 'less_than',
    threshold_value: 0,
    severity: 'medium',
    notification_channels: ['in_app'],
    recipient_emails: [],
    enabled: true,
    cooldown_minutes: 60
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (editingConfig) {
        return base44.entities.AlertConfiguration.update(editingConfig.id, data);
      } else {
        return base44.entities.AlertConfiguration.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['alertConfigs']);
      toast.success(editingConfig ? 'Configuration updated' : 'Configuration created');
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AlertConfiguration.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['alertConfigs']);
      toast.success('Configuration deleted');
    }
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('monitorAlerts', {});
      return response.data;
    },
    onSuccess: (data) => {
      toast.success(`Alert scan complete: ${data.alerts_triggered || 0} alerts triggered`);
      queryClient.invalidateQueries(['alerts']);
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const resetForm = () => {
    setEditingConfig(null);
    setFormData({
      name: '',
      metric_type: 'battery_voltage',
      threshold_operator: 'less_than',
      threshold_value: 0,
      severity: 'medium',
      notification_channels: ['in_app'],
      recipient_emails: [],
      enabled: true,
      cooldown_minutes: 60
    });
  };

  const handleEdit = (config) => {
    setEditingConfig(config);
    setFormData({
      name: config.name,
      metric_type: config.metric_type,
      threshold_operator: config.threshold_operator,
      threshold_value: config.threshold_value,
      severity: config.severity,
      notification_channels: config.notification_channels || ['in_app'],
      recipient_emails: config.recipient_emails || [],
      enabled: config.enabled,
      cooldown_minutes: config.cooldown_minutes || 60
    });
  };

  const toggleChannel = (channel) => {
    setFormData(prev => ({
      ...prev,
      notification_channels: prev.notification_channels.includes(channel)
        ? prev.notification_channels.filter(c => c !== channel)
        : [...prev.notification_channels, channel]
    }));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Configuration Form */}
      <div className="lg:col-span-1">
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">
              {editingConfig ? 'Edit Configuration' : 'New Alert Configuration'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label className="text-slate-300">Alert Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="bg-slate-800 border-slate-700 mt-1"
                  placeholder="Low Battery Alert"
                />
              </div>

              <div>
                <Label className="text-slate-300">Metric</Label>
                <Select value={formData.metric_type} onValueChange={(v) => setFormData({ ...formData, metric_type: v })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="battery_voltage">Battery Voltage</SelectItem>
                    <SelectItem value="risk_score">Risk Score</SelectItem>
                    <SelectItem value="rul_days">RUL Days</SelectItem>
                    <SelectItem value="battery_impedance">Battery Impedance</SelectItem>
                    <SelectItem value="lead_impedance">Lead Impedance</SelectItem>
                    <SelectItem value="temperature">Temperature</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-slate-300">Operator</Label>
                  <Select value={formData.threshold_operator} onValueChange={(v) => setFormData({ ...formData, threshold_operator: v })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="less_than">Less Than</SelectItem>
                      <SelectItem value="greater_than">Greater Than</SelectItem>
                      <SelectItem value="equals">Equals</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-slate-300">Value</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.threshold_value}
                    onChange={(e) => setFormData({ ...formData, threshold_value: parseFloat(e.target.value) })}
                    required
                    className="bg-slate-800 border-slate-700 mt-1"
                  />
                </div>
              </div>

              <div>
                <Label className="text-slate-300">Severity</Label>
                <Select value={formData.severity} onValueChange={(v) => setFormData({ ...formData, severity: v })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300">Notification Channels</Label>
                <div className="flex gap-2 mt-2">
                  {['in_app', 'email'].map(channel => (
                    <button
                      key={channel}
                      type="button"
                      onClick={() => toggleChannel(channel)}
                      className={`px-3 py-1 rounded text-xs ${
                        formData.notification_channels.includes(channel)
                          ? 'bg-teal-600 text-white'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {channel}
                    </button>
                  ))}
                </div>
              </div>

              {formData.notification_channels.includes('email') && (
                <div>
                  <Label className="text-slate-300">Recipient Emails</Label>
                  <Input
                    value={formData.recipient_emails.join(', ')}
                    onChange={(e) => setFormData({ ...formData, recipient_emails: e.target.value.split(',').map(s => s.trim()) })}
                    className="bg-slate-800 border-slate-700 mt-1"
                    placeholder="email1@example.com, email2@example.com"
                  />
                </div>
              )}

              <div>
                <Label className="text-slate-300">Cooldown (minutes)</Label>
                <Input
                  type="number"
                  value={formData.cooldown_minutes}
                  onChange={(e) => setFormData({ ...formData, cooldown_minutes: parseInt(e.target.value) })}
                  className="bg-slate-800 border-slate-700 mt-1"
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-slate-300">Enabled</Label>
                <Switch
                  checked={formData.enabled}
                  onCheckedChange={(checked) => setFormData({ ...formData, enabled: checked })}
                />
              </div>

              <div className="flex gap-2">
                {editingConfig && (
                  <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                    Cancel
                  </Button>
                )}
                <Button type="submit" disabled={saveMutation.isPending} className="flex-1 bg-teal-600 hover:bg-teal-700">
                  <Save className="w-4 h-4 mr-2" />
                  {saveMutation.isPending ? 'Saving...' : editingConfig ? 'Update' : 'Create'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Configuration List */}
      <div className="lg:col-span-2">
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Alert Configurations ({configs.length})</CardTitle>
              <Button
                onClick={() => testMutation.mutate()}
                disabled={testMutation.isPending}
                size="sm"
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Play className="w-4 h-4 mr-2" />
                {testMutation.isPending ? 'Testing...' : 'Test All'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              {configs.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Plus className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No alert configurations yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {configs.map(config => (
                    <Card key={config.id} className="bg-slate-800/50 border-slate-700">
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <p className="text-sm font-medium text-white">{config.name}</p>
                              {!config.enabled && (
                                <Badge variant="outline" className="text-xs">Disabled</Badge>
                              )}
                            </div>
                            <p className="text-xs text-slate-400 mb-2">
                              {config.metric_type.replace(/_/g, ' ')} {config.threshold_operator.replace(/_/g, ' ')} {config.threshold_value}
                            </p>
                            <div className="flex gap-2">
                              <Badge className={getSeverityColor(config.severity)}>
                                {config.severity}
                              </Badge>
                              {config.notification_channels?.map(ch => (
                                <Badge key={ch} variant="outline" className="text-xs border-teal-700/50 text-teal-400">
                                  {ch}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(config)}
                              className="border-slate-700"
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteMutation.mutate(config.id)}
                              className="border-red-700 text-red-400 hover:bg-red-900/20"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function getSeverityColor(severity) {
  const colors = {
    low: 'bg-blue-900/30 text-blue-400',
    medium: 'bg-yellow-900/30 text-yellow-400',
    high: 'bg-orange-900/30 text-orange-400',
    critical: 'bg-red-900/30 text-red-400'
  };
  return colors[severity] || colors.medium;
}