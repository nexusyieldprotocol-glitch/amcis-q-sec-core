import React from 'react';
import RealtimeRegistryDashboard from '../components/registry/RealtimeRegistryDashboard';

export default function RegistryMonitoring() {
  return <RealtimeRegistryDashboard />;
}