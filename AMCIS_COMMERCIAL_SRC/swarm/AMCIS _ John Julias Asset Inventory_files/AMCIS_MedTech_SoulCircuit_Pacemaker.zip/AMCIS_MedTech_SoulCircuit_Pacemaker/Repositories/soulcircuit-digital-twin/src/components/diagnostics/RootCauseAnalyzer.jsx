import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Cpu, Sparkles, TrendingUp, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function RootCauseAnalyzer({ device, diagnostics }) {
  const queryClient = useQueryClient();
  const [selectedDiagnostic, setSelectedDiagnostic] = useState(null);

  const analyzeMutation = useMutation({
    mutationFn: async (diagnostic) => {
      // Prepare context for AI analysis
      const context = `
Device: ${device.device_id}
Manufacturer: ${device.manufacturer}
Model: ${device.model}
Status: ${device.status}
Implant Date: ${device.implant_date}

Error Event:
- Type: ${diagnostic.event_type}
- Code: ${diagnostic.error_code || 'N/A'}
- Description: ${diagnostic.description}
- Severity: ${diagnostic.severity}
- Timestamp: ${diagnostic.timestamp}

Sensor Data at Time of Event:
${JSON.stringify(diagnostic.sensor_data, null, 2)}

Recent Device History:
${diagnostics.slice(0, 5).map(d => `- ${d.event_type}: ${d.description}`).join('\n')}
      `.trim();

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert medical device diagnostics AI. Analyze the following pacemaker diagnostic event and provide:
1. Primary root cause
2. Contributing factors (list up to 3)
3. Confidence level (0-100%)
4. Specific recommendations (list up to 4 actionable items)

Context:
${context}

Provide your analysis in a structured format.`,
        response_json_schema: {
          type: 'object',
          properties: {
            primary_cause: { type: 'string' },
            contributing_factors: { type: 'array', items: { type: 'string' } },
            confidence: { type: 'number' },
            recommendations: { type: 'array', items: { type: 'string' } }
          }
        }
      });

      // Update diagnostic with AI analysis
      await base44.entities.DeviceDiagnostic.update(diagnostic.id, {
        root_cause_analysis: response
      });

      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['deviceDiagnostics']);
      toast.success('Root cause analysis complete');
    },
    onError: (error) => {
      toast.error('Analysis failed: ' + error.message);
    }
  });

  const unresolvedDiagnostics = diagnostics
    .filter(d => !d.resolved)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const handleAnalyze = (diagnostic) => {
    setSelectedDiagnostic(diagnostic);
    analyzeMutation.mutate(diagnostic);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Issue List */}
      <div className="lg:col-span-1">
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-sm text-white">Unresolved Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              {unresolvedDiagnostics.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <CheckCircle2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No unresolved issues</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {unresolvedDiagnostics.map((diagnostic) => (
                    <button
                      key={diagnostic.id}
                      onClick={() => setSelectedDiagnostic(diagnostic)}
                      className={`w-full text-left p-3 rounded-lg transition-all ${
                        selectedDiagnostic?.id === diagnostic.id
                          ? 'bg-teal-900/30 border-2 border-teal-600'
                          : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-1">
                        <p className="text-sm font-medium text-white line-clamp-2">
                          {diagnostic.description}
                        </p>
                        <Badge className={getSeverityColor(diagnostic.severity)}>
                          {diagnostic.severity}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-400">
                        {format(new Date(diagnostic.timestamp), 'MMM d, HH:mm')}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Analysis Panel */}
      <div className="lg:col-span-2">
        {selectedDiagnostic ? (
          <div className="space-y-4">
            {/* Issue Details */}
            <Card className="bg-slate-900/50 border-slate-700">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-white">{selectedDiagnostic.description}</CardTitle>
                  <Button
                    onClick={() => handleAnalyze(selectedDiagnostic)}
                    disabled={analyzeMutation.isPending}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    {analyzeMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        AI Analysis
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-slate-400 text-xs">Event Type</p>
                    <p className="text-white font-medium">{selectedDiagnostic.event_type}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs">Severity</p>
                    <Badge className={getSeverityColor(selectedDiagnostic.severity)}>
                      {selectedDiagnostic.severity}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs">Error Code</p>
                    <p className="text-white font-medium">{selectedDiagnostic.error_code || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs">Timestamp</p>
                    <p className="text-white font-medium">
                      {format(new Date(selectedDiagnostic.timestamp), 'MMM d, HH:mm:ss')}
                    </p>
                  </div>
                </div>

                {selectedDiagnostic.sensor_data && (
                  <div className="bg-slate-800/30 rounded-lg p-3">
                    <p className="text-xs text-slate-400 mb-2">Sensor Readings</p>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      {Object.entries(selectedDiagnostic.sensor_data).map(([key, value]) => (
                        <div key={key}>
                          <p className="text-slate-500">{key.replace(/_/g, ' ')}</p>
                          <p className="text-white font-medium">{value?.toFixed(2)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* AI Analysis Results */}
            {selectedDiagnostic.root_cause_analysis && (
              <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/10 border-purple-700/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-purple-400" />
                    AI Root Cause Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Confidence */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-300">Confidence Level</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-yellow-500 to-green-500"
                          style={{ width: `${selectedDiagnostic.root_cause_analysis.confidence}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium text-white">
                        {selectedDiagnostic.root_cause_analysis.confidence}%
                      </span>
                    </div>
                  </div>

                  {/* Primary Cause */}
                  <div>
                    <p className="text-xs text-purple-300 mb-2 flex items-center gap-2">
                      <TrendingUp className="w-3 h-3" />
                      Primary Root Cause
                    </p>
                    <p className="text-white bg-slate-800/50 p-3 rounded-lg">
                      {selectedDiagnostic.root_cause_analysis.primary_cause}
                    </p>
                  </div>

                  {/* Contributing Factors */}
                  {selectedDiagnostic.root_cause_analysis.contributing_factors?.length > 0 && (
                    <div>
                      <p className="text-xs text-purple-300 mb-2 flex items-center gap-2">
                        <AlertTriangle className="w-3 h-3" />
                        Contributing Factors
                      </p>
                      <ul className="space-y-2">
                        {selectedDiagnostic.root_cause_analysis.contributing_factors.map((factor, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-slate-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 mt-1.5 flex-shrink-0" />
                            {factor}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Recommendations */}
                  {selectedDiagnostic.root_cause_analysis.recommendations?.length > 0 && (
                    <div>
                      <p className="text-xs text-purple-300 mb-2 flex items-center gap-2">
                        <CheckCircle2 className="w-3 h-3" />
                        Recommendations
                      </p>
                      <ul className="space-y-2">
                        {selectedDiagnostic.root_cause_analysis.recommendations.map((rec, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-white bg-slate-800/50 p-2 rounded">
                            <span className="text-purple-400 font-bold">{idx + 1}.</span>
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <Card className="bg-slate-900/50 border-slate-700">
            <CardContent className="p-12 text-center text-slate-500">
              <Cpu className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Select an issue to analyze</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function getSeverityColor(severity) {
  const colors = {
    low: 'bg-blue-900/30 text-blue-400',
    medium: 'bg-yellow-900/30 text-yellow-400',
    high: 'bg-orange-900/30 text-orange-400',
    critical: 'bg-red-900/30 text-red-400'
  };
  return colors[severity] || colors.medium;
}