import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Edit, Activity, Database, Filter, X } from 'lucide-react';
import { format } from 'date-fns';

export default function DeviceList({ devices, snapshots, isLoading, onEditDevice }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [manufacturerFilter, setManufacturerFilter] = useState('all');
  const [cohortFilter, setCohortFilter] = useState('all');

  // Enrich devices with latest snapshot data
  const enrichedDevices = useMemo(() => {
    return devices.map(device => {
      const latestSnapshot = snapshots
        .filter(s => s.device_registry_id === device.id)
        .sort((a, b) => new Date(b.snapshot_date) - new Date(a.snapshot_date))[0];
      
      return {
        ...device,
        risk_score: latestSnapshot?.risk_score || 0,
        predicted_rul_days: latestSnapshot?.predicted_rul_days || 0,
        battery_voltage_v: latestSnapshot?.battery_voltage_v || 0
      };
    });
  }, [devices, snapshots]);

  // Apply filters
  const filteredDevices = useMemo(() => {
    return enrichedDevices.filter(device => {
      const matchesSearch = !searchTerm || 
        device.device_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        device.patient_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        device.model?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || device.status === statusFilter;
      const matchesManufacturer = manufacturerFilter === 'all' || device.manufacturer === manufacturerFilter;
      const matchesCohort = cohortFilter === 'all' || device.cohort_name === cohortFilter;

      return matchesSearch && matchesStatus && matchesManufacturer && matchesCohort;
    });
  }, [enrichedDevices, searchTerm, statusFilter, manufacturerFilter, cohortFilter]);

  const manufacturers = [...new Set(devices.map(d => d.manufacturer).filter(Boolean))];
  const cohorts = [...new Set(devices.map(d => d.cohort_name).filter(Boolean))];

  const hasActiveFilters = statusFilter !== 'all' || manufacturerFilter !== 'all' || cohortFilter !== 'all' || searchTerm;

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setManufacturerFilter('all');
    setCohortFilter('all');
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <span className="text-sm font-medium text-white">Filters</span>
              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="ml-auto text-xs text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3 mr-1" />
                  Clear
                </Button>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search devices..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 bg-slate-800 border-slate-700"
                />
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="eri">ERI</SelectItem>
                  <SelectItem value="eol">EOL</SelectItem>
                  <SelectItem value="explanted">Explanted</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="monitoring">Monitoring</SelectItem>
                </SelectContent>
              </Select>

              <Select value={manufacturerFilter} onValueChange={setManufacturerFilter}>
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue placeholder="Manufacturer" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Manufacturers</SelectItem>
                  {manufacturers.map(mfr => (
                    <SelectItem key={mfr} value={mfr}>{mfr}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={cohortFilter} onValueChange={setCohortFilter}>
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue placeholder="Cohort" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cohorts</SelectItem>
                  {cohorts.map(cohort => (
                    <SelectItem key={cohort} value={cohort}>{cohort}</SelectItem>
                  ))}
                  {cohorts.length === 0 && (
                    <SelectItem value="none" disabled>No cohorts defined</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="text-xs text-slate-400">
              Showing {filteredDevices.length} of {devices.length} devices
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Device List */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Device Registry</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            {isLoading ? (
              <div className="text-center py-12 text-slate-500">
                <Activity className="w-8 h-8 mx-auto mb-2 animate-pulse" />
                Loading devices...
              </div>
            ) : filteredDevices.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <Database className="w-8 h-8 mx-auto mb-2 opacity-50" />
                No devices found
              </div>
            ) : (
              <div className="space-y-3">
                {filteredDevices.map(device => (
                  <DeviceCard
                    key={device.id}
                    device={device}
                    onEdit={onEditDevice}
                  />
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

function DeviceCard({ device, onEdit }) {
  const statusColors = {
    active: 'bg-green-900/30 text-green-400 border-green-700',
    eri: 'bg-yellow-900/30 text-yellow-400 border-yellow-700',
    eol: 'bg-orange-900/30 text-orange-400 border-orange-700',
    explanted: 'bg-slate-800/50 text-slate-400 border-slate-700',
    maintenance: 'bg-blue-900/30 text-blue-400 border-blue-700',
    monitoring: 'bg-purple-900/30 text-purple-400 border-purple-700'
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700 hover:border-teal-700 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-semibold text-white">{device.device_id}</h4>
              <Badge className={statusColors[device.status] || statusColors.active}>
                {device.status}
              </Badge>
            </div>
            <p className="text-sm text-slate-400">{device.manufacturer} - {device.model}</p>
            <p className="text-xs text-slate-500">Patient: {device.patient_id || 'Unassigned'}</p>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onEdit(device)}
            className="border-slate-700 hover:border-teal-700"
          >
            <Edit className="w-3 h-3 mr-1" />
            Edit
          </Button>
        </div>

        <div className="grid grid-cols-4 gap-3 text-xs mb-3">
          <div>
            <p className="text-slate-500">Implanted</p>
            <p className="text-white font-medium">
              {device.implant_date ? format(new Date(device.implant_date), 'MMM yyyy') : 'N/A'}
            </p>
          </div>
          <div>
            <p className="text-slate-500">Risk Score</p>
            <p className="text-white font-medium">{device.risk_score || 0}%</p>
          </div>
          <div>
            <p className="text-slate-500">RUL</p>
            <p className="text-white font-medium">{device.predicted_rul_days || 0}d</p>
          </div>
          <div>
            <p className="text-slate-500">Voltage</p>
            <p className="text-white font-medium">{device.battery_voltage_v?.toFixed(2) || 'N/A'}V</p>
          </div>
        </div>

        {(device.cohort_name || device.clinical_study_id) && (
          <div className="flex gap-2 flex-wrap">
            {device.cohort_name && (
              <Badge variant="outline" className="text-xs border-purple-700/50 text-purple-400">
                Cohort: {device.cohort_name}
              </Badge>
            )}
            {device.clinical_study_id && (
              <Badge variant="outline" className="text-xs border-blue-700/50 text-blue-400">
                Study: {device.clinical_study_id}
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}