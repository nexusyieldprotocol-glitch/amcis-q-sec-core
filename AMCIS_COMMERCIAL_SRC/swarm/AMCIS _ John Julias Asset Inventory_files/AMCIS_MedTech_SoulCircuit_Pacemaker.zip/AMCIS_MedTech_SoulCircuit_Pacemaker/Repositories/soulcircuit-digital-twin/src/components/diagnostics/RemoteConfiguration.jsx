import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, Send, RotateCcw, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export default function RemoteConfiguration({ device }) {
  const queryClient = useQueryClient();
  const [config, setConfig] = useState({
    pacing_mode: device.pacing_mode || 'DDD',
    pacing_rate_bpm: 70,
    pulse_amplitude_v: 2.5,
    pulse_width_ms: 0.4,
    lower_rate_limit: 60,
    upper_rate_limit: 130,
    energy_harvesting_enabled: device.energy_harvesting_enabled || false
  });

  const [lastUpdate, setLastUpdate] = useState(null);

  const updateMutation = useMutation({
    mutationFn: async (newConfig) => {
      // Update device registry
      await base44.entities.DeviceRegistry.update(device.id, {
        pacing_mode: newConfig.pacing_mode,
        energy_harvesting_enabled: newConfig.energy_harvesting_enabled
      });

      // Log configuration change as diagnostic event
      await base44.entities.DeviceDiagnostic.create({
        device_registry_id: device.id,
        timestamp: new Date().toISOString(),
        event_type: 'info',
        severity: 'low',
        description: `Remote configuration updated: ${JSON.stringify(newConfig)}`,
        resolved: true
      });

      return newConfig;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries(['deviceRegistry']);
      queryClient.invalidateQueries(['deviceDiagnostics']);
      setLastUpdate(new Date());
      toast.success('Configuration updated successfully');
    },
    onError: (error) => {
      toast.error('Configuration update failed: ' + error.message);
    }
  });

  const handleApplyConfig = () => {
    updateMutation.mutate(config);
  };

  const handleReset = () => {
    setConfig({
      pacing_mode: device.pacing_mode || 'DDD',
      pacing_rate_bpm: 70,
      pulse_amplitude_v: 2.5,
      pulse_width_ms: 0.4,
      lower_rate_limit: 60,
      upper_rate_limit: 130,
      energy_harvesting_enabled: device.energy_harvesting_enabled || false
    });
  };

  return (
    <div className="space-y-4">
      {/* Warning Banner */}
      <Alert className="bg-orange-900/20 border-orange-700/50">
        <AlertTriangle className="w-4 h-4 text-orange-400" />
        <AlertDescription className="text-orange-200">
          <strong>Remote Configuration:</strong> Changes will be transmitted to the device.
          Ensure clinical authorization before applying changes.
        </AlertDescription>
      </Alert>

      {lastUpdate && (
        <Alert className="bg-green-900/20 border-green-700/50">
          <CheckCircle2 className="w-4 h-4 text-green-400" />
          <AlertDescription className="text-green-200">
            Configuration successfully updated at {lastUpdate.toLocaleTimeString()}
          </AlertDescription>
        </Alert>
      )}

      {/* Configuration Form */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-teal-400" />
            Device Parameters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Pacing Mode */}
          <div>
            <Label className="text-slate-300">Pacing Mode</Label>
            <Select
              value={config.pacing_mode}
              onValueChange={(value) => setConfig({ ...config, pacing_mode: value })}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700 mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="VVI">VVI - Single Chamber Ventricular</SelectItem>
                <SelectItem value="VVIR">VVIR - Rate Responsive Ventricular</SelectItem>
                <SelectItem value="DDD">DDD - Dual Chamber</SelectItem>
                <SelectItem value="DDDR">DDDR - Rate Responsive Dual</SelectItem>
                <SelectItem value="AAI">AAI - Single Chamber Atrial</SelectItem>
                <SelectItem value="CRT">CRT - Cardiac Resynchronization</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Pacing Rate */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-slate-300">Base Pacing Rate</Label>
              <span className="text-sm text-white font-medium">{config.pacing_rate_bpm} bpm</span>
            </div>
            <Slider
              value={[config.pacing_rate_bpm]}
              onValueChange={([value]) => setConfig({ ...config, pacing_rate_bpm: value })}
              min={40}
              max={100}
              step={5}
              className="mt-2"
            />
          </div>

          {/* Rate Limits */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Lower Rate Limit</Label>
              <Input
                type="number"
                value={config.lower_rate_limit}
                onChange={(e) => setConfig({ ...config, lower_rate_limit: parseInt(e.target.value) })}
                className="bg-slate-800 border-slate-700 mt-2"
                min="40"
                max="100"
              />
            </div>
            <div>
              <Label className="text-slate-300">Upper Rate Limit</Label>
              <Input
                type="number"
                value={config.upper_rate_limit}
                onChange={(e) => setConfig({ ...config, upper_rate_limit: parseInt(e.target.value) })}
                className="bg-slate-800 border-slate-700 mt-2"
                min="100"
                max="180"
              />
            </div>
          </div>

          {/* Pulse Parameters */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-slate-300">Pulse Amplitude</Label>
              <span className="text-sm text-white font-medium">{config.pulse_amplitude_v} V</span>
            </div>
            <Slider
              value={[config.pulse_amplitude_v]}
              onValueChange={([value]) => setConfig({ ...config, pulse_amplitude_v: value })}
              min={1.0}
              max={5.0}
              step={0.1}
              className="mt-2"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-slate-300">Pulse Width</Label>
              <span className="text-sm text-white font-medium">{config.pulse_width_ms} ms</span>
            </div>
            <Slider
              value={[config.pulse_width_ms]}
              onValueChange={([value]) => setConfig({ ...config, pulse_width_ms: value })}
              min={0.1}
              max={1.5}
              step={0.05}
              className="mt-2"
            />
          </div>

          {/* Energy Harvesting */}
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-slate-300">Energy Harvesting</Label>
              <p className="text-xs text-slate-500 mt-1">Enable kinetic/thermal energy recovery</p>
            </div>
            <Switch
              checked={config.energy_harvesting_enabled}
              onCheckedChange={(checked) => setConfig({ ...config, energy_harvesting_enabled: checked })}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={handleReset}
              className="flex-1 border-slate-700"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
            <Button
              onClick={handleApplyConfig}
              disabled={updateMutation.isPending}
              className="flex-1 bg-teal-600 hover:bg-teal-700"
            >
              <Send className="w-4 h-4 mr-2" />
              {updateMutation.isPending ? 'Applying...' : 'Apply Configuration'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Current Device Info */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm text-white">Current Device Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div>
              <p className="text-slate-400">Model</p>
              <p className="text-white font-medium">{device.model}</p>
            </div>
            <div>
              <p className="text-slate-400">Status</p>
              <p className="text-white font-medium">{device.status}</p>
            </div>
            <div>
              <p className="text-slate-400">Battery</p>
              <p className="text-white font-medium">{device.battery_chemistry}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}