import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { FileText, Download, Printer, Copy, AlertTriangle, TrendingUp, Battery, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function RiskReportGenerator({ patient, isOpen, onClose }) {
  const [generating, setGenerating] = useState(false);

  if (!patient) return null;

  const riskColor = patient.risk_score >= 80 ? 'text-red-400' :
                    patient.risk_score >= 60 ? 'text-orange-400' :
                    patient.risk_score >= 40 ? 'text-yellow-400' : 'text-green-400';

  const handleGeneratePDF = async () => {
    setGenerating(true);
    // Simulate PDF generation
    await new Promise(resolve => setTimeout(resolve, 1500));
    toast.success('Risk report generated');
    setGenerating(false);
  };

  const handleCopyReport = () => {
    const reportText = `
PATIENT RISK ASSESSMENT REPORT
Generated: ${format(new Date(), 'PPpp')}

Patient ID: ${patient.patient_id}
Device ID: ${patient.device_id}
Manufacturer: ${patient.manufacturer}
Model: ${patient.model}

RISK ASSESSMENT:
Overall Risk Score: ${patient.risk_score}/100
Risk Level: ${getRiskLevel(patient.risk_score)}
Predicted RUL: ${patient.predicted_rul_days} days

DEVICE STATUS:
Current Status: ${patient.status}
Battery Voltage: ${patient.battery_voltage_v}V
Lead Impedance: ${patient.lead_impedance_ohms}Ω
Pacing Burden: ${patient.cumulative_pacing_burden_percent}%

RECOMMENDATIONS:
${getRecommendations(patient)}
    `.trim();

    navigator.clipboard.writeText(reportText);
    toast.success('Report copied to clipboard');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-400" />
            Patient Risk Report
          </DialogTitle>
          <DialogDescription>
            Comprehensive risk assessment and clinical recommendations
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)] space-y-4">
          {/* Patient Header */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-slate-400 mb-1">Patient ID</p>
                  <p className="text-white font-medium">{patient.patient_id}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Device ID</p>
                  <p className="text-white font-medium">{patient.device_id}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Manufacturer</p>
                  <p className="text-white font-medium">{patient.manufacturer}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-1">Model</p>
                  <p className="text-white font-medium">{patient.model}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Assessment */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-400" />
                Risk Assessment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Overall Risk Score</span>
                <div className="flex items-center gap-2">
                  <span className={`text-2xl font-bold ${riskColor}`}>{patient.risk_score}</span>
                  <span className="text-slate-500">/100</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Risk Classification</span>
                <Badge className={`${getRiskBadgeClass(patient.risk_score)}`}>
                  {getRiskLevel(patient.risk_score)}
                </Badge>
              </div>
              <Separator className="bg-slate-700" />
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-sm">Predicted RUL</span>
                <span className="text-white font-medium">{patient.predicted_rul_days} days</span>
              </div>
            </CardContent>
          </Card>

          {/* Device Metrics */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <Battery className="w-4 h-4 text-teal-400" />
                Device Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-slate-400">Battery Voltage</p>
                  <p className="text-white font-medium">{patient.battery_voltage_v}V</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Lead Impedance</p>
                  <p className="text-white font-medium">{patient.lead_impedance_ohms}Ω</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Pacing Threshold</p>
                  <p className="text-white font-medium">{patient.pacing_threshold_v}V</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Pacing Burden</p>
                  <p className="text-white font-medium">{patient.cumulative_pacing_burden_percent}%</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Current Status</p>
                  <Badge variant="outline" className="border-slate-600 text-slate-300">
                    {patient.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Days Since Implant</p>
                  <p className="text-white font-medium">{patient.days_since_implant}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Clinical Recommendations */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                Clinical Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm text-slate-300">
                {getRecommendations(patient).split('\n').map((rec, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="text-teal-400 mt-1">•</span>
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Timestamp */}
          <div className="text-xs text-slate-500 text-center">
            Report generated: {format(new Date(), 'PPpp')}
          </div>
        </div>

        <DialogFooter className="border-t border-slate-700 pt-4">
          <div className="flex gap-2 w-full">
            <Button
              variant="outline"
              onClick={handleCopyReport}
              className="flex-1 border-slate-700"
            >
              <Copy className="w-3 h-3 mr-1" />
              Copy
            </Button>
            <Button
              variant="outline"
              onClick={() => window.print()}
              className="flex-1 border-slate-700"
            >
              <Printer className="w-3 h-3 mr-1" />
              Print
            </Button>
            <Button
              onClick={handleGeneratePDF}
              disabled={generating}
              className="flex-1 bg-teal-600 hover:bg-teal-700"
            >
              <Download className="w-3 h-3 mr-1" />
              {generating ? 'Generating...' : 'Download PDF'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function getRiskLevel(score) {
  if (score >= 80) return 'Critical';
  if (score >= 60) return 'High';
  if (score >= 40) return 'Moderate';
  return 'Low';
}

function getRiskBadgeClass(score) {
  if (score >= 80) return 'bg-red-900/30 text-red-400 border-red-700/50';
  if (score >= 60) return 'bg-orange-900/30 text-orange-400 border-orange-700/50';
  if (score >= 40) return 'bg-yellow-900/30 text-yellow-400 border-yellow-700/50';
  return 'bg-green-900/30 text-green-400 border-green-700/50';
}

function getRecommendations(patient) {
  const recommendations = [];
  
  if (patient.risk_score >= 80) {
    recommendations.push('URGENT: Schedule immediate device evaluation');
    recommendations.push('Consider expedited replacement consultation');
  } else if (patient.risk_score >= 60) {
    recommendations.push('Schedule follow-up within 2 weeks');
    recommendations.push('Monitor battery voltage trends closely');
  } else if (patient.risk_score >= 40) {
    recommendations.push('Schedule routine follow-up within 30 days');
  } else {
    recommendations.push('Continue standard monitoring protocol');
  }

  if (patient.predicted_rul_days < 90) {
    recommendations.push('Device nearing EOL - schedule replacement discussion');
  } else if (patient.predicted_rul_days < 180) {
    recommendations.push('Begin replacement planning in next 3-6 months');
  }

  if (patient.lead_impedance_ohms > 1500) {
    recommendations.push('Elevated lead impedance - check for lead integrity issues');
  }

  if (patient.pacing_threshold_v > 2.0) {
    recommendations.push('High pacing threshold - consider lead repositioning evaluation');
  }

  return recommendations.join('\n');
}