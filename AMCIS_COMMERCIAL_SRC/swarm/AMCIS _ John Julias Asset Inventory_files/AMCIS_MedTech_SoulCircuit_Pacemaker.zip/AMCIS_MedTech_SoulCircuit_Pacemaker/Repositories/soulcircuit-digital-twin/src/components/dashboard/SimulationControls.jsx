import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Settings, 
  Activity,
  Heart,
  Zap,
  AlertTriangle
} from 'lucide-react';
import { FAILURE_MODES } from '../simulation/SimulationEngine';

export default function SimulationControls({ 
  config, 
  onConfigChange, 
  onRun, 
  onPause, 
  onReset,
  isRunning,
  prototype
}) {
  const handleSliderChange = (key, value) => {
    onConfigChange({ ...config, [key]: value[0] });
  };

  const handleSelectChange = (key, value) => {
    onConfigChange({ ...config, [key]: value });
  };

  const handleFailureModeToggle = (mode) => {
    const current = config.failureModes || [];
    const updated = current.includes(mode)
      ? current.filter(m => m !== mode)
      : [...current, mode];
    onConfigChange({ ...config, failureModes: updated });
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
          <Settings className="w-4 h-4 text-slate-400" />
          Simulation Parameters
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Pacing Configuration */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium uppercase tracking-wide">
            <Heart className="w-3 h-3" />
            Pacing Configuration
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <Label className="text-slate-400">Pacing Rate</Label>
              <span className="text-teal-400 font-medium">{config.pacingRate} BPM</span>
            </div>
            <Slider
              value={[config.pacingRate]}
              onValueChange={(v) => handleSliderChange('pacingRate', v)}
              min={40}
              max={180}
              step={5}
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <Label className="text-slate-400">Pacing Percentage</Label>
              <span className="text-teal-400 font-medium">{config.pacingPercentage}%</span>
            </div>
            <Slider
              value={[config.pacingPercentage]}
              onValueChange={(v) => handleSliderChange('pacingPercentage', v)}
              min={0}
              max={100}
              step={5}
              className="w-full"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <Label className="text-slate-400">Amplitude</Label>
                <span className="text-teal-400 font-medium">{config.pulseAmplitude}V</span>
              </div>
              <Slider
                value={[config.pulseAmplitude]}
                onValueChange={(v) => handleSliderChange('pulseAmplitude', v)}
                min={0.5}
                max={5.0}
                step={0.1}
                className="w-full"
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <Label className="text-slate-400">Pulse Width</Label>
                <span className="text-teal-400 font-medium">{config.pulseWidth}ms</span>
              </div>
              <Slider
                value={[config.pulseWidth]}
                onValueChange={(v) => handleSliderChange('pulseWidth', v)}
                min={0.1}
                max={1.5}
                step={0.05}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Patient & Environment */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium uppercase tracking-wide">
            <Activity className="w-3 h-3" />
            Patient Model
          </div>

          <div className="space-y-2">
            <Label className="text-xs text-slate-400">Activity Level</Label>
            <Select 
              value={config.activityLevel} 
              onValueChange={(v) => handleSelectChange('activityLevel', v)}
            >
              <SelectTrigger className="bg-slate-800/50 border-slate-700 text-slate-200 text-xs h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="sedentary" className="text-xs">Sedentary</SelectItem>
                <SelectItem value="moderate" className="text-xs">Moderate</SelectItem>
                <SelectItem value="active" className="text-xs">Active</SelectItem>
                <SelectItem value="athletic" className="text-xs">Athletic</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <Label className="text-slate-400">Simulation Duration</Label>
              <span className="text-teal-400 font-medium">{config.durationYears} years</span>
            </div>
            <Slider
              value={[config.durationYears]}
              onValueChange={(v) => handleSliderChange('durationYears', v)}
              min={1}
              max={25}
              step={1}
              className="w-full"
            />
          </div>
        </div>

        {/* Failure Modes */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium uppercase tracking-wide">
            <AlertTriangle className="w-3 h-3" />
            Failure Mode Simulation
          </div>
          <div className="flex flex-wrap gap-2">
            {Object.entries(FAILURE_MODES).map(([key, mode]) => (
              <Badge
                key={key}
                variant="outline"
                className={`cursor-pointer text-[10px] transition-colors ${
                  config.failureModes?.includes(key)
                    ? mode.severity === 'critical' 
                      ? 'bg-red-500/20 border-red-500/50 text-red-400'
                      : mode.severity === 'moderate'
                        ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400'
                        : 'bg-blue-500/20 border-blue-500/50 text-blue-400'
                    : 'bg-slate-800/50 border-slate-600/30 text-slate-500'
                }`}
                onClick={() => handleFailureModeToggle(key)}
              >
                {mode.name}
              </Badge>
            ))}
          </div>
        </div>

        {/* Control Buttons */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={onRun}
            disabled={isRunning || !prototype}
            className="flex-1 bg-teal-600 hover:bg-teal-500 text-white text-xs h-9"
          >
            <Play className="w-3 h-3 mr-1.5" />
            {isRunning ? 'Running...' : 'Run Simulation'}
          </Button>
          <Button
            onClick={onReset}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-800 text-xs h-9"
          >
            <RotateCcw className="w-3 h-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}