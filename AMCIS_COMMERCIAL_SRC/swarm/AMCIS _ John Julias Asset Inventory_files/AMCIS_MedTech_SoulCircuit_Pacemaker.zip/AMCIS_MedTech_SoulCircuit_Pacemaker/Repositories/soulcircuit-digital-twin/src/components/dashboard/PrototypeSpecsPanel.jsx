import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Cpu, 
  Battery, 
  Zap, 
  Thermometer, 
  Radio, 
  Clock, 
  Box,
  Weight,
  Shield,
  Heart
} from 'lucide-react';

export default function PrototypeSpecsPanel({ prototype }) {
  if (!prototype) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardContent className="flex items-center justify-center h-64">
          <p className="text-slate-500 text-sm">Select a prototype to view specifications</p>
        </CardContent>
      </Card>
    );
  }

  const specs = [
    { 
      label: 'Battery Chemistry', 
      value: prototype.battery_chemistry,
      icon: Battery,
      color: 'text-teal-400'
    },
    { 
      label: 'Energy Capacity', 
      value: `${prototype.energy_capacity_mah} mAh`,
      icon: Zap,
      color: 'text-yellow-400'
    },
    { 
      label: 'Nominal Voltage', 
      value: `${prototype.nominal_voltage}V`,
      icon: Zap,
      color: 'text-orange-400'
    },
    { 
      label: 'Internal Resistance', 
      value: `${prototype.internal_resistance_ohms}Ω`,
      icon: Radio,
      color: 'text-purple-400'
    },
    { 
      label: 'Volume', 
      value: `${prototype.volume_cc} cc`,
      icon: Box,
      color: 'text-blue-400'
    },
    { 
      label: 'Weight', 
      value: `${prototype.weight_grams}g`,
      icon: Weight,
      color: 'text-pink-400'
    },
    { 
      label: 'Expected Lifetime', 
      value: `${prototype.expected_lifetime_years} years`,
      icon: Clock,
      color: 'text-green-400'
    },
    { 
      label: 'Thermal Dissipation', 
      value: `${prototype.thermal_dissipation_mw} mW`,
      icon: Thermometer,
      color: 'text-red-400'
    }
  ];

  const formatDimensions = (dims) => {
    if (!dims) return 'N/A';
    if (dims.length && dims.diameter) return `${dims.length}×Ø${dims.diameter} mm`;
    if (dims.length && dims.width && dims.thickness) return `${dims.length}×${dims.width}×${dims.thickness} mm`;
    return JSON.stringify(dims);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Cpu className="w-4 h-4 text-slate-400" />
            Device Specifications
          </CardTitle>
          <div 
            className="w-3 h-3 rounded-full" 
            style={{ backgroundColor: prototype.color || '#6B7280' }}
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Header Info */}
        <div className="p-3 rounded-lg bg-slate-800/50">
          <h3 className="font-semibold text-slate-100">{prototype.name}</h3>
          <p className="text-xs text-slate-500">{prototype.manufacturer}</p>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline" className="text-[10px] border-slate-600 text-slate-400">
              {prototype.model_type}
            </Badge>
            <Badge 
              variant="outline" 
              className={`text-[10px] ${
                prototype.status === 'approved' ? 'border-green-500/50 text-green-400' :
                prototype.status === 'prototype' ? 'border-purple-500/50 text-purple-400' :
                prototype.status === 'concept' ? 'border-blue-500/50 text-blue-400' :
                'border-slate-600 text-slate-400'
              }`}
            >
              {prototype.status?.replace('_', ' ')}
            </Badge>
          </div>
        </div>

        {/* Dimensions */}
        <div className="p-3 rounded-lg bg-slate-800/30">
          <p className="text-xs text-slate-500 mb-1">Dimensions</p>
          <p className="text-sm text-slate-200 font-medium">{formatDimensions(prototype.dimensions_mm)}</p>
        </div>

        {/* Specs Grid */}
        <div className="grid grid-cols-2 gap-2">
          {specs.map((spec, idx) => (
            <div key={idx} className="p-2 rounded-lg bg-slate-800/30">
              <div className="flex items-center gap-1.5 mb-1">
                <spec.icon className={`w-3 h-3 ${spec.color}`} />
                <p className="text-[10px] text-slate-500">{spec.label}</p>
              </div>
              <p className="text-xs text-slate-200 font-medium">{spec.value}</p>
            </div>
          ))}
        </div>

        <Separator className="bg-slate-700/50" />

        {/* Features */}
        <div className="space-y-3">
          <p className="text-xs text-slate-400 font-medium">Features & Capabilities</p>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded bg-slate-800/30">
              <span className="text-slate-500">Energy Harvesting</span>
              <Badge variant="outline" className={`text-[10px] ${prototype.energy_harvesting_enabled ? 'border-green-500/50 text-green-400' : 'border-slate-600 text-slate-500'}`}>
                {prototype.energy_harvesting_enabled ? prototype.harvesting_type : 'None'}
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-800/30">
              <span className="text-slate-500">Supercapacitor</span>
              <Badge variant="outline" className={`text-[10px] ${prototype.supercapacitor_enabled ? 'border-green-500/50 text-green-400' : 'border-slate-600 text-slate-500'}`}>
                {prototype.supercapacitor_enabled ? `${prototype.supercap_capacitance_f}F` : 'None'}
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-800/30">
              <span className="text-slate-500">Rechargeable</span>
              <Badge variant="outline" className={`text-[10px] ${prototype.rechargeable ? 'border-green-500/50 text-green-400' : 'border-slate-600 text-slate-500'}`}>
                {prototype.rechargeable ? 'Yes' : 'No'}
              </Badge>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-800/30">
              <span className="text-slate-500">MRI Conditional</span>
              <Badge variant="outline" className={`text-[10px] ${prototype.mri_conditional ? 'border-green-500/50 text-green-400' : 'border-red-500/50 text-red-400'}`}>
                {prototype.mri_conditional ? 'Yes' : 'No'}
              </Badge>
            </div>
          </div>

          {/* Pacing Modes */}
          {prototype.pacing_modes && (
            <div className="p-2 rounded bg-slate-800/30">
              <div className="flex items-center gap-1.5 mb-2">
                <Heart className="w-3 h-3 text-red-400" />
                <span className="text-[10px] text-slate-500">Pacing Modes</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {prototype.pacing_modes.map((mode, idx) => (
                  <Badge key={idx} variant="outline" className="text-[10px] border-slate-600 text-slate-300">
                    {mode}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Notes */}
        {prototype.notes && (
          <>
            <Separator className="bg-slate-700/50" />
            <div className="p-2 rounded bg-slate-800/30">
              <p className="text-[10px] text-slate-500 mb-1">Notes</p>
              <p className="text-xs text-slate-400">{prototype.notes}</p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}