import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, Search, AlertTriangle, Cpu } from 'lucide-react';

import DiagnosticDashboard from '../components/diagnostics/DiagnosticDashboard';
import RootCauseAnalyzer from '../components/diagnostics/RootCauseAnalyzer';
import RemoteConfiguration from '../components/diagnostics/RemoteConfiguration';

export default function DeviceDiagnostics() {
  const [selectedDeviceId, setSelectedDeviceId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const { data: devices = [] } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list('-updated_date', 200)
  });

  const { data: diagnostics = [] } = useQuery({
    queryKey: ['deviceDiagnostics'],
    queryFn: () => base44.entities.DeviceDiagnostic.list('-timestamp', 500)
  });

  const filteredDevices = devices.filter(d => 
    !searchTerm || 
    d.device_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.patient_id?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedDevice = devices.find(d => d.id === selectedDeviceId);
  const deviceDiagnostics = diagnostics.filter(d => d.device_registry_id === selectedDeviceId);

  const criticalCount = diagnostics.filter(d => d.severity === 'critical' && !d.resolved).length;
  const unresolvedCount = diagnostics.filter(d => !d.resolved).length;

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Cpu className="w-8 h-8 text-teal-400" />
              Device Diagnostics & Analysis
            </h1>
            <p className="text-slate-400 mt-1">
              AI-powered diagnostics and remote troubleshooting
            </p>
          </div>
          <div className="flex gap-4 text-sm">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">{criticalCount}</p>
              <p className="text-xs text-slate-500">Critical</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-400">{unresolvedCount}</p>
              <p className="text-xs text-slate-500">Unresolved</p>
            </div>
          </div>
        </div>

        {/* Device Selector */}
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white">Select Device</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search by device ID or patient ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 bg-slate-800 border-slate-700"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 max-h-32 overflow-y-auto">
              {filteredDevices.map(device => {
                const deviceIssues = diagnostics.filter(d => 
                  d.device_registry_id === device.id && !d.resolved
                ).length;
                return (
                  <button
                    key={device.id}
                    onClick={() => setSelectedDeviceId(device.id)}
                    className={`p-2 rounded-lg text-left transition-all ${
                      selectedDeviceId === device.id
                        ? 'bg-teal-900/30 border-2 border-teal-600'
                        : 'bg-slate-800/50 border border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <p className="text-sm font-medium text-white truncate">{device.device_id}</p>
                    <div className="flex items-center justify-between mt-1">
                      <p className="text-xs text-slate-400">{device.status}</p>
                      {deviceIssues > 0 && (
                        <span className="text-xs px-1.5 py-0.5 bg-red-900/30 text-red-400 rounded">
                          {deviceIssues}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        {selectedDevice ? (
          <Tabs defaultValue="dashboard" className="space-y-4">
            <TabsList className="bg-slate-900 border border-slate-700">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-teal-900/30">
                <Activity className="w-4 h-4 mr-2" />
                Real-time Dashboard
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:bg-teal-900/30">
                <Cpu className="w-4 h-4 mr-2" />
                AI Root Cause Analysis
              </TabsTrigger>
              <TabsTrigger value="config" className="data-[state=active]:bg-teal-900/30">
                <AlertTriangle className="w-4 h-4 mr-2" />
                Remote Configuration
              </TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard">
              <DiagnosticDashboard
                device={selectedDevice}
                diagnostics={deviceDiagnostics}
              />
            </TabsContent>

            <TabsContent value="analysis">
              <RootCauseAnalyzer
                device={selectedDevice}
                diagnostics={deviceDiagnostics}
              />
            </TabsContent>

            <TabsContent value="config">
              <RemoteConfiguration
                device={selectedDevice}
              />
            </TabsContent>
          </Tabs>
        ) : (
          <Card className="bg-slate-900/50 border-slate-700">
            <CardContent className="p-12 text-center text-slate-500">
              <Cpu className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Select a device to view diagnostics</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}