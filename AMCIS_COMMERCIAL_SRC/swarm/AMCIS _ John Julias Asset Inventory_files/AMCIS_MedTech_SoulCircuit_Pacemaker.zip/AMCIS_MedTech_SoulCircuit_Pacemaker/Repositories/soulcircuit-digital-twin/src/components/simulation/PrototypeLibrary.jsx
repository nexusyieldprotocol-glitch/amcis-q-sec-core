// Soul Circuit - Commercial Pacemaker Prototype Library
// Metrics from FDA PMA summaries, clinical papers, ISO disclosures

export const PROTOTYPE_LIBRARY = [
  {
    id: 'micra-vr',
    name: 'MICRA VR',
    manufacturer: 'Medtronic',
    model_type: 'leadless',
    battery_chemistry: 'Li-I2',
    energy_capacity_mah: 120, // Estimated from FDA PMA
    nominal_voltage: 2.8,
    internal_resistance_ohms: 100,
    volume_cc: 0.8,
    dimensions_mm: { length: 25.9, diameter: 6.7 },
    weight_grams: 2.0,
    energy_harvesting_enabled: false,
    harvesting_type: 'none',
    supercapacitor_enabled: false,
    rechargeable: false,
    expected_lifetime_years: 12, // Clinical average
    pacing_modes: ['VVI', 'VVIR'],
    max_pacing_rate_bpm: 180,
    pulse_amplitude_v: 2.5, // 0.5-3.5V range
    pulse_width_ms: 0.4, // 0.06-1.0ms range
    energy_per_pulse_uj: 15, // 5-25 µJ typical
    quiescent_power_uw: 7, // 5-10 µW baseline
    thermal_dissipation_mw: 15,
    biocompatibility_rating: 'ISO_10993',
    mri_conditional: true,
    status: 'approved',
    notes: 'Gold standard leadless VVI, Li-I2 ultra-stable chemistry, world\'s smallest pacemaker',
    color: '#3B82F6'
  },
  {
    id: 'aveir-dr',
    name: 'AVEIR DR',
    manufacturer: 'Abbott',
    model_type: 'leadless',
    battery_chemistry: 'Li-CFx',
    energy_capacity_mah: 140, // Higher volumetric density
    nominal_voltage: 3.0,
    internal_resistance_ohms: 80,
    volume_cc: 0.85,
    dimensions_mm: { length: 41.4, diameter: 6.0 },
    weight_grams: 2.5,
    energy_harvesting_enabled: false,
    harvesting_type: 'none',
    supercapacitor_enabled: false,
    rechargeable: false,
    expected_lifetime_years: 15, // Abbott 15-20 year target
    pacing_modes: ['DDD', 'DDI'],
    max_pacing_rate_bpm: 220,
    pulse_amplitude_v: 3.0,
    pulse_width_ms: 0.5,
    energy_per_pulse_uj: 18, // Dual chamber higher energy
    quiescent_power_uw: 9, // Intracardiac telemetry overhead
    thermal_dissipation_mw: 18,
    biocompatibility_rating: 'ISO_10993',
    mri_conditional: true,
    status: 'approved',
    notes: 'Retrievable dual-chamber, Li-CFx high density, conductive i2i telemetry',
    color: '#8B5CF6'
  },
  {
    id: 'base44-nexus',
    name: 'Base44 Nexus',
    manufacturer: 'Base44 Labs',
    model_type: 'leadless',
    battery_chemistry: 'Hybrid',
    energy_capacity_mah: 200, // Li-CFx + thin-film buffer
    nominal_voltage: 3.3,
    internal_resistance_ohms: 60,
    volume_cc: 1.0,
    dimensions_mm: { length: 30, diameter: 7.5 },
    weight_grams: 3.2,
    energy_harvesting_enabled: true,
    harvesting_type: 'hybrid', // Piezo + thermoelectric + buffer
    supercapacitor_enabled: true,
    supercap_capacitance_f: 0.1, // Medical-grade supercap
    rechargeable: false,
    expected_lifetime_years: 20,
    pacing_modes: ['VVI', 'VVIR', 'DDD'],
    max_pacing_rate_bpm: 200,
    pulse_amplitude_v: 2.8,
    pulse_width_ms: 0.45,
    energy_per_pulse_uj: 16,
    quiescent_power_uw: 6, // Optimized power IC
    thermal_dissipation_mw: 20,
    biocompatibility_rating: 'ISO_10993',
    mri_conditional: true,
    status: 'prototype',
    notes: '30-year target feasible, hybrid harvesting + solid-state buffer, 2030-2035 window',
    color: '#14B8A6'
  },
  {
    id: 'base44-aurora',
    name: 'Base44 Aurora',
    manufacturer: 'Base44 Labs',
    model_type: 'hybrid',
    battery_chemistry: 'Li-Ion',
    energy_capacity_mah: 350,
    nominal_voltage: 3.7,
    internal_resistance_ohms: 25,
    volume_cc: 2.5,
    dimensions_mm: { length: 45.0, width: 32.0, thickness: 8.0 },
    weight_grams: 12.0,
    energy_harvesting_enabled: true,
    harvesting_type: 'hybrid',
    supercapacitor_enabled: true,
    supercap_capacitance_f: 0.5,
    rechargeable: true,
    expected_lifetime_years: 25,
    pacing_modes: ['VVI', 'DDD', 'DDDR', 'CRT'],
    max_pacing_rate_bpm: 220,
    pulse_amplitude_v: 1.5,
    pulse_width_ms: 0.25,
    energy_per_pulse_uj: 10,
    quiescent_power_uw: 8,
    thermal_dissipation_mw: 25,
    biocompatibility_rating: 'ISO_10993',
    mri_conditional: true,
    status: 'concept',
    notes: 'Next-gen rechargeable system with hybrid harvesting for extended lifetime',
    color: '#F59E0B'
  },
  {
    id: 'boston-accolade',
    name: 'Accolade MRI',
    manufacturer: 'Boston Scientific',
    model_type: 'transvenous',
    battery_chemistry: 'Li-MnO2',
    energy_capacity_mah: 1000,
    nominal_voltage: 3.0,
    internal_resistance_ohms: 95,
    volume_cc: 11.0,
    dimensions_mm: { length: 48.0, width: 44.0, thickness: 7.5 },
    weight_grams: 22.0,
    energy_harvesting_enabled: false,
    harvesting_type: 'none',
    supercapacitor_enabled: false,
    rechargeable: false,
    expected_lifetime_years: 13, // Boston Scientific longevity focus
    pacing_modes: ['VVI', 'DDD', 'DDDR'],
    max_pacing_rate_bpm: 180,
    pulse_amplitude_v: 3.5, // Higher voltage headroom
    pulse_width_ms: 0.4,
    energy_per_pulse_uj: 20,
    quiescent_power_uw: 8,
    thermal_dissipation_mw: 20,
    biocompatibility_rating: 'ISO_10993',
    mri_conditional: true,
    status: 'approved',
    notes: 'Li-MnO2 chemistry, higher pulse voltage capacity, larger can volume',
    color: '#F97316'
  },
  {
    id: 'biotronik-edora',
    name: 'Edora 8 DR-T',
    manufacturer: 'Biotronik',
    model_type: 'transvenous',
    battery_chemistry: 'Li-I2',
    energy_capacity_mah: 950,
    nominal_voltage: 2.8,
    internal_resistance_ohms: 110,
    volume_cc: 10.5,
    dimensions_mm: { length: 47.0, width: 43.0, thickness: 7.0 },
    weight_grams: 20.0,
    energy_harvesting_enabled: false,
    harvesting_type: 'none',
    supercapacitor_enabled: false,
    rechargeable: false,
    expected_lifetime_years: 15, // European longevity focus
    pacing_modes: ['VVI', 'DDD', 'DDDR'],
    max_pacing_rate_bpm: 185,
    pulse_amplitude_v: 3.0,
    pulse_width_ms: 0.4,
    energy_per_pulse_uj: 18,
    quiescent_power_uw: 7,
    thermal_dissipation_mw: 18,
    biocompatibility_rating: 'ISO_10993',
    mri_conditional: true,
    status: 'approved',
    notes: 'ProMRI pacemaker, MRI mode energy penalties, European 15+ year focus',
    color: '#06B6D4'
  },
  {
    id: 'classic-transvenous',
    name: 'Legacy Transvenous',
    manufacturer: 'Reference Design',
    model_type: 'transvenous',
    battery_chemistry: 'Li-I2',
    energy_capacity_mah: 1000,
    nominal_voltage: 2.8,
    internal_resistance_ohms: 100,
    volume_cc: 12.0,
    dimensions_mm: { length: 50.0, width: 45.0, thickness: 8.0 },
    weight_grams: 25.0,
    energy_harvesting_enabled: false,
    harvesting_type: 'none',
    supercapacitor_enabled: false,
    rechargeable: false,
    expected_lifetime_years: 12,
    pacing_modes: ['VVI', 'DDD', 'DDDR'],
    max_pacing_rate_bpm: 180,
    pulse_amplitude_v: 3.0,
    pulse_width_ms: 0.5,
    energy_per_pulse_uj: 22,
    quiescent_power_uw: 10,
    thermal_dissipation_mw: 25,
    biocompatibility_rating: 'Class_VI',
    mri_conditional: false,
    status: 'legacy',
    notes: 'Traditional transvenous design for comparison baseline',
    color: '#6B7280'
  }
];

export const getPrototypeById = (id) => PROTOTYPE_LIBRARY.find(p => p.id === id);

export const getPrototypesByStatus = (status) => 
  PROTOTYPE_LIBRARY.filter(p => p.status === status);

export const getPrototypesByManufacturer = (manufacturer) =>
  PROTOTYPE_LIBRARY.filter(p => p.manufacturer === manufacturer);