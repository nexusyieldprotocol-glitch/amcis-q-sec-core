import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, Save, Plus, Trash2, Copy, CheckCircle2, 
  Zap, Activity, AlertTriangle, Thermometer 
} from 'lucide-react';
import { toast } from 'sonner';

export default function ConfigurationEditor({ 
  prototype, 
  isOpen, 
  onClose, 
  onApplyConfiguration 
}) {
  const queryClient = useQueryClient();
  const [selectedConfig, setSelectedConfig] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(getDefaultConfig(prototype));

  // Fetch configurations for this prototype
  const { data: configurations = [] } = useQuery({
    queryKey: ['deviceConfigurations', prototype?.id],
    queryFn: () => base44.entities.DeviceConfiguration.filter({ 
      prototype_id: prototype?.id 
    }),
    enabled: !!prototype && isOpen
  });

  // Create configuration
  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.DeviceConfiguration.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['deviceConfigurations']);
      toast.success('Configuration saved');
      setIsEditing(false);
    }
  });

  // Update configuration
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DeviceConfiguration.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['deviceConfigurations']);
      toast.success('Configuration updated');
    }
  });

  // Delete configuration
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.DeviceConfiguration.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['deviceConfigurations']);
      toast.success('Configuration deleted');
      setSelectedConfig(null);
      setFormData(getDefaultConfig(prototype));
    }
  });

  const handleSave = () => {
    if (selectedConfig) {
      updateMutation.mutate({ id: selectedConfig.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleApply = () => {
    onApplyConfiguration?.(formData);
    onClose?.();
    toast.success('Configuration applied to simulation');
  };

  const handleLoadConfig = (config) => {
    setSelectedConfig(config);
    setFormData(config);
  };

  const handleNewConfig = () => {
    setSelectedConfig(null);
    setFormData(getDefaultConfig(prototype));
    setIsEditing(true);
  };

  const handleDuplicate = () => {
    setSelectedConfig(null);
    setFormData({
      ...formData,
      name: `${formData.name} (Copy)`,
      is_default: false
    });
    setIsEditing(true);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-teal-400" />
            Device Configuration
          </DialogTitle>
          <DialogDescription>
            Configure custom pacing parameters, energy harvesting, and failure sensitivities for {prototype?.name}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-3 gap-4 h-[600px]">
          {/* Saved Configurations List */}
          <div className="col-span-1 border-r border-slate-700 pr-4">
            <div className="flex items-center justify-between mb-3">
              <Label className="text-sm text-slate-400">Saved Profiles</Label>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleNewConfig}
                className="border-teal-600/50 text-teal-400 hover:bg-teal-600/10"
              >
                <Plus className="w-3 h-3 mr-1" />
                New
              </Button>
            </div>
            
            <ScrollArea className="h-[520px]">
              <div className="space-y-2">
                {configurations.map(config => (
                  <div
                    key={config.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedConfig?.id === config.id
                        ? 'bg-teal-900/30 border-teal-700'
                        : 'bg-slate-800/30 border-slate-700/50 hover:border-slate-600'
                    }`}
                    onClick={() => handleLoadConfig(config)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-white">{config.name}</span>
                      {config.is_default && (
                        <Badge variant="outline" className="border-green-700/50 text-green-400 text-xs">
                          Default
                        </Badge>
                      )}
                    </div>
                    {config.description && (
                      <p className="text-xs text-slate-500 line-clamp-2">{config.description}</p>
                    )}
                  </div>
                ))}
                
                {configurations.length === 0 && (
                  <div className="text-center py-8 text-slate-500">
                    <Settings className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-xs">No saved configurations</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Configuration Editor */}
          <div className="col-span-2">
            <ScrollArea className="h-[540px] pr-4">
              <div className="space-y-6">
                {/* Basic Info */}
                <div className="space-y-3">
                  <Label className="text-white">Configuration Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., High Performance Mode"
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                  
                  <Label className="text-white">Description</Label>
                  <Textarea
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe this configuration..."
                    className="bg-slate-800 border-slate-700 text-white h-16"
                  />
                </div>

                <Separator className="bg-slate-700" />

                {/* Pacing Parameters */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-teal-400">
                    <Activity className="w-4 h-4" />
                    <Label className="text-white font-medium">Pacing Parameters</Label>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-400 text-xs">Pacing Rate (BPM)</Label>
                      <Input
                        type="number"
                        value={formData.pacing_rate_bpm}
                        onChange={(e) => setFormData({ ...formData, pacing_rate_bpm: parseFloat(e.target.value) })}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-400 text-xs">Pacing Percentage (%)</Label>
                      <Input
                        type="number"
                        value={formData.pacing_percentage}
                        onChange={(e) => setFormData({ ...formData, pacing_percentage: parseFloat(e.target.value) })}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-400 text-xs">Pulse Amplitude (V)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={formData.pulse_amplitude_v}
                        onChange={(e) => setFormData({ ...formData, pulse_amplitude_v: parseFloat(e.target.value) })}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-400 text-xs">Pulse Width (ms)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={formData.pulse_width_ms}
                        onChange={(e) => setFormData({ ...formData, pulse_width_ms: parseFloat(e.target.value) })}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                  </div>
                </div>

                <Separator className="bg-slate-700" />

                {/* Energy Harvesting */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-orange-400">
                      <Zap className="w-4 h-4" />
                      <Label className="text-white font-medium">Energy Harvesting</Label>
                    </div>
                    <Switch
                      checked={formData.energy_harvesting_enabled}
                      onCheckedChange={(checked) => setFormData({ 
                        ...formData, 
                        energy_harvesting_enabled: checked 
                      })}
                    />
                  </div>
                  
                  {formData.energy_harvesting_enabled && (
                    <div className="space-y-3">
                      <div>
                        <Label className="text-slate-400 text-xs">Activity Level</Label>
                        <Select
                          value={formData.activity_level}
                          onValueChange={(value) => setFormData({ ...formData, activity_level: value })}
                        >
                          <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sedentary">Sedentary</SelectItem>
                            <SelectItem value="moderate">Moderate</SelectItem>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="athletic">Athletic</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label className="text-slate-400 text-xs">
                          Harvesting Efficiency: {(formData.harvesting_efficiency * 100).toFixed(0)}%
                        </Label>
                        <Slider
                          value={[formData.harvesting_efficiency * 100]}
                          onValueChange={([value]) => setFormData({ 
                            ...formData, 
                            harvesting_efficiency: value / 100 
                          })}
                          min={0}
                          max={100}
                          step={5}
                          className="mt-2"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <Separator className="bg-slate-700" />

                {/* Simulation Settings */}
                <div className="space-y-4">
                  <Label className="text-white font-medium">Simulation Settings</Label>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-slate-400 text-xs">Duration (years)</Label>
                      <Input
                        type="number"
                        value={formData.simulation_duration_years}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          simulation_duration_years: parseFloat(e.target.value) 
                        })}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-slate-400 text-xs">Temperature (°C)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={formData.ambient_temperature_c}
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          ambient_temperature_c: parseFloat(e.target.value) 
                        })}
                        className="bg-slate-800 border-slate-700 text-white mt-1"
                      />
                    </div>
                  </div>
                </div>

                <Separator className="bg-slate-700" />

                {/* Failure Mode Sensitivities */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-red-400">
                    <AlertTriangle className="w-4 h-4" />
                    <Label className="text-white font-medium">Failure Mode Sensitivities</Label>
                  </div>
                  
                  <div className="space-y-3">
                    {Object.entries(formData.failure_mode_sensitivities || {}).map(([mode, value]) => (
                      <div key={mode}>
                        <Label className="text-slate-400 text-xs capitalize">
                          {mode.replace(/_/g, ' ')}: {value.toFixed(1)}x
                        </Label>
                        <Slider
                          value={[value * 10]}
                          onValueChange={([val]) => setFormData({
                            ...formData,
                            failure_mode_sensitivities: {
                              ...formData.failure_mode_sensitivities,
                              [mode]: val / 10
                            }
                          })}
                          min={0}
                          max={30}
                          step={1}
                          className="mt-1"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollArea>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-700">
              <div className="flex gap-2">
                {selectedConfig && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteMutation.mutate(selectedConfig.id)}
                      className="border-red-700/50 text-red-400 hover:bg-red-900/20"
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDuplicate}
                      className="border-slate-700"
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Duplicate
                    </Button>
                  </>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleSave}
                  className="border-teal-700/50 text-teal-400 hover:bg-teal-900/20"
                >
                  <Save className="w-3 h-3 mr-1" />
                  Save
                </Button>
                <Button
                  onClick={handleApply}
                  className="bg-teal-600 hover:bg-teal-700 text-white"
                >
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Apply to Simulation
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function getDefaultConfig(prototype) {
  return {
    name: 'Default Configuration',
    prototype_id: prototype?.id || '',
    pacing_rate_bpm: 70,
    pacing_percentage: 50,
    pulse_amplitude_v: prototype?.pulse_amplitude_v || 2.5,
    pulse_width_ms: prototype?.pulse_width_ms || 0.4,
    activity_level: 'moderate',
    ambient_temperature_c: 37,
    energy_harvesting_enabled: prototype?.energy_harvesting_enabled || false,
    harvesting_efficiency: 0.85,
    failure_mode_sensitivities: {
      battery_swelling: 1.0,
      capacitor_failure: 1.0,
      thermal_spike: 1.0,
      lead_impedance: 1.0,
      voltage_sag: 1.0
    },
    enabled_failure_modes: [],
    simulation_duration_years: 10,
    is_default: false,
    description: ''
  };
}