import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Radio, Activity, AlertTriangle, CheckCircle2 } from 'lucide-react';

export default function FleetLiveStatus() {
  const [recentUpdates, setRecentUpdates] = useState([]);
  const [deviceStatuses, setDeviceStatuses] = useState({});

  const { data: devices = [] } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list('-updated_date', 100)
  });

  // Subscribe to device updates
  useEffect(() => {
    const unsubscribe = base44.entities.DeviceRegistry.subscribe((event) => {
      if (event.type === 'update') {
        setDeviceStatuses(prev => ({
          ...prev,
          [event.id]: event.data
        }));
        setRecentUpdates(prev => [{
          id: event.id,
          device_id: event.data.device_id,
          status: event.data.status,
          timestamp: new Date()
        }, ...prev].slice(0, 20));
      }
    });

    return unsubscribe;
  }, []);

  // Subscribe to snapshot updates
  useEffect(() => {
    const unsubscribe = base44.entities.LongevitySnapshot.subscribe((event) => {
      if (event.type === 'create') {
        setRecentUpdates(prev => [{
          id: event.id,
          device_registry_id: event.data.device_registry_id,
          type: 'snapshot',
          risk_score: event.data.risk_score,
          timestamp: new Date()
        }, ...prev].slice(0, 20));
      }
    });

    return unsubscribe;
  }, []);

  const statusCounts = devices.reduce((acc, device) => {
    const status = deviceStatuses[device.id]?.status || device.status;
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      {/* Fleet Status Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatusCard label="Active" count={statusCounts.active || 0} color="green" />
        <StatusCard label="ERI" count={statusCounts.eri || 0} color="yellow" />
        <StatusCard label="EOL" count={statusCounts.eol || 0} color="orange" />
        <StatusCard label="Explanted" count={statusCounts.explanted || 0} color="slate" />
      </div>

      {/* Live Activity Feed */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-teal-400" />
            Live Activity Feed
            <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse ml-auto" />
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            {recentUpdates.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Waiting for updates...</p>
              </div>
            ) : (
              <div className="space-y-2">
                {recentUpdates.map((update, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-3 p-2 rounded-lg bg-slate-800/30 border border-slate-700/50"
                  >
                    <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white truncate">
                        {update.device_id || `Device ${update.device_registry_id?.slice(-8)}`}
                      </p>
                      <p className="text-xs text-slate-400">
                        {update.type === 'snapshot' 
                          ? `New snapshot • Risk: ${update.risk_score}%`
                          : `Status: ${update.status}`
                        }
                      </p>
                    </div>
                    <p className="text-xs text-slate-500 flex-shrink-0">
                      {update.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

function StatusCard({ label, count, color }) {
  const colors = {
    green: 'bg-green-900/20 border-green-700/50 text-green-400',
    yellow: 'bg-yellow-900/20 border-yellow-700/50 text-yellow-400',
    orange: 'bg-orange-900/20 border-orange-700/50 text-orange-400',
    slate: 'bg-slate-800/50 border-slate-700 text-slate-400'
  };

  const icons = {
    green: CheckCircle2,
    yellow: Activity,
    orange: AlertTriangle,
    slate: Activity
  };

  const Icon = icons[color];

  return (
    <Card className={`${colors[color]} border`}>
      <CardContent className="p-3">
        <div className="flex items-center justify-between mb-1">
          <Icon className="w-4 h-4" />
        </div>
        <p className="text-xs opacity-80 mb-1">{label}</p>
        <p className="text-2xl font-bold">{count}</p>
      </CardContent>
    </Card>
  );
}