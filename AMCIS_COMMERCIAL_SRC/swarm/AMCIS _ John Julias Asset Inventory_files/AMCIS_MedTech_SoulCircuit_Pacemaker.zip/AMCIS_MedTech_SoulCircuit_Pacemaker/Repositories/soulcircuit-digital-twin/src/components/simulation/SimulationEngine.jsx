// Soul Circuit Digital Twin - Core Simulation Engine
// IEC 62304 Compliant Structure - Class B Medical Device Software
// Metrics based on FDA PMA summaries, clinical papers, ISO test disclosures

/**
 * Battery Chemistry Models - Commercial Pacemaker Data
 * Sources: FDA PMA summaries, teardown analysis, patent disclosures
 */
export const BATTERY_MODELS = {
  'Li-Ion': {
    nominalVoltage: 3.7,
    cutoffVoltage: 3.0,
    voltageCurve: (soc) => 3.0 + (0.7 * Math.pow(soc, 0.3)),
    degradationRate: 0.02, // 2% per year
    selfDischargeRate: 0.02, // 2% per year
    temperatureCoeff: 0.003, // V per °C
    energyDensityWhPerCc: 0.4,
    pulsePowerCapability: 'medium'
  },
  'Li-CFx': {
    nominalVoltage: 3.0,
    cutoffVoltage: 2.0,
    voltageCurve: (soc) => 2.0 + (1.0 * Math.pow(soc, 0.5)),
    degradationRate: 0.005,
    selfDischargeRate: 0.008, // <1% per year (ultra-stable)
    temperatureCoeff: 0.002,
    energyDensityWhPerCc: 0.5, // highest volumetric
    pulsePowerCapability: 'low', // lower pulse power vs Li-I2
    designLife: 15 // Abbott Aveir target
  },
  'Li-I2': {
    nominalVoltage: 2.8,
    cutoffVoltage: 2.0,
    voltageCurve: (soc) => 2.0 + (0.8 * soc),
    degradationRate: 0.008,
    selfDischargeRate: 0.005, // <1% per year (gold standard)
    temperatureCoeff: 0.0015,
    energyDensityWhPerCc: 0.35,
    pulsePowerCapability: 'high', // excellent pulse delivery
    designLife: 12, // Medtronic standard
    calendarAging: 'ultra-stable'
  },
  'SVO': {
    nominalVoltage: 3.2,
    cutoffVoltage: 2.0,
    voltageCurve: (soc) => 2.0 + (1.2 * Math.pow(soc, 0.7)),
    degradationRate: 0.006,
    selfDischargeRate: 0.015,
    temperatureCoeff: 0.0025,
    energyDensityWhPerCc: 0.38
  },
  'Li-MnO2': {
    nominalVoltage: 3.0,
    cutoffVoltage: 2.0,
    voltageCurve: (soc) => 2.0 + (1.0 * Math.pow(soc, 0.6)),
    degradationRate: 0.01,
    selfDischargeRate: 0.012,
    temperatureCoeff: 0.002,
    energyDensityWhPerCc: 0.42,
    pulsePowerCapability: 'high', // Boston Scientific preference
    designLife: 13
  },
  'Hybrid': {
    nominalVoltage: 3.5,
    cutoffVoltage: 2.5,
    voltageCurve: (soc) => 2.5 + (1.0 * Math.pow(soc, 0.4)),
    degradationRate: 0.015,
    selfDischargeRate: 0.008,
    temperatureCoeff: 0.0028,
    energyDensityWhPerCc: 0.45,
    pulsePowerCapability: 'high',
    hasSuperCapBuffer: true, // Li-CFx + capacitor
    designLife: 20, // 30-year target feasible
    feasibility: '2030-2035'
  }
};

/**
 * Energy Harvesting Models
 * Based on in-vivo cardiac biomechanics and medical MEMS research
 */
export const HARVESTING_MODELS = {
  none: { 
    baseOutput: 0, 
    continuousUw: 0,
    burstPeakUw: 0,
    activityMultiplier: { sedentary: 0, moderate: 0, active: 0, athletic: 0 } 
  },
  piezoelectric: {
    // RV wall strain + tricuspid valve motion
    baseOutput: 0.005, // mW
    continuousUw: 5, // 1-10 µW realistic
    burstPeakUw: 75, // 50-100 µW bursts
    materials: ['PZT', 'AlN', 'PVDF'],
    efficiency: 0.15,
    activityMultiplier: { 
      sedentary: 0.4,  // 2 µW
      moderate: 1.0,   // 5 µW
      active: 1.6,     // 8 µW
      athletic: 2.0    // 10 µW
    }
  },
  thermoelectric: {
    baseOutput: 0.002,
    continuousUw: 2, // 1-3 µW realistic
    burstPeakUw: 5,
    efficiency: 0.05, // Carnot-limited
    activityMultiplier: { 
      sedentary: 0.8, 
      moderate: 1.0, 
      active: 1.2, 
      athletic: 1.3 
    }
  },
  inductive: {
    baseOutput: 0.001,
    continuousUw: 3,
    burstPeakUw: 30,
    activityMultiplier: { 
      sedentary: 0.5, 
      moderate: 1.0, 
      active: 1.4, 
      athletic: 1.7 
    }
  },
  hybrid: {
    // Piezo + thermoelectric + buffer - 30-year architecture
    baseOutput: 0.008,
    continuousUw: 8, // 7-12 µW combined
    burstPeakUw: 100,
    storageBuffer: 'supercap + thin-film battery',
    activityMultiplier: { 
      sedentary: 0.5,  // 4 µW
      moderate: 1.0,   // 8 µW
      active: 1.5,     // 12 µW
      athletic: 2.0    // 16 µW
    }
  }
};

/**
 * Failure Mode Definitions
 */
export const FAILURE_MODES = {
  battery_swelling: {
    name: 'Battery Swelling',
    probability: (age, temp) => 0.001 * age * (temp > 39 ? 2 : 1),
    indicator: (state) => state.internalResistance > state.initialResistance * 1.5,
    severity: 'critical'
  },
  capacitor_failure: {
    name: 'Capacitor Degradation',
    probability: (age) => 0.0005 * Math.pow(age, 1.5),
    indicator: (state) => state.supercapCapacitance < state.initialSupercapCapacitance * 0.7,
    severity: 'moderate'
  },
  thermal_spike: {
    name: 'Thermal Event',
    probability: (age, temp) => temp > 41 ? 0.1 : 0.001,
    indicator: (state) => state.temperature > 41,
    severity: 'critical'
  },
  lead_impedance: {
    name: 'Lead Impedance Change',
    probability: (age) => 0.002 * age,
    indicator: (state) => state.leadImpedance > state.initialLeadImpedance * 1.3,
    severity: 'moderate'
  },
  voltage_sag: {
    name: 'Premature Voltage Sag',
    probability: (age) => 0.001 * Math.pow(age, 2),
    indicator: (state) => state.voltage < state.nominalVoltage * 0.85 && state.soc > 0.3,
    severity: 'warning'
  }
};

/**
 * Bioheat Transfer Model (Simplified Pennes Equation)
 * For tissue-adjacent thermal dissipation
 */
export const calculateThermalDissipation = (powerDissipation, bloodFlow, ambientTemp) => {
  const tissueSpecificHeat = 3600; // J/(kg·K)
  const tissueDensity = 1050; // kg/m³
  const bloodPerfusionRate = bloodFlow * 0.001; // m³/(s·m³)
  const metabolicHeat = 0.5; // W/m³
  
  // Simplified steady-state temperature rise
  const thermalConductivity = 0.5; // W/(m·K)
  const deviceRadius = 0.01; // m (approximation)
  
  const tempRise = (powerDissipation * 0.001) / (4 * Math.PI * thermalConductivity * deviceRadius);
  return ambientTemp + tempRise;
};

/**
 * ISO 14708-1 Thermal Safety Thresholds
 */
export const THERMAL_THRESHOLDS = {
  normal: { max: 39, label: 'Normal Operation' },
  elevated: { max: 41, label: 'Elevated - Monitor' },
  warning: { max: 43, label: 'Warning - Reduce Load' },
  critical: { max: 45, label: 'Critical - Immediate Action' }
};

/**
 * Core Simulation State Class
 */
export class SimulationState {
  constructor(prototype, config = {}) {
    this.prototype = prototype;
    this.config = {
      pacingRate: config.pacingRate || 70,
      pacingPercentage: config.pacingPercentage || 50,
      pulseAmplitude: config.pulseAmplitude || prototype.pulse_amplitude_v || 2.5,
      pulseWidth: config.pulseWidth || prototype.pulse_width_ms || 0.4,
      activityLevel: config.activityLevel || 'moderate',
      ambientTemp: config.ambientTemp || 37,
      failureModes: config.failureModes || [],
      timeStepDays: config.timeStepDays || 1
    };
    
    this.reset();
  }
  
  reset() {
    const p = this.prototype;
    const batteryModel = BATTERY_MODELS[p.battery_chemistry] || BATTERY_MODELS['Li-Ion'];
    
    this.state = {
      // Time tracking
      elapsedDays: 0,
      elapsedYears: 0,
      
      // Battery state
      soc: 1.0, // State of charge (0-1)
      voltage: batteryModel.nominalVoltage,
      nominalVoltage: batteryModel.nominalVoltage,
      internalResistance: p.internal_resistance_ohms || 100,
      initialResistance: p.internal_resistance_ohms || 100,
      capacityRemaining: p.energy_capacity_mah,
      initialCapacity: p.energy_capacity_mah,
      degradationFactor: 1.0,
      
      // Supercapacitor state
      supercapVoltage: p.supercapacitor_enabled ? batteryModel.nominalVoltage : 0,
      supercapCapacitance: p.supercap_capacitance_f || 0,
      initialSupercapCapacitance: p.supercap_capacitance_f || 0,
      
      // Thermal state
      temperature: this.config.ambientTemp,
      maxTemperature: this.config.ambientTemp,
      
      // Lead state
      leadImpedance: 500, // Ohms (typical electrode impedance 400-800)
      initialLeadImpedance: 500,
      
      // Energy harvesting
      harvestedEnergy: 0,
      totalHarvestedEnergy: 0,
      
      // Pacing statistics
      totalPaces: 0,
      energyDelivered: 0,
      
      // Telemetry
      telemetryEnergy: 0,
      
      // Failure tracking
      failures: [],
      warnings: [],
      
      // Status
      isOperational: true,
      eolReached: false
    };
    
    this.timeSeries = [];
  }
  
  /**
   * Calculate energy consumption per pace (5-25 µJ typical)
   */
  calculatePaceEnergy() {
    const { pulseAmplitude, pulseWidth } = this.config;
    const leadImpedance = this.state.leadImpedance;
    
    // E = V² × t / R (in microjoules)
    const energyPerPace = (pulseAmplitude ** 2) * (pulseWidth / 1000) / leadImpedance * 1e6;
    
    // Clamp to commercial range: 5-25 µJ
    return Math.max(5, Math.min(25, energyPerPace));
  }
  
  /**
   * Calculate harvested energy for time step
   * Models realistic cardiac biomechanics
   */
  calculateHarvestedEnergy(days) {
    const harvestingType = this.prototype.harvesting_type || 'none';
    const model = HARVESTING_MODELS[harvestingType];
    const activityMultiplier = model.activityMultiplier[this.config.activityLevel];
    
    // Continuous baseline + burst peaks
    const hours = days * 24;
    const continuousUw = model.continuousUw * activityMultiplier;
    
    // Burst peaks (20% duty cycle during active beats)
    const burstDutyCycle = 0.2;
    const burstContributionUw = model.burstPeakUw * burstDutyCycle * activityMultiplier * 0.5;
    
    const totalPowerUw = continuousUw + burstContributionUw;
    const energyUwh = totalPowerUw * hours;
    
    // Convert to mAh (assuming 3V nominal)
    const energyMAh = (energyUwh / 1000000) / 3.0 * 1000;
    
    // Storage efficiency (supercap or direct)
    const storageEff = this.prototype.supercapacitor_enabled ? 0.90 : 0.85;
    
    return energyMAh * storageEff;
  }
  
  /**
   * Advance simulation by one time step
   */
  step() {
    if (!this.state.isOperational) return this.state;
    
    const days = this.config.timeStepDays;
    const p = this.prototype;
    const batteryModel = BATTERY_MODELS[p.battery_chemistry] || BATTERY_MODELS['Li-Ion'];
    
    // Calculate pacing load
    const pacesPerDay = this.config.pacingRate * 60 * 24 * (this.config.pacingPercentage / 100);
    const totalPaces = pacesPerDay * days;
    const energyPerPace = this.calculatePaceEnergy();
    const pacingEnergy = totalPaces * energyPerPace / 1e6; // Convert µJ to J
    
    // Convert to mAh consumed
    const pacingCurrent = pacingEnergy / (this.state.voltage * days * 24 * 3600) * 1000;
    
    // Quiescent power draw (5-10 µW typical)
    const quiescentUw = 7;
    const quiescentCurrent = (quiescentUw * days * 24 / 1000000) / this.state.voltage * 1000;
    
    // RF telemetry bursts (1-10 mW for milliseconds, duty-cycled)
    const telemetryBurstsPerDay = 4;
    const telemetryMw = 5;
    const telemetryDurationMs = 100;
    const telemetryEnergy = (telemetryMw * telemetryDurationMs / 1000 / 3600) / this.state.voltage * days * telemetryBurstsPerDay;
    
    const totalCurrentDraw = pacingCurrent + quiescentCurrent + telemetryEnergy;
    
    // Energy harvesting offset
    const harvestedEnergy = this.calculateHarvestedEnergy(days);
    this.state.harvestedEnergy = harvestedEnergy;
    this.state.totalHarvestedEnergy += harvestedEnergy;
    this.state.telemetryEnergy += telemetryEnergy;
    
    // Net energy consumption
    const netConsumption = Math.max(0, (totalCurrentDraw * days * 24) - harvestedEnergy);
    
    // Update capacity and SOC
    this.state.capacityRemaining -= netConsumption;
    this.state.soc = Math.max(0, this.state.capacityRemaining / this.state.initialCapacity);
    
    // Battery degradation
    const yearFraction = days / 365;
    this.state.degradationFactor *= (1 - batteryModel.degradationRate * yearFraction);
    this.state.internalResistance = this.state.initialResistance / this.state.degradationFactor;
    
    // Update voltage based on SOC and degradation
    this.state.voltage = batteryModel.voltageCurve(this.state.soc) * this.state.degradationFactor;
    
    // Thermal calculation
    const powerDissipation = this.state.internalResistance * (totalCurrentDraw / 1000) ** 2 * 1000;
    this.state.temperature = calculateThermalDissipation(
      powerDissipation + (p.thermal_dissipation_mw || 1),
      1.0,
      this.config.ambientTemp
    );
    this.state.maxTemperature = Math.max(this.state.maxTemperature, this.state.temperature);
    
    // Lead impedance drift
    this.state.leadImpedance = this.state.initialLeadImpedance * (1 + 0.001 * this.state.elapsedYears);
    
    // Update time
    this.state.elapsedDays += days;
    this.state.elapsedYears = this.state.elapsedDays / 365;
    this.state.totalPaces += totalPaces;
    this.state.energyDelivered += pacingEnergy;
    
    // Check failure modes
    this.checkFailureModes();
    
    // Check end of life
    if (this.state.voltage < batteryModel.cutoffVoltage || this.state.soc <= 0.05) {
      this.state.eolReached = true;
      this.state.isOperational = false;
    }
    
    // Record time series data point
    this.timeSeries.push({
      days: this.state.elapsedDays,
      years: this.state.elapsedYears,
      voltage: this.state.voltage,
      soc: this.state.soc,
      temperature: this.state.temperature,
      internalResistance: this.state.internalResistance,
      harvestedEnergy: harvestedEnergy,
      capacityRemaining: this.state.capacityRemaining,
      energyDelivered: energyPerPace,
      telemetryEnergy: telemetryEnergy
    });
    
    return this.state;
  }
  
  /**
   * Check and trigger failure modes
   */
  checkFailureModes() {
    const enabledModes = this.config.failureModes;
    
    for (const modeKey of enabledModes) {
      const mode = FAILURE_MODES[modeKey];
      if (!mode) continue;
      
      const probability = mode.probability(this.state.elapsedYears, this.state.temperature);
      const triggered = mode.indicator(this.state);
      
      if (triggered || Math.random() < probability * this.config.timeStepDays / 365) {
        const existingFailure = this.state.failures.find(f => f.type === modeKey);
        if (!existingFailure) {
          this.state.failures.push({
            type: modeKey,
            name: mode.name,
            severity: mode.severity,
            detectedAt: this.state.elapsedYears,
            detectedDays: this.state.elapsedDays
          });
          
          if (mode.severity === 'critical') {
            this.state.isOperational = false;
          }
        }
      }
    }
  }
  
  /**
   * Run simulation for specified duration
   */
  runSimulation(durationYears) {
    const totalDays = durationYears * 365;
    const steps = Math.ceil(totalDays / this.config.timeStepDays);
    
    for (let i = 0; i < steps && this.state.isOperational; i++) {
      this.step();
    }
    
    return {
      finalState: this.state,
      timeSeries: this.timeSeries,
      predictedEOL: this.predictEOL()
    };
  }
  
  /**
   * Predict end-of-life based on current consumption rate
   */
  predictEOL() {
    if (this.timeSeries.length < 2) return this.prototype.expected_lifetime_years || 10;
    
    const recentPoints = this.timeSeries.slice(-10);
    const avgConsumptionPerDay = recentPoints.reduce((sum, p, i, arr) => {
      if (i === 0) return 0;
      return sum + (arr[i-1].capacityRemaining - p.capacityRemaining) / this.config.timeStepDays;
    }, 0) / (recentPoints.length - 1);
    
    if (avgConsumptionPerDay <= 0) return 99; // Effectively infinite with harvesting
    
    const daysRemaining = this.state.capacityRemaining / avgConsumptionPerDay;
    return (this.state.elapsedDays + daysRemaining) / 365;
  }
  
  /**
   * Get thermal compliance status
   */
  getThermalCompliance() {
    const temp = this.state.temperature;
    for (const [level, threshold] of Object.entries(THERMAL_THRESHOLDS)) {
      if (temp <= threshold.max) {
        return { level, ...threshold, current: temp, compliant: level !== 'critical' };
      }
    }
    return { level: 'critical', label: 'Critical - Immediate Action', max: 45, current: temp, compliant: false };
  }
}

/**
 * Utility to export simulation report
 */
export const generateReport = (simulation, prototype) => {
  const state = simulation.finalState;
  const compliance = simulation.getThermalCompliance ? simulation.getThermalCompliance() : { level: 'normal', compliant: true };
  
  return {
    metadata: {
      generatedAt: new Date().toISOString(),
      prototypeName: prototype.name,
      manufacturer: prototype.manufacturer,
      simulationDuration: state.elapsedYears
    },
    configuration: simulation.config,
    results: {
      finalVoltage: state.voltage.toFixed(3),
      finalSOC: (state.soc * 100).toFixed(1) + '%',
      capacityRemaining: state.capacityRemaining.toFixed(2) + ' mAh',
      totalPaces: Math.round(state.totalPaces),
      energyDelivered: state.energyDelivered.toFixed(2) + ' J',
      totalHarvestedEnergy: state.totalHarvestedEnergy.toFixed(2) + ' mAh',
      maxTemperature: state.maxTemperature.toFixed(1) + '°C',
      predictedEOL: simulation.predictEOL ? simulation.predictEOL().toFixed(1) + ' years' : 'N/A'
    },
    thermalCompliance: compliance,
    failures: state.failures,
    warnings: state.warnings
  };
};