import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { TrendingUp, Bell, CheckCircle2, AlertTriangle } from 'lucide-react';
import { format, subDays } from 'date-fns';

export default function AlertDashboard({ alerts, configs }) {
  const stats = useMemo(() => {
    const last24h = subDays(new Date(), 1);
    const last7d = subDays(new Date(), 7);

    return {
      total: alerts.length,
      active: alerts.filter(a => !a.acknowledged && !a.resolved).length,
      acknowledged: alerts.filter(a => a.acknowledged).length,
      resolved: alerts.filter(a => a.resolved).length,
      last24h: alerts.filter(a => new Date(a.triggered_at) > last24h).length,
      last7d: alerts.filter(a => new Date(a.triggered_at) > last7d).length,
      critical: alerts.filter(a => a.severity === 'critical').length
    };
  }, [alerts]);

  const severityData = useMemo(() => {
    const counts = { critical: 0, high: 0, medium: 0, low: 0 };
    alerts.forEach(a => counts[a.severity]++);
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [alerts]);

  const metricData = useMemo(() => {
    const counts = {};
    alerts.forEach(a => {
      const metric = a.metric_type?.replace(/_/g, ' ') || 'unknown';
      counts[metric] = (counts[metric] || 0) + 1;
    });
    return Object.entries(counts).map(([name, count]) => ({ name, count }));
  }, [alerts]);

  const trendData = useMemo(() => {
    const days = 7;
    const data = [];
    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayAlerts = alerts.filter(a => {
        const alertDate = new Date(a.triggered_at);
        return alertDate.toDateString() === date.toDateString();
      });
      data.push({
        date: format(date, 'MMM d'),
        count: dayAlerts.length,
        critical: dayAlerts.filter(a => a.severity === 'critical').length
      });
    }
    return data;
  }, [alerts]);

  const COLORS = {
    critical: '#ef4444',
    high: '#f97316',
    medium: '#eab308',
    low: '#3b82f6'
  };

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 mb-1">Active Alerts</p>
                <p className="text-2xl font-bold text-orange-400">{stats.active}</p>
              </div>
              <Bell className="w-8 h-8 text-orange-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 mb-1">Critical</p>
                <p className="text-2xl font-bold text-red-400">{stats.critical}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 mb-1">Last 24h</p>
                <p className="text-2xl font-bold text-white">{stats.last24h}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-teal-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-700">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400 mb-1">Resolved</p>
                <p className="text-2xl font-bold text-green-400">{stats.resolved}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Severity Distribution */}
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">Alerts by Severity</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[entry.name]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Metric Breakdown */}
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white text-sm">Alerts by Metric Type</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={metricData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                <Bar dataKey="count" fill="#14b8a6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 7-Day Trend */}
        <Card className="bg-slate-900/50 border-slate-700 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-white text-sm">Alert Trend (7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                <Line type="monotone" dataKey="count" stroke="#14b8a6" strokeWidth={2} name="Total" />
                <Line type="monotone" dataKey="critical" stroke="#ef4444" strokeWidth={2} name="Critical" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Active Configurations */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Active Alert Configurations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {configs.filter(c => c.enabled).map(config => (
              <div key={config.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-white">{config.name}</p>
                  <p className="text-xs text-slate-400">
                    {config.metric_type.replace(/_/g, ' ')} {config.threshold_operator.replace(/_/g, ' ')} {config.threshold_value}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`${getSeverityColor(config.severity)}`}>
                    {config.severity}
                  </Badge>
                  {config.notification_channels?.map(ch => (
                    <Badge key={ch} variant="outline" className="text-xs border-teal-700/50 text-teal-400">
                      {ch}
                    </Badge>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function getSeverityColor(severity) {
  const colors = {
    low: 'bg-blue-900/30 text-blue-400',
    medium: 'bg-yellow-900/30 text-yellow-400',
    high: 'bg-orange-900/30 text-orange-400',
    critical: 'bg-red-900/30 text-red-400'
  };
  return colors[severity] || colors.medium;
}