import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Database, Plus, Upload, List, Activity } from 'lucide-react';

import DeviceList from '../components/devices/DeviceList';
import DeviceForm from '../components/devices/DeviceForm';
import BulkDeviceImport from '../components/devices/BulkDeviceImport';

export default function DeviceManagement() {
  const [activeTab, setActiveTab] = useState('list');
  const [editingDevice, setEditingDevice] = useState(null);

  const { data: devices = [], isLoading } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list('-updated_date', 1000)
  });

  const { data: snapshots = [] } = useQuery({
    queryKey: ['longevitySnapshots'],
    queryFn: () => base44.entities.LongevitySnapshot.list('-snapshot_date', 1000)
  });

  const handleAddDevice = () => {
    setEditingDevice(null);
    setActiveTab('add');
  };

  const handleEditDevice = (device) => {
    setEditingDevice(device);
    setActiveTab('add');
  };

  const handleDeviceCreated = () => {
    setActiveTab('list');
    setEditingDevice(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Database className="w-8 h-8 text-teal-400" />
              Device Management
            </h1>
            <p className="text-slate-400 mt-1">
              Comprehensive device registry and lifecycle management
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleAddDevice}
              className="bg-teal-600 hover:bg-teal-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Device
            </Button>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-slate-900/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 mb-1">Total Devices</p>
                  <p className="text-2xl font-bold text-white">{devices.length}</p>
                </div>
                <Database className="w-8 h-8 text-teal-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-900/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 mb-1">Active</p>
                  <p className="text-2xl font-bold text-green-400">
                    {devices.filter(d => d.status === 'active').length}
                  </p>
                </div>
                <Activity className="w-8 h-8 text-green-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-900/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 mb-1">ERI/EOL</p>
                  <p className="text-2xl font-bold text-orange-400">
                    {devices.filter(d => d.status === 'eri' || d.status === 'eol').length}
                  </p>
                </div>
                <Activity className="w-8 h-8 text-orange-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-slate-900/50 border-slate-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400 mb-1">Manufacturers</p>
                  <p className="text-2xl font-bold text-white">
                    {new Set(devices.map(d => d.manufacturer)).size}
                  </p>
                </div>
                <Database className="w-8 h-8 text-purple-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-slate-900 border border-slate-700">
            <TabsTrigger value="list" className="data-[state=active]:bg-teal-900/30">
              <List className="w-4 h-4 mr-2" />
              Device List
            </TabsTrigger>
            <TabsTrigger value="add" className="data-[state=active]:bg-teal-900/30">
              <Plus className="w-4 h-4 mr-2" />
              {editingDevice ? 'Edit Device' : 'Add Device'}
            </TabsTrigger>
            <TabsTrigger value="import" className="data-[state=active]:bg-teal-900/30">
              <Upload className="w-4 h-4 mr-2" />
              Bulk Import
            </TabsTrigger>
          </TabsList>

          <TabsContent value="list">
            <DeviceList
              devices={devices}
              snapshots={snapshots}
              isLoading={isLoading}
              onEditDevice={handleEditDevice}
            />
          </TabsContent>

          <TabsContent value="add">
            <DeviceForm
              device={editingDevice}
              onSuccess={handleDeviceCreated}
              onCancel={() => setActiveTab('list')}
            />
          </TabsContent>

          <TabsContent value="import">
            <BulkDeviceImport onSuccess={() => setActiveTab('list')} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}