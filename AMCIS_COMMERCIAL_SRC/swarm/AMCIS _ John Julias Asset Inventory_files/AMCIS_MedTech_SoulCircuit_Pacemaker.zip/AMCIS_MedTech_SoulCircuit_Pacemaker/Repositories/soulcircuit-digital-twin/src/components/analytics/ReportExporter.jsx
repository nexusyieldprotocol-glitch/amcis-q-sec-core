import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, FileText, FileSpreadsheet, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function ReportExporter({ registryData, snapshots }) {
  const [reportConfig, setReportConfig] = useState({
    includeFleetMetrics: true,
    includeComparisons: true,
    includePredictive: true,
    includeRawData: false,
    format: 'json',
    dateRange: 'all'
  });
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    
    // Build report data
    const reportData = {
      metadata: {
        generatedAt: new Date().toISOString(),
        title: 'Fleet Analytics Report',
        dateRange: reportConfig.dateRange,
        deviceCount: registryData.length,
        snapshotCount: snapshots.length
      },
      sections: {}
    };

    if (reportConfig.includeFleetMetrics) {
      reportData.sections.fleetMetrics = {
        totalDevices: registryData.length,
        activeDevices: registryData.filter(d => d.status === 'active').length,
        avgRUL: calculateAvgRUL(registryData, snapshots),
        statusBreakdown: getStatusBreakdown(registryData)
      };
    }

    if (reportConfig.includeComparisons) {
      reportData.sections.comparisons = {
        byManufacturer: getComparisonByField(registryData, snapshots, 'manufacturer'),
        byChemistry: getComparisonByField(registryData, snapshots, 'battery_chemistry')
      };
    }

    if (reportConfig.includePredictive) {
      reportData.sections.predictive = {
        emergingPatterns: getEmergingPatterns(snapshots),
        riskTrend: getRiskTrend(snapshots)
      };
    }

    if (reportConfig.includeRawData) {
      reportData.rawData = {
        devices: registryData,
        snapshots: snapshots
      };
    }

    // Export based on format
    if (reportConfig.format === 'json') {
      downloadJSON(reportData, `fleet-analytics-${format(new Date(), 'yyyy-MM-dd')}.json`);
    } else if (reportConfig.format === 'csv') {
      downloadCSV(reportData);
    }

    setExporting(false);
    toast.success('Report exported successfully');
  };

  const downloadJSON = (data, filename) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadCSV = (data) => {
    let csv = 'Section,Metric,Value\n';
    
    Object.entries(data.sections).forEach(([section, metrics]) => {
      Object.entries(metrics).forEach(([key, value]) => {
        csv += `${section},${key},"${JSON.stringify(value)}"\n`;
      });
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fleet-analytics-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Download className="w-5 h-5 text-teal-400" />
          Export Analytics Report
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Report Sections */}
        <div className="space-y-3">
          <Label className="text-slate-400 text-sm">Include Sections</Label>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Checkbox
                id="fleet"
                checked={reportConfig.includeFleetMetrics}
                onCheckedChange={(checked) => setReportConfig({ ...reportConfig, includeFleetMetrics: checked })}
              />
              <Label htmlFor="fleet" className="text-white text-sm cursor-pointer">
                Fleet-Wide Metrics
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="compare"
                checked={reportConfig.includeComparisons}
                onCheckedChange={(checked) => setReportConfig({ ...reportConfig, includeComparisons: checked })}
              />
              <Label htmlFor="compare" className="text-white text-sm cursor-pointer">
                Comparative Analysis
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="predictive"
                checked={reportConfig.includePredictive}
                onCheckedChange={(checked) => setReportConfig({ ...reportConfig, includePredictive: checked })}
              />
              <Label htmlFor="predictive" className="text-white text-sm cursor-pointer">
                Predictive Analytics
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="raw"
                checked={reportConfig.includeRawData}
                onCheckedChange={(checked) => setReportConfig({ ...reportConfig, includeRawData: checked })}
              />
              <Label htmlFor="raw" className="text-white text-sm cursor-pointer">
                Raw Data (Full Dataset)
              </Label>
            </div>
          </div>
        </div>

        {/* Export Format */}
        <div>
          <Label className="text-slate-400 text-sm mb-2 block">Export Format</Label>
          <Select value={reportConfig.format} onValueChange={(value) => setReportConfig({ ...reportConfig, format: value })}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="json">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  JSON
                </div>
              </SelectItem>
              <SelectItem value="csv">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4" />
                  CSV
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Date Range */}
        <div>
          <Label className="text-slate-400 text-sm mb-2 block">Date Range</Label>
          <Select value={reportConfig.dateRange} onValueChange={(value) => setReportConfig({ ...reportConfig, dateRange: value })}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="last30">Last 30 Days</SelectItem>
              <SelectItem value="last90">Last 90 Days</SelectItem>
              <SelectItem value="last365">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Export Button */}
        <Button
          onClick={handleExport}
          disabled={exporting}
          className="w-full bg-teal-600 hover:bg-teal-700"
        >
          {exporting ? (
            <>Generating Report...</>
          ) : (
            <>
              <Download className="w-4 h-4 mr-2" />
              Export Report
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}

// Helper functions
function calculateAvgRUL(registryData, snapshots) {
  const activeDevices = registryData.filter(d => d.status === 'active');
  const rulValues = activeDevices.map(device => {
    const snapshot = snapshots.find(s => s.device_registry_id === device.id);
    return snapshot?.predicted_rul_days || 0;
  }).filter(v => v > 0);
  return rulValues.length ? Math.round(rulValues.reduce((a, b) => a + b, 0) / rulValues.length) : 0;
}

function getStatusBreakdown(registryData) {
  return registryData.reduce((acc, device) => {
    acc[device.status] = (acc[device.status] || 0) + 1;
    return acc;
  }, {});
}

function getComparisonByField(registryData, snapshots, field) {
  const groups = {};
  registryData.forEach(device => {
    const key = device[field];
    if (!groups[key]) groups[key] = { count: 0, totalRUL: 0, devices: 0 };
    groups[key].count++;
  });
  return groups;
}

function getEmergingPatterns(snapshots) {
  const patterns = {};
  snapshots.forEach(snapshot => {
    if (snapshot.anomaly_flags) {
      snapshot.anomaly_flags.forEach(flag => {
        patterns[flag] = (patterns[flag] || 0) + 1;
      });
    }
  });
  return patterns;
}

function getRiskTrend(snapshots) {
  const highRisk = snapshots.filter(s => s.risk_score >= 60).length;
  return snapshots.length > 0 ? ((highRisk / snapshots.length) * 100).toFixed(1) : 0;
}