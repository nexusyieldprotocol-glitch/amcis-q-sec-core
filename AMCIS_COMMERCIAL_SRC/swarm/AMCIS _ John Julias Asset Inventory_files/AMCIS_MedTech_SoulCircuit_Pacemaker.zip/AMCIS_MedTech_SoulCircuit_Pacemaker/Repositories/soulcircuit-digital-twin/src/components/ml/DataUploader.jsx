import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Upload, CheckCircle2, AlertTriangle, Activity, Database } from 'lucide-react';
import { toast } from 'sonner';

export default function DataUploader({ onUploadComplete }) {
  const queryClient = useQueryClient();
  const [uploadState, setUploadState] = useState({
    uploading: false,
    validating: false,
    importing: false,
    retraining: false,
    progress: 0,
    errors: [],
    recordsProcessed: 0
  });

  const uploadMutation = useMutation({
    mutationFn: async (file) => {
      setUploadState(prev => ({ ...prev, uploading: true, progress: 10, errors: [] }));

      // Step 1: Upload file
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadState(prev => ({ ...prev, progress: 30, validating: true, uploading: false }));

      // Step 2: Extract and validate data
      const jsonSchema = {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            prototype_id: { type: 'string' },
            battery_chemistry: { type: 'string' },
            time_series: { type: 'array' },
            final_state: { type: 'object' },
            actual_eol: { type: 'number' }
          },
          required: ['battery_chemistry']
        }
      };

      const extractResult = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: jsonSchema
      });

      if (extractResult.status === 'error') {
        throw new Error(extractResult.details || 'Failed to parse CSV file');
      }

      const rawData = extractResult.output;
      setUploadState(prev => ({ ...prev, progress: 50, validating: false, importing: true }));

      // Step 3: Validate and preprocess
      const validatedData = validateAndPreprocess(rawData);
      if (validatedData.errors.length > 0) {
        setUploadState(prev => ({ ...prev, errors: validatedData.errors, importing: false }));
        throw new Error(`Validation errors: ${validatedData.errors.join(', ')}`);
      }

      // Step 4: Bulk insert into MLTrainingData
      const insertPromises = validatedData.records.map(record => 
        base44.entities.MLTrainingData.create({
          ...record,
          timestamp: new Date().toISOString()
        })
      );

      await Promise.all(insertPromises);
      setUploadState(prev => ({ 
        ...prev, 
        progress: 80, 
        importing: false,
        retraining: true,
        recordsProcessed: validatedData.records.length 
      }));

      // Step 5: Trigger auto-retraining
      const retrainResult = await base44.functions.invoke('autoRetrainModels', {});
      setUploadState(prev => ({ ...prev, progress: 100, retraining: false }));

      return {
        recordsImported: validatedData.records.length,
        retrainResult
      };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries(['mlTrainingData']);
      queryClient.invalidateQueries(['mlModelVersions']);
      toast.success(`${result.recordsImported} records imported. ${result.retrainResult.message}`);
      onUploadComplete?.();
      resetState();
    },
    onError: (error) => {
      toast.error(error.message);
      setUploadState(prev => ({ 
        ...prev, 
        uploading: false, 
        validating: false, 
        importing: false,
        retraining: false 
      }));
    }
  });

  const resetState = () => {
    setTimeout(() => {
      setUploadState({
        uploading: false,
        validating: false,
        importing: false,
        retraining: false,
        progress: 0,
        errors: [],
        recordsProcessed: 0
      });
    }, 3000);
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast.error('Please upload a CSV file');
      return;
    }

    uploadMutation.mutate(file);
  };

  const isProcessing = uploadState.uploading || uploadState.validating || 
                       uploadState.importing || uploadState.retraining;

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Upload className="w-5 h-5 text-teal-400" />
          Upload Training Data
        </CardTitle>
        <CardDescription>
          Import real-world device data from CSV files
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Upload Status */}
        {isProcessing && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-300">
                {uploadState.uploading && 'Uploading file...'}
                {uploadState.validating && 'Validating data...'}
                {uploadState.importing && `Importing ${uploadState.recordsProcessed} records...`}
                {uploadState.retraining && 'Triggering model retraining...'}
              </span>
              <span className="text-teal-400 font-medium">{uploadState.progress}%</span>
            </div>
            <Progress value={uploadState.progress} className="h-2" />
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Activity className="w-3 h-3 animate-pulse" />
              <span>Processing pipeline active</span>
            </div>
          </div>
        )}

        {/* Errors */}
        {uploadState.errors.length > 0 && (
          <Alert className="bg-red-900/20 border-red-700/50">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <AlertDescription className="text-red-200">
              <strong>Validation Errors:</strong>
              <ul className="list-disc list-inside mt-2 text-xs">
                {uploadState.errors.map((error, idx) => (
                  <li key={idx}>{error}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}

        {/* Success */}
        {uploadState.progress === 100 && (
          <Alert className="bg-green-900/20 border-green-700/50">
            <CheckCircle2 className="w-4 h-4 text-green-400" />
            <AlertDescription className="text-green-200">
              Successfully imported {uploadState.recordsProcessed} training records!
            </AlertDescription>
          </Alert>
        )}

        {/* Upload Button */}
        <div className="border-2 border-dashed border-slate-700 rounded-lg p-6 text-center hover:border-teal-600 transition-colors">
          <input
            type="file"
            accept=".csv"
            onChange={handleFileSelect}
            disabled={isProcessing}
            className="hidden"
            id="csv-upload"
          />
          <label htmlFor="csv-upload" className="cursor-pointer">
            <Database className="w-12 h-12 mx-auto mb-3 text-slate-600" />
            <p className="text-white font-medium mb-1">
              {isProcessing ? 'Processing...' : 'Click to upload CSV'}
            </p>
            <p className="text-xs text-slate-500">
              Expected format: prototype_id, battery_chemistry, time_series, final_state, actual_eol
            </p>
          </label>
        </div>

        {/* Info */}
        <div className="bg-slate-800/30 rounded-lg p-3 text-xs text-slate-400">
          <p className="font-medium text-slate-300 mb-2">CSV Format Requirements:</p>
          <ul className="space-y-1 list-disc list-inside">
            <li>Required: battery_chemistry</li>
            <li>Optional: prototype_id, time_series (JSON array), final_state (JSON object), actual_eol</li>
            <li>Auto-retraining triggers when 10+ new records added</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}

function validateAndPreprocess(data) {
  const errors = [];
  const validRecords = [];

  if (!Array.isArray(data)) {
    return { errors: ['Data must be an array'], records: [] };
  }

  data.forEach((record, idx) => {
    // Required field validation
    if (!record.battery_chemistry) {
      errors.push(`Row ${idx + 1}: Missing required field 'battery_chemistry'`);
      return;
    }

    // Validate battery chemistry
    const validChemistries = ['Li-Ion', 'Li-CFx', 'Li-I2', 'SVO', 'Li-MnO2', 'Hybrid'];
    if (!validChemistries.includes(record.battery_chemistry)) {
      errors.push(`Row ${idx + 1}: Invalid battery_chemistry '${record.battery_chemistry}'`);
      return;
    }

    // Validate actual_eol if present
    if (record.actual_eol !== undefined && (typeof record.actual_eol !== 'number' || record.actual_eol <= 0)) {
      errors.push(`Row ${idx + 1}: Invalid actual_eol value`);
      return;
    }

    // Preprocess time_series
    let timeSeries = [];
    if (record.time_series) {
      try {
        timeSeries = typeof record.time_series === 'string' 
          ? JSON.parse(record.time_series) 
          : record.time_series;
        if (!Array.isArray(timeSeries)) {
          errors.push(`Row ${idx + 1}: time_series must be an array`);
          return;
        }
      } catch (e) {
        errors.push(`Row ${idx + 1}: Invalid JSON in time_series`);
        return;
      }
    }

    // Preprocess final_state
    let finalState = {};
    if (record.final_state) {
      try {
        finalState = typeof record.final_state === 'string' 
          ? JSON.parse(record.final_state) 
          : record.final_state;
      } catch (e) {
        errors.push(`Row ${idx + 1}: Invalid JSON in final_state`);
        return;
      }
    }

    // Add validated record
    validRecords.push({
      prototype_id: record.prototype_id || 'imported',
      battery_chemistry: record.battery_chemistry,
      time_series: timeSeries,
      final_state: finalState,
      actual_eol: record.actual_eol || null,
      simulation_config: record.simulation_config || {}
    });
  });

  return {
    errors: errors.slice(0, 10), // Limit to first 10 errors
    records: validRecords
  };
}