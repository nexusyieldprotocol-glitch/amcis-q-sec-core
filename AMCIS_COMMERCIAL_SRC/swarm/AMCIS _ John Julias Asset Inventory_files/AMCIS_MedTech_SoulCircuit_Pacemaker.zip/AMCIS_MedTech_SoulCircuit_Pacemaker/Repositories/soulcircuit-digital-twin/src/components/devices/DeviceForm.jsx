import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Save, X } from 'lucide-react';
import { toast } from 'sonner';

export default function DeviceForm({ device, onSuccess, onCancel }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    device_id: device?.device_id || '',
    patient_id: device?.patient_id || '',
    manufacturer: device?.manufacturer || 'Medtronic',
    model: device?.model || '',
    implant_date: device?.implant_date || '',
    battery_chemistry: device?.battery_chemistry || 'Li-I2',
    initial_capacity_mah: device?.initial_capacity_mah || 0,
    pacing_mode: device?.pacing_mode || 'DDD',
    pacing_percentage: device?.pacing_percentage || 0,
    lead_impedance_ohms: device?.lead_impedance_ohms || 0,
    status: device?.status || 'active',
    clinical_study_id: device?.clinical_study_id || '',
    cohort_name: device?.cohort_name || '',
    site_location: device?.site_location || '',
    energy_harvesting_enabled: device?.energy_harvesting_enabled || false,
    revision_flag: device?.revision_flag || false,
    revision_reason: device?.revision_reason || 'none',
    notes: device?.notes || ''
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (device) {
        return base44.entities.DeviceRegistry.update(device.id, data);
      } else {
        return base44.entities.DeviceRegistry.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['deviceRegistry']);
      toast.success(device ? 'Device updated successfully' : 'Device added successfully');
      onSuccess();
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to save device');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white">
          {device ? 'Edit Device' : 'Add New Device'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-white">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="device_id" className="text-slate-300">Device ID *</Label>
                <Input
                  id="device_id"
                  value={formData.device_id}
                  onChange={(e) => updateField('device_id', e.target.value)}
                  required
                  className="bg-slate-800 border-slate-700"
                  placeholder="Serial number"
                />
              </div>
              <div>
                <Label htmlFor="patient_id" className="text-slate-300">Patient ID</Label>
                <Input
                  id="patient_id"
                  value={formData.patient_id}
                  onChange={(e) => updateField('patient_id', e.target.value)}
                  className="bg-slate-800 border-slate-700"
                  placeholder="De-identified patient ID"
                />
              </div>
              <div>
                <Label htmlFor="manufacturer" className="text-slate-300">Manufacturer *</Label>
                <Select value={formData.manufacturer} onValueChange={(v) => updateField('manufacturer', v)}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Medtronic">Medtronic</SelectItem>
                    <SelectItem value="Abbott">Abbott</SelectItem>
                    <SelectItem value="Boston Scientific">Boston Scientific</SelectItem>
                    <SelectItem value="Biotronik">Biotronik</SelectItem>
                    <SelectItem value="Base44 Labs">Base44 Labs</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="model" className="text-slate-300">Model *</Label>
                <Input
                  id="model"
                  value={formData.model}
                  onChange={(e) => updateField('model', e.target.value)}
                  required
                  className="bg-slate-800 border-slate-700"
                />
              </div>
              <div>
                <Label htmlFor="implant_date" className="text-slate-300">Implant Date *</Label>
                <Input
                  id="implant_date"
                  type="date"
                  value={formData.implant_date}
                  onChange={(e) => updateField('implant_date', e.target.value)}
                  required
                  className="bg-slate-800 border-slate-700"
                />
              </div>
              <div>
                <Label htmlFor="status" className="text-slate-300">Status</Label>
                <Select value={formData.status} onValueChange={(v) => updateField('status', v)}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="eri">ERI</SelectItem>
                    <SelectItem value="eol">EOL</SelectItem>
                    <SelectItem value="explanted">Explanted</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="monitoring">Monitoring</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Device Configuration */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-white">Device Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="battery_chemistry" className="text-slate-300">Battery Chemistry *</Label>
                <Select value={formData.battery_chemistry} onValueChange={(v) => updateField('battery_chemistry', v)}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Li-I2">Li-I2</SelectItem>
                    <SelectItem value="Li-CFx">Li-CFx</SelectItem>
                    <SelectItem value="Li-MnO2">Li-MnO2</SelectItem>
                    <SelectItem value="SVO">SVO</SelectItem>
                    <SelectItem value="Hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="initial_capacity_mah" className="text-slate-300">Capacity (mAh)</Label>
                <Input
                  id="initial_capacity_mah"
                  type="number"
                  value={formData.initial_capacity_mah}
                  onChange={(e) => updateField('initial_capacity_mah', parseFloat(e.target.value))}
                  className="bg-slate-800 border-slate-700"
                />
              </div>
              <div>
                <Label htmlFor="pacing_mode" className="text-slate-300">Pacing Mode</Label>
                <Select value={formData.pacing_mode} onValueChange={(v) => updateField('pacing_mode', v)}>
                  <SelectTrigger className="bg-slate-800 border-slate-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="VVI">VVI</SelectItem>
                    <SelectItem value="VVIR">VVIR</SelectItem>
                    <SelectItem value="DDD">DDD</SelectItem>
                    <SelectItem value="DDDR">DDDR</SelectItem>
                    <SelectItem value="AAI">AAI</SelectItem>
                    <SelectItem value="CRT">CRT</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="pacing_percentage" className="text-slate-300">Pacing %</Label>
                <Input
                  id="pacing_percentage"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.pacing_percentage}
                  onChange={(e) => updateField('pacing_percentage', parseFloat(e.target.value))}
                  className="bg-slate-800 border-slate-700"
                />
              </div>
              <div>
                <Label htmlFor="lead_impedance_ohms" className="text-slate-300">Lead Impedance (Ω)</Label>
                <Input
                  id="lead_impedance_ohms"
                  type="number"
                  value={formData.lead_impedance_ohms}
                  onChange={(e) => updateField('lead_impedance_ohms', parseFloat(e.target.value))}
                  className="bg-slate-800 border-slate-700"
                />
              </div>
            </div>
          </div>

          {/* Clinical Study & Cohort */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-white">Clinical Classification</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="clinical_study_id" className="text-slate-300">Clinical Study ID</Label>
                <Input
                  id="clinical_study_id"
                  value={formData.clinical_study_id}
                  onChange={(e) => updateField('clinical_study_id', e.target.value)}
                  className="bg-slate-800 border-slate-700"
                  placeholder="e.g., STUDY-2024-001"
                />
              </div>
              <div>
                <Label htmlFor="cohort_name" className="text-slate-300">Cohort Name</Label>
                <Input
                  id="cohort_name"
                  value={formData.cohort_name}
                  onChange={(e) => updateField('cohort_name', e.target.value)}
                  className="bg-slate-800 border-slate-700"
                  placeholder="e.g., High Risk"
                />
              </div>
              <div>
                <Label htmlFor="site_location" className="text-slate-300">Site Location</Label>
                <Input
                  id="site_location"
                  value={formData.site_location}
                  onChange={(e) => updateField('site_location', e.target.value)}
                  className="bg-slate-800 border-slate-700"
                  placeholder="Hospital/clinic"
                />
              </div>
            </div>
          </div>

          {/* Switches */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="energy_harvesting" className="text-slate-300">Energy Harvesting Enabled</Label>
              <Switch
                id="energy_harvesting"
                checked={formData.energy_harvesting_enabled}
                onCheckedChange={(checked) => updateField('energy_harvesting_enabled', checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="revision_flag" className="text-slate-300">Revision Required</Label>
              <Switch
                id="revision_flag"
                checked={formData.revision_flag}
                onCheckedChange={(checked) => updateField('revision_flag', checked)}
              />
            </div>
          </div>

          {formData.revision_flag && (
            <div>
              <Label htmlFor="revision_reason" className="text-slate-300">Revision Reason</Label>
              <Select value={formData.revision_reason} onValueChange={(v) => updateField('revision_reason', v)}>
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="infection">Infection</SelectItem>
                  <SelectItem value="lead_failure">Lead Failure</SelectItem>
                  <SelectItem value="battery_depletion">Battery Depletion</SelectItem>
                  <SelectItem value="malfunction">Malfunction</SelectItem>
                  <SelectItem value="upgrade">Upgrade</SelectItem>
                  <SelectItem value="none">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Notes */}
          <div>
            <Label htmlFor="notes" className="text-slate-300">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => updateField('notes', e.target.value)}
              className="bg-slate-800 border-slate-700"
              rows={3}
              placeholder="Additional clinical notes..."
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 justify-end">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="border-slate-700"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={saveMutation.isPending}
              className="bg-teal-600 hover:bg-teal-700"
            >
              <Save className="w-4 h-4 mr-2" />
              {saveMutation.isPending ? 'Saving...' : device ? 'Update Device' : 'Add Device'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}