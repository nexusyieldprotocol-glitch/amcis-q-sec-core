import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Activity, 
  Zap, 
  Gauge,
  Radio,
  Timer,
  TrendingDown,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';

/**
 * Engineering Metrics Validation Component
 * Displays digital twin minimum viable parameter set for FDA-credible validation
 */
export default function EngineeringMetrics({ simulation, prototype }) {
  if (!simulation || !simulation.finalState) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-slate-200 text-sm">Engineering Validation Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-500">Run simulation to view validation metrics</p>
        </CardContent>
      </Card>
    );
  }

  const { finalState, timeSeries, config } = simulation;

  // 1. Beat-by-beat energy consumption
  const avgEnergyPerBeat = timeSeries.reduce((sum, point) => sum + (point.energyDelivered || 0), 0) / timeSeries.length;
  
  // 2. Harvester stochastic output
  const avgHarvestedPower = timeSeries
    .filter(p => p.harvestedEnergy > 0)
    .reduce((sum, p) => sum + p.harvestedEnergy, 0) / timeSeries.length * 1000; // µW

  // 3. Battery impedance growth (Arrhenius aging)
  const impedanceGrowthPercent = ((finalState.internalResistance / prototype.internal_resistance_ohms) - 1) * 100;

  // 4. Capture threshold drift (simulated from voltage stability)
  const voltageStability = 1 - (Math.abs(finalState.voltage - prototype.nominal_voltage) / prototype.nominal_voltage);
  const captureSafetyMargin = voltageStability > 0.85 ? 'adequate' : 'degraded';

  // 5. Telemetry burst modeling
  const telemetryEnergy = timeSeries.reduce((sum, point) => sum + (point.telemetryEnergy || 0), 0);

  // 6. Safety margin depletion
  const socSafetyMargin = finalState.soc > 0.3 ? 'safe' : finalState.soc > 0.15 ? 'caution' : 'critical';

  // FDA-credible lifetime validation
  const meetsLifetimeTarget = finalState.elapsedYears >= (prototype.expected_lifetime_years * 0.8);
  const thermalCompliant = finalState.maxTemperature <= 39.0;
  const voltageCompliant = finalState.voltage >= prototype.nominal_voltage * 0.7;

  const validationPassed = meetsLifetimeTarget && thermalCompliant && voltageCompliant;

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Gauge className="w-4 h-4 text-blue-400" />
            Engineering Validation Metrics
          </CardTitle>
          <Badge 
            variant="outline" 
            className={`${validationPassed ? 'border-green-500/50 text-green-400' : 'border-yellow-500/50 text-yellow-400'}`}
          >
            {validationPassed ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <AlertCircle className="w-3 h-3 mr-1" />}
            {validationPassed ? 'Validated' : 'Needs Review'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Core Digital Twin Parameters */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Activity className="w-3 h-3" />
              <span>Beat-by-beat energy</span>
            </div>
            <span className="font-mono text-slate-200">{avgEnergyPerBeat.toFixed(2)} µJ</span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Zap className="w-3 h-3" />
              <span>Harvester output (avg)</span>
            </div>
            <span className="font-mono text-slate-200">
              {prototype.energy_harvesting_enabled ? `${avgHarvestedPower.toFixed(1)} µW` : 'N/A'}
            </span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <TrendingDown className="w-3 h-3" />
              <span>Impedance growth</span>
            </div>
            <span className="font-mono text-slate-200">+{impedanceGrowthPercent.toFixed(1)}%</span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Gauge className="w-3 h-3" />
              <span>Capture safety margin</span>
            </div>
            <Badge 
              variant="outline" 
              className={`text-xs ${
                captureSafetyMargin === 'adequate' 
                  ? 'border-green-500/50 text-green-400'
                  : 'border-yellow-500/50 text-yellow-400'
              }`}
            >
              {captureSafetyMargin}
            </Badge>
          </div>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Radio className="w-3 h-3" />
              <span>Telemetry energy total</span>
            </div>
            <span className="font-mono text-slate-200">{telemetryEnergy.toFixed(3)} mAh</span>
          </div>

          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Timer className="w-3 h-3" />
              <span>Safety margin depletion</span>
            </div>
            <Badge 
              variant="outline" 
              className={`text-xs ${
                socSafetyMargin === 'safe' 
                  ? 'border-green-500/50 text-green-400'
                  : socSafetyMargin === 'caution'
                    ? 'border-yellow-500/50 text-yellow-400'
                    : 'border-red-500/50 text-red-400'
              }`}
            >
              {socSafetyMargin}
            </Badge>
          </div>
        </div>

        <Separator className="bg-slate-700/50" />

        {/* FDA-Credible Validation Checks */}
        <div>
          <h4 className="text-xs font-semibold text-slate-400 mb-3">FDA-Credible Validation</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Lifetime target (≥80%)</span>
              <Badge 
                variant="outline" 
                className={`text-[10px] ${meetsLifetimeTarget ? 'border-green-500/50 text-green-400' : 'border-red-500/50 text-red-400'}`}
              >
                {meetsLifetimeTarget ? 'PASS' : 'FAIL'} ({finalState.elapsedYears.toFixed(1)}y)
              </Badge>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Thermal compliance (≤39°C)</span>
              <Badge 
                variant="outline" 
                className={`text-[10px] ${thermalCompliant ? 'border-green-500/50 text-green-400' : 'border-red-500/50 text-red-400'}`}
              >
                {thermalCompliant ? 'PASS' : 'FAIL'} ({finalState.maxTemperature.toFixed(1)}°C)
              </Badge>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500">Voltage margin (≥70%)</span>
              <Badge 
                variant="outline" 
                className={`text-[10px] ${voltageCompliant ? 'border-green-500/50 text-green-400' : 'border-red-500/50 text-red-400'}`}
              >
                {voltageCompliant ? 'PASS' : 'FAIL'} ({finalState.voltage.toFixed(2)}V)
              </Badge>
            </div>
          </div>
        </div>

        {/* Engineering Reality Notes */}
        <div className="p-3 rounded-lg bg-slate-800/50 border border-blue-500/20">
          <p className="text-[10px] text-slate-500 leading-relaxed">
            <strong className="text-blue-400">Engineering Note:</strong> Metrics derived from FDA PMA summaries, 
            clinical papers, and ISO 14708-1 test disclosures. 30-year leadless target requires hybrid 
            harvesting + ultra-stable primary storage (feasibility window: 2030-2035).
          </p>
        </div>
      </CardContent>
    </Card>
  );
}