import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Zap,
  Activity,
  RefreshCw,
  Sparkles,
  Database,
  Target
} from 'lucide-react';

export default function MLPredictionPanel({ 
  mlPredictions, 
  isMLEnabled,
  trainingDataCount,
  onTrain,
  isTraining,
  trainingProgress
}) {
  const [showDetails, setShowDetails] = useState(false);

  if (!isMLEnabled) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400" />
            ML Predictions (Not Available)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-6">
            <Brain className="w-12 h-12 text-slate-600 mx-auto mb-3 opacity-50" />
            <p className="text-sm text-slate-500 mb-2">ML models not trained yet</p>
            <p className="text-xs text-slate-600 mb-4">
              Run simulations to collect training data
            </p>
            <Badge variant="outline" className="border-slate-600 text-slate-500">
              <Database className="w-3 h-3 mr-1" />
              {trainingDataCount || 0} simulations collected
            </Badge>
          </div>
          
          {trainingDataCount >= 5 && (
            <Button
              onClick={onTrain}
              disabled={isTraining}
              className="w-full bg-purple-600 hover:bg-purple-500 text-white"
            >
              {isTraining ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Training Models...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Train ML Models
                </>
              )}
            </Button>
          )}

          {trainingDataCount < 5 && (
            <div className="text-center text-xs text-slate-600">
              Need {5 - (trainingDataCount || 0)} more simulations to start training
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  const { eolPrediction, failurePredictions, topRisks } = mlPredictions || {};

  return (
    <Card className="bg-gradient-to-br from-purple-900/20 to-slate-900/50 border-purple-500/30 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-400" />
            ML-Powered Analytics
          </CardTitle>
          <Badge variant="outline" className="border-purple-500/50 text-purple-400">
            <Sparkles className="w-3 h-3 mr-1" />
            LSTM
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* EOL Prediction */}
        {eolPrediction && (
          <div className="p-3 rounded-lg bg-slate-800/50 border border-purple-500/20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Target className="w-3 h-3" />
                Predicted EOL (LSTM)
              </span>
              <Badge 
                variant="outline" 
                className={`text-[10px] ${
                  eolPrediction.confidence > 0.8 
                    ? 'border-green-500/50 text-green-400'
                    : eolPrediction.confidence > 0.6
                      ? 'border-yellow-500/50 text-yellow-400'
                      : 'border-orange-500/50 text-orange-400'
                }`}
              >
                {(eolPrediction.confidence * 100).toFixed(0)}% confidence
              </Badge>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-purple-400">
                {eolPrediction.predictedEOL.toFixed(1)}
              </span>
              <span className="text-xs text-slate-500">years</span>
            </div>
          </div>
        )}

        <Separator className="bg-slate-700/50" />

        {/* Top Failure Risks */}
        {topRisks && topRisks.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-slate-400 font-medium">Top Failure Risks</span>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 text-xs text-slate-500 hover:text-slate-300"
                onClick={() => setShowDetails(!showDetails)}
              >
                {showDetails ? 'Hide' : 'Show'} Details
              </Button>
            </div>
            
            <div className="space-y-2">
              {topRisks.map((risk, idx) => {
                const Icon = risk.risk === 'high' ? AlertTriangle : Activity;
                const colorClass = risk.risk === 'high' 
                  ? 'border-red-500/50 bg-red-500/10'
                  : risk.risk === 'medium'
                    ? 'border-yellow-500/50 bg-yellow-500/10'
                    : 'border-blue-500/50 bg-blue-500/10';
                
                return (
                  <div key={risk.mode} className={`p-2 rounded-lg border ${colorClass}`}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <Icon className="w-3 h-3" />
                        <span className="text-xs font-medium text-slate-200">
                          {risk.mode.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </span>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={`text-[10px] ${
                          risk.risk === 'high' 
                            ? 'border-red-500/50 text-red-400'
                            : risk.risk === 'medium'
                              ? 'border-yellow-500/50 text-yellow-400'
                              : 'border-blue-500/50 text-blue-400'
                        }`}
                      >
                        {(risk.probability * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <Progress 
                      value={risk.probability * 100} 
                      className="h-1"
                    />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Detailed Failure Predictions */}
        {showDetails && failurePredictions && (
          <ScrollArea className="h-48">
            <div className="space-y-2 pr-4">
              {Object.entries(failurePredictions).map(([mode, pred]) => (
                <div key={mode} className="p-2 rounded bg-slate-800/30 border border-slate-700/50">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      {mode.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-300">{(pred.probability * 100).toFixed(1)}%</span>
                      <Badge 
                        variant="outline" 
                        className={`text-[9px] ${
                          pred.confidence === 'high' 
                            ? 'border-green-500/50 text-green-400'
                            : pred.confidence === 'medium'
                              ? 'border-yellow-500/50 text-yellow-400'
                              : 'border-slate-600 text-slate-500'
                        }`}
                      >
                        {pred.confidence}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        <Separator className="bg-slate-700/50" />

        {/* Training Info */}
        <div className="flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1">
            <Database className="w-3 h-3" />
            <span>Trained on {trainingDataCount} simulations</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onTrain}
            disabled={isTraining}
            className="h-6 text-xs hover:text-purple-400"
          >
            {isTraining ? (
              <RefreshCw className="w-3 h-3 animate-spin" />
            ) : (
              <RefreshCw className="w-3 h-3" />
            )}
          </Button>
        </div>

        {isTraining && trainingProgress && (
          <div className="space-y-2">
            <Progress value={trainingProgress.overall || 0} className="h-1" />
            <p className="text-xs text-slate-500 text-center">
              {trainingProgress.status}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}