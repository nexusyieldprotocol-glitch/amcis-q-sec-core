import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Area, ComposedChart } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Battery, Zap } from 'lucide-react';

export default function VoltageChart({ data, prototype, cutoffVoltage }) {
  if (!data || data.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Battery className="w-4 h-4 text-teal-400" />
            Battery Voltage
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64 flex items-center justify-center">
          <p className="text-slate-500 text-sm">Run simulation to view data</p>
        </CardContent>
      </Card>
    );
  }

  const chartData = data.map(d => ({
    years: d.years.toFixed(2),
    voltage: d.voltage,
    soc: d.soc * 100
  }));

  const currentVoltage = chartData[chartData.length - 1]?.voltage || 0;
  const nominalVoltage = prototype?.nominal_voltage || 3.0;
  const voltageHealth = currentVoltage / nominalVoltage * 100;

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Battery className="w-4 h-4 text-teal-400" />
            Battery Voltage Profile
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={`text-xs ${voltageHealth > 80 ? 'border-green-500/50 text-green-400' : voltageHealth > 60 ? 'border-yellow-500/50 text-yellow-400' : 'border-red-500/50 text-red-400'}`}>
              {currentVoltage.toFixed(3)}V
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="voltageGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#14B8A6" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#14B8A6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis 
                dataKey="years" 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
                label={{ value: 'Years', position: 'bottom', fill: '#64748B', fontSize: 10 }}
              />
              <YAxis 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
                domain={[cutoffVoltage ? cutoffVoltage - 0.5 : 'auto', 'auto']}
                label={{ value: 'Voltage (V)', angle: -90, position: 'insideLeft', fill: '#64748B', fontSize: 10 }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1E293B', 
                  border: '1px solid #334155',
                  borderRadius: '8px',
                  boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.3)'
                }}
                labelStyle={{ color: '#94A3B8' }}
                itemStyle={{ color: '#14B8A6' }}
                formatter={(value, name) => [value.toFixed(3) + 'V', 'Voltage']}
                labelFormatter={(label) => `Year ${label}`}
              />
              {cutoffVoltage && (
                <ReferenceLine 
                  y={cutoffVoltage} 
                  stroke="#EF4444" 
                  strokeDasharray="5 5"
                  label={{ value: 'EOL', fill: '#EF4444', fontSize: 10, position: 'right' }}
                />
              )}
              <Area
                type="monotone"
                dataKey="voltage"
                fill="url(#voltageGradient)"
                stroke="none"
              />
              <Line 
                type="monotone" 
                dataKey="voltage" 
                stroke="#14B8A6" 
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: '#14B8A6', stroke: '#0F172A', strokeWidth: 2 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}