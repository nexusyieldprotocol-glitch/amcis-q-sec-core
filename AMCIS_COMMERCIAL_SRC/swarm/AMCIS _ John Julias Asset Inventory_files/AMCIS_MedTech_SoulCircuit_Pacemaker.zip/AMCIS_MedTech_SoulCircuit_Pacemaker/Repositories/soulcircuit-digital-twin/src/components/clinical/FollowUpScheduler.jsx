import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export default function FollowUpScheduler({ patient, isOpen, onClose }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    scheduled_date: '',
    appointment_type: 'routine',
    priority: 'medium',
    reason: '',
    notes: ''
  });

  const createAppointment = useMutation({
    mutationFn: (data) => base44.entities.FollowUpAppointment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['followUpAppointments']);
      toast.success('Follow-up appointment scheduled');
      onClose?.();
      resetForm();
    },
    onError: (error) => {
      toast.error('Failed to schedule appointment');
      console.error(error);
    }
  });

  const resetForm = () => {
    setFormData({
      scheduled_date: '',
      appointment_type: 'routine',
      priority: 'medium',
      reason: '',
      notes: ''
    });
  };

  const handleSchedule = () => {
    if (!formData.scheduled_date) {
      toast.error('Please select a date and time');
      return;
    }

    const appointmentData = {
      device_registry_id: patient.id,
      patient_id: patient.patient_id,
      scheduled_date: new Date(formData.scheduled_date).toISOString(),
      appointment_type: formData.appointment_type,
      priority: formData.priority,
      risk_score: patient.risk_score,
      predicted_rul_days: patient.predicted_rul_days,
      reason: formData.reason || getDefaultReason(formData.appointment_type, patient),
      notes: formData.notes,
      status: 'scheduled'
    };

    createAppointment.mutate(appointmentData);
  };

  const suggestAppointmentDate = () => {
    const suggestedDate = new Date();
    
    // Suggest based on risk and RUL
    if (patient.risk_score >= 80 || patient.predicted_rul_days < 90) {
      suggestedDate.setDate(suggestedDate.getDate() + 7); // 1 week
      setFormData(prev => ({ 
        ...prev, 
        appointment_type: 'urgent',
        priority: 'critical'
      }));
    } else if (patient.risk_score >= 60 || patient.predicted_rul_days < 180) {
      suggestedDate.setDate(suggestedDate.getDate() + 14); // 2 weeks
      setFormData(prev => ({ 
        ...prev, 
        appointment_type: 'risk_assessment',
        priority: 'high'
      }));
    } else if (patient.status === 'eri') {
      suggestedDate.setDate(suggestedDate.getDate() + 30); // 1 month
      setFormData(prev => ({ 
        ...prev, 
        appointment_type: 'eri_check',
        priority: 'medium'
      }));
    } else {
      suggestedDate.setDate(suggestedDate.getDate() + 90); // 3 months
    }

    suggestedDate.setHours(9, 0, 0, 0); // Set to 9 AM
    const dateTimeString = suggestedDate.toISOString().slice(0, 16);
    setFormData(prev => ({ ...prev, scheduled_date: dateTimeString }));
  };

  if (!patient) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5 text-teal-400" />
            Schedule Follow-Up
          </DialogTitle>
          <DialogDescription>
            Schedule appointment for patient {patient.patient_id}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Patient Info Summary */}
          <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-400">Risk Score:</span>
                <span className="text-white font-medium ml-2">{patient.risk_score}/100</span>
              </div>
              <div>
                <span className="text-slate-400">RUL:</span>
                <span className="text-white font-medium ml-2">{patient.predicted_rul_days} days</span>
              </div>
            </div>
          </div>

          {/* AI Suggestion */}
          <Button
            variant="outline"
            onClick={suggestAppointmentDate}
            className="w-full border-teal-700/50 text-teal-400 hover:bg-teal-900/20"
          >
            <AlertCircle className="w-4 h-4 mr-2" />
            Suggest Based on Risk Profile
          </Button>

          {/* Date/Time */}
          <div>
            <Label className="text-slate-400 text-sm">Date & Time</Label>
            <Input
              type="datetime-local"
              value={formData.scheduled_date}
              onChange={(e) => setFormData({ ...formData, scheduled_date: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white mt-1"
            />
          </div>

          {/* Appointment Type */}
          <div>
            <Label className="text-slate-400 text-sm">Appointment Type</Label>
            <Select value={formData.appointment_type} onValueChange={(value) => setFormData({ ...formData, appointment_type: value })}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="routine">Routine Check-up</SelectItem>
                <SelectItem value="eri_check">ERI Assessment</SelectItem>
                <SelectItem value="urgent">Urgent Evaluation</SelectItem>
                <SelectItem value="eol_replacement">EOL Replacement Consult</SelectItem>
                <SelectItem value="risk_assessment">Risk Assessment</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Priority */}
          <div>
            <Label className="text-slate-400 text-sm">Priority</Label>
            <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value })}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Reason */}
          <div>
            <Label className="text-slate-400 text-sm">Reason</Label>
            <Input
              placeholder="e.g., Elevated risk score, declining battery voltage"
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white mt-1"
            />
          </div>

          {/* Notes */}
          <div>
            <Label className="text-slate-400 text-sm">Clinical Notes</Label>
            <Textarea
              placeholder="Additional notes or instructions..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white h-20 mt-1"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-slate-700">
            Cancel
          </Button>
          <Button
            onClick={handleSchedule}
            disabled={createAppointment.isPending}
            className="bg-teal-600 hover:bg-teal-700"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" />
            {createAppointment.isPending ? 'Scheduling...' : 'Schedule Appointment'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function getDefaultReason(appointmentType, patient) {
  switch (appointmentType) {
    case 'urgent':
      return `High risk score (${patient.risk_score}/100) requiring urgent evaluation`;
    case 'eri_check':
      return 'Device approaching elective replacement indicator';
    case 'eol_replacement':
      return `Device nearing end of life (RUL: ${patient.predicted_rul_days} days)`;
    case 'risk_assessment':
      return `Elevated risk profile - comprehensive assessment needed`;
    default:
      return 'Routine follow-up examination';
  }
}