import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  Download, 
  Copy, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  Thermometer,
  Battery,
  Zap
} from 'lucide-react';
import { generateReport } from '../simulation/SimulationEngine';

export default function ReportGenerator({ simulation, prototype }) {
  const [copied, setCopied] = useState(false);
  const [report, setReport] = useState(null);

  const handleGenerateReport = () => {
    if (!simulation || !prototype) return;
    
    const reportData = {
      metadata: {
        generatedAt: new Date().toISOString(),
        prototypeName: prototype.name,
        manufacturer: prototype.manufacturer,
        simulationDuration: simulation.finalState?.elapsedYears || 0
      },
      configuration: simulation.config,
      results: {
        finalVoltage: (simulation.finalState?.voltage || 0).toFixed(3) + 'V',
        finalSOC: ((simulation.finalState?.soc || 0) * 100).toFixed(1) + '%',
        capacityRemaining: (simulation.finalState?.capacityRemaining || 0).toFixed(2) + ' mAh',
        totalPaces: Math.round(simulation.finalState?.totalPaces || 0),
        energyDelivered: (simulation.finalState?.energyDelivered || 0).toFixed(2) + ' J',
        totalHarvestedEnergy: (simulation.finalState?.totalHarvestedEnergy || 0).toFixed(2) + ' mAh',
        maxTemperature: (simulation.finalState?.maxTemperature || 37).toFixed(1) + '°C',
        predictedEOL: simulation.predictedEOL ? simulation.predictedEOL().toFixed(1) + ' years' : 'N/A'
      },
      thermalCompliance: {
        level: simulation.finalState?.maxTemperature <= 39 ? 'normal' : 
               simulation.finalState?.maxTemperature <= 41 ? 'elevated' : 'warning',
        compliant: simulation.finalState?.maxTemperature <= 41
      },
      failures: simulation.finalState?.failures || [],
      prototypeConfig: {
        battery_chemistry: prototype.battery_chemistry,
        energy_capacity_mah: prototype.energy_capacity_mah,
        nominal_voltage: prototype.nominal_voltage,
        internal_resistance_ohms: prototype.internal_resistance_ohms,
        energy_harvesting_enabled: prototype.energy_harvesting_enabled,
        harvesting_type: prototype.harvesting_type,
        supercapacitor_enabled: prototype.supercapacitor_enabled
      }
    };
    
    setReport(reportData);
  };

  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(report, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadJSON = () => {
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `simulation-report-${prototype?.name?.replace(/\s+/g, '-').toLowerCase()}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadCSV = () => {
    if (!simulation?.timeSeries) return;
    
    const headers = ['Year', 'Voltage (V)', 'SOC (%)', 'Temperature (°C)', 'Resistance (Ω)', 'Capacity (mAh)'];
    const rows = simulation.timeSeries.map(d => [
      d.years.toFixed(3),
      d.voltage.toFixed(4),
      (d.soc * 100).toFixed(2),
      d.temperature.toFixed(2),
      d.internalResistance.toFixed(2),
      d.capacityRemaining.toFixed(2)
    ]);
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `simulation-timeseries-${prototype?.name?.replace(/\s+/g, '-').toLowerCase()}-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="border-slate-600 text-slate-300 hover:bg-slate-800"
          disabled={!simulation || !prototype}
          onClick={handleGenerateReport}
        >
          <FileText className="w-4 h-4 mr-2" />
          Generate Report
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl bg-slate-900 border-slate-700 text-slate-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-400" />
            Simulation Report - {prototype?.name}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh]">
          {report && (
            <div className="space-y-4 p-1">
              {/* Metadata */}
              <div className="p-4 rounded-lg bg-slate-800/50">
                <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Report Metadata
                </h3>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <p className="text-slate-500">Generated</p>
                    <p className="text-slate-300">{new Date(report.metadata.generatedAt).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Prototype</p>
                    <p className="text-slate-300">{report.metadata.prototypeName}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Manufacturer</p>
                    <p className="text-slate-300">{report.metadata.manufacturer}</p>
                  </div>
                  <div>
                    <p className="text-slate-500">Simulation Duration</p>
                    <p className="text-slate-300">{report.metadata.simulationDuration.toFixed(2)} years</p>
                  </div>
                </div>
              </div>

              {/* Results Summary */}
              <div className="p-4 rounded-lg bg-slate-800/50">
                <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                  <Battery className="w-4 h-4" />
                  Simulation Results
                </h3>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  {Object.entries(report.results).map(([key, value]) => (
                    <div key={key}>
                      <p className="text-slate-500">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</p>
                      <p className="text-slate-300 font-medium">{value}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Thermal Compliance */}
              <div className="p-4 rounded-lg bg-slate-800/50">
                <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                  <Thermometer className="w-4 h-4" />
                  ISO 14708-1 Thermal Compliance
                </h3>
                <div className="flex items-center gap-3">
                  <Badge 
                    variant="outline" 
                    className={`${
                      report.thermalCompliance.compliant 
                        ? 'border-green-500/50 text-green-400' 
                        : 'border-red-500/50 text-red-400'
                    }`}
                  >
                    {report.thermalCompliance.compliant ? (
                      <><CheckCircle className="w-3 h-3 mr-1" /> Compliant</>
                    ) : (
                      <><AlertTriangle className="w-3 h-3 mr-1" /> Non-Compliant</>
                    )}
                  </Badge>
                  <span className="text-xs text-slate-400">
                    Thermal Level: {report.thermalCompliance.level}
                  </span>
                </div>
              </div>

              {/* Failure Events */}
              {report.failures.length > 0 && (
                <div className="p-4 rounded-lg bg-slate-800/50">
                  <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-yellow-400" />
                    Failure Events
                  </h3>
                  <div className="space-y-2">
                    {report.failures.map((f, idx) => (
                      <div key={idx} className="p-2 rounded bg-red-500/10 border border-red-500/30 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="text-red-400 font-medium">{f.name}</span>
                          <Badge variant="outline" className="text-[10px] border-red-500/50 text-red-400">
                            {f.severity}
                          </Badge>
                        </div>
                        <p className="text-slate-500 mt-1">Detected at year {f.detectedAt?.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Configuration JSON */}
              <div className="p-4 rounded-lg bg-slate-800/50">
                <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Configuration (JSON)
                </h3>
                <pre className="text-xs text-slate-400 bg-slate-950/50 p-3 rounded overflow-x-auto">
                  {JSON.stringify(report.prototypeConfig, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </ScrollArea>

        <Separator className="bg-slate-700" />

        {/* Export Actions */}
        <div className="flex gap-2 justify-end">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopyJSON}
            className="border-slate-600 text-slate-300 hover:bg-slate-800"
          >
            {copied ? <CheckCircle className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            {copied ? 'Copied!' : 'Copy JSON'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadCSV}
            disabled={!simulation?.timeSeries}
            className="border-slate-600 text-slate-300 hover:bg-slate-800"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button
            size="sm"
            onClick={handleDownloadJSON}
            className="bg-teal-600 hover:bg-teal-500 text-white"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Report
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}