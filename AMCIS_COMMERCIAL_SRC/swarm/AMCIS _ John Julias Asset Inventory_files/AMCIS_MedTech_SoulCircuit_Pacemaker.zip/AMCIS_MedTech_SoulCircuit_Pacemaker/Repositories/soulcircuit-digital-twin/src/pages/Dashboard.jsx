import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Heart, 
  Activity, 
  Cpu, 
  Zap, 
  FlaskConical,
  BarChart3,
  Box,
  FileText,
  ChevronRight,
  Brain
} from 'lucide-react';

// Simulation Engine
import { SimulationState, BATTERY_MODELS } from '../components/simulation/SimulationEngine';
import { PROTOTYPE_LIBRARY } from '../components/simulation/PrototypeLibrary';
import { base44 } from '@/api/base44Client';

// ML Components
import ModelTrainer from '../components/ml/ModelTrainer';
import MLPredictionPanel from '../components/ml/MLPredictionPanel';
import ExplainabilityPanel from '../components/ml/ExplainabilityPanel';
import ModelVersionManager from '../components/ml/ModelVersionManager';
import DataUploader from '../components/ml/DataUploader';

// Dashboard Components
import PrototypeCard from '../components/dashboard/PrototypeCard';
import SimulationControls from '../components/dashboard/SimulationControls';
import ConfigurationEditor from '../components/configuration/ConfigurationEditor';
import VoltageChart from '../components/dashboard/VoltageChart';
import ThermalChart from '../components/dashboard/ThermalChart';
import EnergyHarvestingChart from '../components/dashboard/EnergyHarvestingChart';
import ResistanceChart from '../components/dashboard/ResistanceChart';
import StateOfChargeGauge from '../components/dashboard/StateOfChargeGauge';
import FailureEventsPanel from '../components/dashboard/FailureEventsPanel';
import PrototypeSpecsPanel from '../components/dashboard/PrototypeSpecsPanel';
import ReportGenerator from '../components/dashboard/ReportGenerator';
import Device3DViewer from '../components/visualization/Device3DViewer';
import EngineeringMetrics from '../components/validation/EngineeringMetrics';

export default function Dashboard() {
  // State
  const [selectedPrototype, setSelectedPrototype] = useState(PROTOTYPE_LIBRARY[2]); // Default to Base44 Nexus
  const [simulationConfig, setSimulationConfig] = useState({
    pacingRate: 70,
    pacingPercentage: 50,
    pulseAmplitude: 2.5,
    pulseWidth: 0.4,
    activityLevel: 'moderate',
    ambientTemp: 37,
    durationYears: 10,
    failureModes: [],
    timeStepDays: 7 // Weekly time steps
  });
  const [simulation, setSimulation] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [activeTab, setActiveTab] = useState('simulation');
  
  // ML State
  const [modelTrainer] = useState(() => new ModelTrainer());
  const [mlPredictions, setMlPredictions] = useState(null);
  const [isMLEnabled, setIsMLEnabled] = useState(false);
  const [trainingDataCount, setTrainingDataCount] = useState(0);
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState(null);
  
  // Configuration State
  const [configEditorOpen, setConfigEditorOpen] = useState(false);
  const [configuringPrototype, setConfiguringPrototype] = useState(null);

  // Load ML models and check training data on mount
  useEffect(() => {
    const initML = async () => {
      const loaded = await modelTrainer.loadModels();
      setIsMLEnabled(loaded.batteryModelLoaded && loaded.failureModelsLoaded);
      
      // Check training data count
      const data = await modelTrainer.fetchTrainingData(1);
      const count = await base44.entities.MLTrainingData.list('-created_date', 100);
      setTrainingDataCount(count.length);
    };
    initML();
  }, []);

  // Get battery cutoff voltage for selected prototype
  const cutoffVoltage = useMemo(() => {
    if (!selectedPrototype) return 2.0;
    const model = BATTERY_MODELS[selectedPrototype.battery_chemistry];
    return model?.cutoffVoltage || 2.0;
  }, [selectedPrototype]);

  // Run simulation
  const handleRunSimulation = useCallback(async () => {
    if (!selectedPrototype) return;
    
    setIsRunning(true);
    
    // Use setTimeout to allow UI to update
    setTimeout(async () => {
      const config = {
        pacingRate: simulationConfig.pacingRate,
        pacingPercentage: simulationConfig.pacingPercentage,
        pulseAmplitude: simulationConfig.pulseAmplitude,
        pulseWidth: simulationConfig.pulseWidth,
        activityLevel: simulationConfig.activityLevel,
        ambientTemp: simulationConfig.ambientTemp,
        failureModes: simulationConfig.failureModes,
        timeStepDays: simulationConfig.timeStepDays
      };
      
      const sim = new SimulationState(selectedPrototype, config);
      const result = sim.runSimulation(simulationConfig.durationYears);
      
      const simulationData = {
        ...sim,
        finalState: result.finalState,
        timeSeries: result.timeSeries,
        predictedEOL: () => result.predictedEOL,
        config: config
      };
      
      setSimulation(simulationData);
      
      // Collect training data
      await modelTrainer.collectSimulationData(simulationData, selectedPrototype);
      const count = await base44.entities.MLTrainingData.list('-created_date', 100);
      setTrainingDataCount(count.length);
      
      // Generate ML predictions with explainability if models are ready
      if (isMLEnabled && result.timeSeries.length > 20) {
        try {
          const predictions = await modelTrainer.getPredictionWithExplainability(
            result.finalState,
            result.timeSeries
          );
          
          setMlPredictions(predictions);
        } catch (error) {
          console.error('ML prediction failed:', error);
        }
      }
      
      setIsRunning(false);
    }, 100);
  }, [selectedPrototype, simulationConfig, modelTrainer, isMLEnabled, cutoffVoltage]);

  // Reset simulation
  const handleReset = useCallback(() => {
    setSimulation(null);
    setMlPredictions(null);
  }, []);

  // Train ML models
  const handleTrainModels = useCallback(async () => {
    setIsTraining(true);
    setTrainingProgress({ phase: 'init', progress: 0, overall: 0, status: 'Starting...' });
    
    const result = await modelTrainer.trainAllModels((progress) => {
      setTrainingProgress(progress);
    });
    
    if (result.success) {
      setIsMLEnabled(true);
      const count = await base44.entities.MLTrainingData.list('-created_date', 100);
      setTrainingDataCount(count.length);
    }
    
    setIsTraining(false);
    setTimeout(() => setTrainingProgress(null), 2000);
  }, [modelTrainer]);

  // Handle prototype selection
  const handlePrototypeSelect = useCallback((prototype) => {
    setSelectedPrototype(prototype);
    setSimulation(null);
    // Update default pulse parameters from prototype
    setSimulationConfig(prev => ({
      ...prev,
      pulseAmplitude: prototype.pulse_amplitude_v || 2.5,
      pulseWidth: prototype.pulse_width_ms || 0.4
    }));
  }, []);

  // Handle configuration
  const handleOpenConfiguration = useCallback((prototype) => {
    setConfiguringPrototype(prototype);
    setConfigEditorOpen(true);
  }, []);

  const handleApplyConfiguration = useCallback((config) => {
    setSimulationConfig({
      pacingRate: config.pacing_rate_bpm,
      pacingPercentage: config.pacing_percentage,
      pulseAmplitude: config.pulse_amplitude_v,
      pulseWidth: config.pulse_width_ms,
      activityLevel: config.activity_level,
      ambientTemp: config.ambient_temperature_c,
      durationYears: config.simulation_duration_years,
      failureModes: config.enabled_failure_modes || [],
      timeStepDays: 7
    });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800/50 bg-slate-900/30 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute inset-0 bg-teal-500 blur-xl opacity-30" />
                <Heart className="w-8 h-8 text-teal-400 relative animate-pulse" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight">Soul Circuit</h1>
                <p className="text-xs text-slate-500">Pacemaker Digital Twin Ecosystem</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="border-teal-500/30 text-teal-400 text-xs">
                <FlaskConical className="w-3 h-3 mr-1" />
                IEC 62304 Compliant
              </Badge>
              {isMLEnabled && (
                <Badge variant="outline" className="border-purple-500/30 text-purple-400 text-xs">
                  <Brain className="w-3 h-3 mr-1" />
                  ML Enabled
                </Badge>
              )}
              <ReportGenerator simulation={simulation} prototype={selectedPrototype} />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-6">
        {/* Prototype Selector */}
        <section className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-slate-400" />
              <h2 className="text-sm font-medium text-slate-300">Prototype Library</h2>
            </div>
            <Badge variant="outline" className="text-xs border-slate-700 text-slate-500">
              {PROTOTYPE_LIBRARY.length} devices
            </Badge>
          </div>
          
          <ScrollArea className="w-full">
            <div className="flex gap-4 pb-2">
              {PROTOTYPE_LIBRARY.map((prototype) => (
                <div key={prototype.id} className="w-72 flex-shrink-0">
                  <PrototypeCard
                    prototype={prototype}
                    isSelected={selectedPrototype?.id === prototype.id}
                    onClick={() => handlePrototypeSelect(prototype)}
                    onConfigure={handleOpenConfiguration}
                  />
                </div>
              ))}
            </div>
          </ScrollArea>
        </section>

        <Separator className="bg-slate-800/50 mb-6" />

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-800/30 border border-slate-700/50 p-1">
            <TabsTrigger 
              value="simulation" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white text-xs"
            >
              <Activity className="w-3 h-3 mr-1.5" />
              Simulation
            </TabsTrigger>
            <TabsTrigger 
              value="analysis" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white text-xs"
            >
              <BarChart3 className="w-3 h-3 mr-1.5" />
              Analysis
            </TabsTrigger>
            <TabsTrigger 
              value="3d-model" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white text-xs"
            >
              <Box className="w-3 h-3 mr-1.5" />
              3D Model
            </TabsTrigger>
            <TabsTrigger 
              value="specs" 
              className="data-[state=active]:bg-teal-600 data-[state=active]:text-white text-xs"
            >
              <FileText className="w-3 h-3 mr-1.5" />
              Specifications
            </TabsTrigger>
            <TabsTrigger 
              value="ml" 
              className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-xs"
            >
              <Brain className="w-3 h-3 mr-1.5" />
              ML Training
            </TabsTrigger>
          </TabsList>

          {/* Simulation Tab */}
          <TabsContent value="simulation" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Panel - Controls */}
              <div className="lg:col-span-3 space-y-4">
                <SimulationControls
                  config={simulationConfig}
                  onConfigChange={setSimulationConfig}
                  onRun={handleRunSimulation}
                  onPause={() => {}}
                  onReset={handleReset}
                  isRunning={isRunning}
                  prototype={selectedPrototype}
                />
                
                <StateOfChargeGauge
                  soc={simulation?.finalState?.soc || 1}
                  voltage={simulation?.finalState?.voltage || selectedPrototype?.nominal_voltage}
                  capacityRemaining={simulation?.finalState?.capacityRemaining || selectedPrototype?.energy_capacity_mah}
                  initialCapacity={selectedPrototype?.energy_capacity_mah}
                />
              </div>

              {/* Center Panel - Charts */}
              <div className="lg:col-span-6 space-y-4">
                <VoltageChart 
                  data={simulation?.timeSeries} 
                  prototype={selectedPrototype}
                  cutoffVoltage={cutoffVoltage}
                />
                <ThermalChart 
                  data={simulation?.timeSeries}
                  maxTemp={simulation?.finalState?.maxTemperature}
                />
              </div>

              {/* Right Panel - Failure Analysis & ML */}
              <div className="lg:col-span-3 space-y-4">
                <MLPredictionPanel
                  mlPredictions={mlPredictions}
                  isMLEnabled={isMLEnabled}
                  trainingDataCount={trainingDataCount}
                  onTrain={handleTrainModels}
                  isTraining={isTraining}
                  trainingProgress={trainingProgress}
                />
                
                <EngineeringMetrics 
                  simulation={simulation}
                  prototype={selectedPrototype}
                />
                
                <FailureEventsPanel
                  failures={simulation?.finalState?.failures}
                  warnings={simulation?.finalState?.warnings}
                  isOperational={simulation?.finalState?.isOperational}
                  eolReached={simulation?.finalState?.eolReached}
                  predictedEOL={simulation?.predictedEOL?.()}
                />
                
                <Device3DViewer prototype={selectedPrototype} />
              </div>
            </div>
          </TabsContent>

          {/* Analysis Tab */}
          <TabsContent value="analysis" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <VoltageChart 
                data={simulation?.timeSeries} 
                prototype={selectedPrototype}
                cutoffVoltage={cutoffVoltage}
              />
              <ResistanceChart 
                data={simulation?.timeSeries}
                initialResistance={selectedPrototype?.internal_resistance_ohms}
              />
              <ThermalChart 
                data={simulation?.timeSeries}
                maxTemp={simulation?.finalState?.maxTemperature}
              />
              <EnergyHarvestingChart
                data={simulation?.timeSeries}
                harvestingType={selectedPrototype?.harvesting_type}
                totalHarvested={simulation?.finalState?.totalHarvestedEnergy}
              />
            </div>
            
            {!simulation && (
              <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                <Activity className="w-12 h-12 mb-4 opacity-50" />
                <p className="text-sm">Run a simulation to view analysis data</p>
                <Button 
                  variant="outline" 
                  className="mt-4 border-teal-500/50 text-teal-400 hover:bg-teal-500/10"
                  onClick={() => setActiveTab('simulation')}
                >
                  Go to Simulation
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            )}
          </TabsContent>

          {/* 3D Model Tab */}
          <TabsContent value="3d-model">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="lg:col-span-1">
                <Device3DViewer prototype={selectedPrototype} />
              </div>
              <div className="lg:col-span-1">
                <PrototypeSpecsPanel prototype={selectedPrototype} />
              </div>
            </div>
          </TabsContent>

          {/* Specifications Tab */}
          <TabsContent value="specs">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <PrototypeSpecsPanel prototype={selectedPrototype} />
              </div>
              <div className="lg:col-span-1 space-y-4">
                <StateOfChargeGauge
                  soc={simulation?.finalState?.soc || 1}
                  voltage={simulation?.finalState?.voltage || selectedPrototype?.nominal_voltage}
                  capacityRemaining={simulation?.finalState?.capacityRemaining || selectedPrototype?.energy_capacity_mah}
                  initialCapacity={selectedPrototype?.energy_capacity_mah}
                />
                <FailureEventsPanel
                  failures={simulation?.finalState?.failures}
                  warnings={simulation?.finalState?.warnings}
                  isOperational={simulation?.finalState?.isOperational}
                  eolReached={simulation?.finalState?.eolReached}
                  predictedEOL={simulation?.predictedEOL?.()}
                />
              </div>
            </div>
          </TabsContent>

          {/* ML Training Tab */}
          <TabsContent value="ml" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <MLPredictionPanel
                mlPredictions={mlPredictions}
                isMLEnabled={isMLEnabled}
                trainingDataCount={trainingDataCount}
                onTrain={handleTrainModels}
                isTraining={isTraining}
                trainingProgress={trainingProgress}
              />
              <ExplainabilityPanel 
                shapValues={mlPredictions?.shapValues}
                clinicalSummary={mlPredictions?.clinicalSummary}
                currentState={simulation?.finalState}
              />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ModelVersionManager />
              </div>
              <DataUploader onUploadComplete={() => queryClient.invalidateQueries(['mlTrainingData'])} />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <VoltageChart 
                data={simulation?.timeSeries} 
                prototype={selectedPrototype}
                cutoffVoltage={cutoffVoltage}
              />
              <ThermalChart 
                data={simulation?.timeSeries}
                maxTemp={simulation?.finalState?.maxTemperature}
              />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Configuration Editor */}
      <ConfigurationEditor
        prototype={configuringPrototype || selectedPrototype}
        isOpen={configEditorOpen}
        onClose={() => setConfigEditorOpen(false)}
        onApplyConfiguration={handleApplyConfiguration}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/50 mt-12 py-6">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between text-xs text-slate-600">
            <p>Soul Circuit Digital Twin • Base44 MedTech</p>
            <div className="flex items-center gap-4">
              <span>ISO 14708-1 Compliant</span>
              <span>IEC 62304 Class B</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}