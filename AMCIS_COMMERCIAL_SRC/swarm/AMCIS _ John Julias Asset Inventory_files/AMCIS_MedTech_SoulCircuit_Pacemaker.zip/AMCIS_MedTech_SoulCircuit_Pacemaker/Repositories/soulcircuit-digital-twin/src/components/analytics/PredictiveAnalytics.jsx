import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { LineChart, Line, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, AlertTriangle, Activity, Zap } from 'lucide-react';

export default function PredictiveAnalytics({ registryData, snapshots }) {
  const analytics = useMemo(() => {
    if (!snapshots.length) return null;

    // Detect emerging failure patterns
    const recentSnapshots = snapshots
      .filter(s => new Date(s.snapshot_date) > new Date(Date.now() - 90 * 24 * 60 * 60 * 1000))
      .sort((a, b) => new Date(b.snapshot_date) - new Date(a.snapshot_date));

    // Anomaly frequency over time
    const anomalyTrends = {};
    snapshots.forEach(snapshot => {
      const month = new Date(snapshot.snapshot_date).toISOString().slice(0, 7);
      if (!anomalyTrends[month]) {
        anomalyTrends[month] = { count: 0, totalDevices: 0 };
      }
      anomalyTrends[month].totalDevices++;
      if (snapshot.anomaly_flags && snapshot.anomaly_flags.length > 0) {
        anomalyTrends[month].count += snapshot.anomaly_flags.length;
      }
    });

    const trendData = Object.keys(anomalyTrends)
      .sort()
      .slice(-12)
      .map(month => ({
        month,
        anomalyRate: anomalyTrends[month].totalDevices > 0 
          ? ((anomalyTrends[month].count / anomalyTrends[month].totalDevices) * 100).toFixed(1)
          : 0,
        count: anomalyTrends[month].count
      }));

    // Identify emerging patterns
    const emergingPatterns = [];
    const anomalyTypes = {};
    
    recentSnapshots.forEach(snapshot => {
      if (snapshot.anomaly_flags) {
        snapshot.anomaly_flags.forEach(flag => {
          anomalyTypes[flag] = (anomalyTypes[flag] || 0) + 1;
        });
      }
    });

    Object.entries(anomalyTypes)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .forEach(([pattern, count]) => {
        const prevalence = ((count / recentSnapshots.length) * 100).toFixed(1);
        emergingPatterns.push({
          pattern,
          count,
          prevalence,
          severity: count > 10 ? 'high' : count > 5 ? 'moderate' : 'low'
        });
      });

    // Risk distribution scatter
    const riskDistribution = snapshots
      .filter(s => s.risk_score > 0 && s.predicted_rul_days > 0)
      .map(s => ({
        risk: s.risk_score,
        rul: s.predicted_rul_days,
        age: s.days_since_implant / 365
      }));

    // Population-level risk forecast
    const highRiskDevices = recentSnapshots.filter(s => s.risk_score >= 60).length;
    const totalRecentDevices = recentSnapshots.length;
    const riskTrend = totalRecentDevices > 0 ? ((highRiskDevices / totalRecentDevices) * 100).toFixed(1) : 0;

    return {
      trendData,
      emergingPatterns,
      riskDistribution,
      riskTrend,
      highRiskDevices
    };
  }, [registryData, snapshots]);

  if (!analytics) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="py-12 text-center text-slate-500">
          <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>Insufficient data for predictive analytics</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Risk Forecast Alert */}
      {parseFloat(analytics.riskTrend) > 15 && (
        <Alert className="bg-orange-900/20 border-orange-700/50">
          <AlertTriangle className="w-4 h-4 text-orange-400" />
          <AlertDescription className="text-orange-200">
            <strong>Population Risk Alert:</strong> {analytics.riskTrend}% of recently monitored devices 
            show elevated risk scores (≥60). Consider targeted interventions.
          </AlertDescription>
        </Alert>
      )}

      {/* Emerging Failure Patterns */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            Emerging Failure Patterns (Last 90 Days)
          </CardTitle>
          <CardDescription>
            Most frequently detected anomalies across the fleet
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics.emergingPatterns.length === 0 ? (
              <p className="text-center text-slate-500 py-6">No significant patterns detected</p>
            ) : (
              analytics.emergingPatterns.map((pattern, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-lg border ${
                    pattern.severity === 'high' ? 'bg-red-900/20 border-red-700/50' :
                    pattern.severity === 'moderate' ? 'bg-orange-900/20 border-orange-700/50' :
                    'bg-yellow-900/20 border-yellow-700/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className={`w-4 h-4 ${
                        pattern.severity === 'high' ? 'text-red-400' :
                        pattern.severity === 'moderate' ? 'text-orange-400' : 'text-yellow-400'
                      }`} />
                      <span className="font-medium text-white capitalize">{pattern.pattern}</span>
                    </div>
                    <Badge variant="outline" className={
                      pattern.severity === 'high' ? 'border-red-700/50 text-red-400' :
                      pattern.severity === 'moderate' ? 'border-orange-700/50 text-orange-400' :
                      'border-yellow-700/50 text-yellow-400'
                    }>
                      {pattern.severity}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-slate-300">
                    <span>Occurrences: <strong>{pattern.count}</strong></span>
                    <span>Prevalence: <strong>{pattern.prevalence}%</strong></span>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Anomaly Trend Over Time */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-teal-400" />
            Anomaly Detection Trends
          </CardTitle>
          <CardDescription>Monthly anomaly rate across fleet (last 12 months)</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={analytics.trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="month" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" label={{ value: 'Anomaly Rate (%)', angle: -90, position: 'insideLeft' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                labelStyle={{ color: '#f1f5f9' }}
              />
              <Legend />
              <Line type="monotone" dataKey="anomalyRate" stroke="#f97316" strokeWidth={2} name="Anomaly Rate (%)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Risk vs RUL Scatter */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Risk Score vs Remaining Useful Life</CardTitle>
          <CardDescription>Population-level risk distribution</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={350}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis 
                type="number" 
                dataKey="rul" 
                name="RUL (days)" 
                stroke="#94a3b8"
                label={{ value: 'Remaining Useful Life (days)', position: 'insideBottom', offset: -5 }}
              />
              <YAxis 
                type="number" 
                dataKey="risk" 
                name="Risk Score" 
                stroke="#94a3b8"
                label={{ value: 'Risk Score', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
              />
              <Legend />
              <Scatter name="Devices" data={analytics.riskDistribution} fill="#14b8a6">
                {analytics.riskDistribution.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.risk >= 80 ? '#ef4444' : entry.risk >= 60 ? '#f97316' : entry.risk >= 40 ? '#f59e0b' : '#14b8a6'}
                  />
                ))}
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
          <div className="mt-4 flex items-center justify-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full" />
              <span className="text-slate-400">Critical (&gt;80)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-orange-500 rounded-full" />
              <span className="text-slate-400">High (60-80)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full" />
              <span className="text-slate-400">Moderate (40-60)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-teal-500 rounded-full" />
              <span className="text-slate-400">Low (&lt;40)</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}