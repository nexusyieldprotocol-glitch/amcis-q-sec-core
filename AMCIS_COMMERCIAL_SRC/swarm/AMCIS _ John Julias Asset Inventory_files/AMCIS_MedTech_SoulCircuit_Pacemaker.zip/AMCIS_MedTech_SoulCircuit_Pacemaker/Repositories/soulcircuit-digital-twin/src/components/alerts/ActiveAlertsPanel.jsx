import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle2, Bell, AlertTriangle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { format, formatDistanceToNow } from 'date-fns';

export default function ActiveAlertsPanel({ alerts }) {
  const queryClient = useQueryClient();
  const [, setRefresh] = useState(0);

  // Subscribe to real-time alert updates
  useEffect(() => {
    const unsubscribe = base44.entities.Alert.subscribe((event) => {
      if (event.type === 'create') {
        setRefresh(prev => prev + 1);
        queryClient.invalidateQueries(['alerts']);
        
        // Show toast notification for critical alerts
        if (event.data?.severity === 'critical') {
          toast.error(`Critical Alert: ${event.data.message}`, {
            duration: 10000
          });
        }
      }
    });

    return unsubscribe;
  }, [queryClient]);

  const acknowledgeMutation = useMutation({
    mutationFn: async ({ alertId, user }) => {
      return base44.entities.Alert.update(alertId, {
        acknowledged: true,
        acknowledged_by: user.email,
        acknowledged_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['alerts']);
      toast.success('Alert acknowledged');
    }
  });

  const resolveMutation = useMutation({
    mutationFn: async (alertId) => {
      return base44.entities.Alert.update(alertId, {
        resolved: true,
        resolved_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['alerts']);
      toast.success('Alert resolved');
    }
  });

  const handleAcknowledge = async (alertId) => {
    const user = await base44.auth.me();
    acknowledgeMutation.mutate({ alertId, user });
  };

  const sortedAlerts = [...alerts].sort((a, b) => {
    const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    const severityDiff = severityOrder[a.severity] - severityOrder[b.severity];
    if (severityDiff !== 0) return severityDiff;
    return new Date(b.triggered_at) - new Date(a.triggered_at);
  });

  const criticalAlerts = sortedAlerts.filter(a => a.severity === 'critical');

  return (
    <div className="space-y-4">
      {/* Critical Alerts Banner */}
      {criticalAlerts.length > 0 && (
        <Alert className="bg-red-900/20 border-red-700/50">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <AlertDescription className="text-red-200">
            <strong>{criticalAlerts.length} Critical Alert{criticalAlerts.length !== 1 ? 's' : ''}</strong> require immediate attention
          </AlertDescription>
        </Alert>
      )}

      {/* Alert List */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-teal-400" />
            Active Alerts ({alerts.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] pr-4">
            {sortedAlerts.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="text-lg">No active alerts</p>
                <p className="text-sm">All systems operating normally</p>
              </div>
            ) : (
              <div className="space-y-3">
                {sortedAlerts.map(alert => (
                  <AlertCard
                    key={alert.id}
                    alert={alert}
                    onAcknowledge={handleAcknowledge}
                    onResolve={(id) => resolveMutation.mutate(id)}
                  />
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

function AlertCard({ alert, onAcknowledge, onResolve }) {
  const severityColors = {
    low: 'bg-blue-900/20 border-blue-700/50',
    medium: 'bg-yellow-900/20 border-yellow-700/50',
    high: 'bg-orange-900/20 border-orange-700/50',
    critical: 'bg-red-900/20 border-red-700/50'
  };

  const severityBadge = {
    low: 'bg-blue-900/30 text-blue-400',
    medium: 'bg-yellow-900/30 text-yellow-400',
    high: 'bg-orange-900/30 text-orange-400',
    critical: 'bg-red-900/30 text-red-400'
  };

  return (
    <Card className={`${severityColors[alert.severity]} border-2`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={severityBadge[alert.severity]}>
                {alert.severity}
              </Badge>
              <Badge variant="outline" className="text-xs border-purple-700/50 text-purple-400">
                {alert.metric_type?.replace(/_/g, ' ')}
              </Badge>
            </div>
            <p className="text-white font-medium mb-1">{alert.message}</p>
            <div className="text-xs text-slate-400 space-y-1">
              <p>Device: {alert.device_snapshot?.device_id || 'Unknown'}</p>
              <p>Patient: {alert.device_snapshot?.patient_id || 'N/A'}</p>
              <p className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDistanceToNow(new Date(alert.triggered_at), { addSuffix: true })}
              </p>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            {!alert.acknowledged && (
              <Button
                size="sm"
                onClick={() => onAcknowledge(alert.id)}
                className="bg-teal-600 hover:bg-teal-700"
              >
                Acknowledge
              </Button>
            )}
            {alert.acknowledged && !alert.resolved && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onResolve(alert.id)}
                className="border-green-700 text-green-400 hover:bg-green-900/20"
              >
                Resolve
              </Button>
            )}
          </div>
        </div>

        {alert.acknowledged && (
          <div className="text-xs text-slate-500 bg-slate-800/30 p-2 rounded mt-2">
            Acknowledged by {alert.acknowledged_by} at {format(new Date(alert.acknowledged_at), 'MMM d, HH:mm')}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 mt-3 text-xs">
          <div className="bg-slate-800/30 p-2 rounded">
            <p className="text-slate-400">Current Value</p>
            <p className="text-white font-medium">{alert.metric_value?.toFixed(2)}</p>
          </div>
          <div className="bg-slate-800/30 p-2 rounded">
            <p className="text-slate-400">Threshold</p>
            <p className="text-white font-medium">{alert.threshold_value}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}