import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Activity, Zap, Thermometer, AlertCircle, CheckCircle2, Radio } from 'lucide-react';
import { format } from 'date-fns';

export default function DiagnosticDashboard({ device, diagnostics }) {
  const [liveSensorData, setLiveSensorData] = useState([]);
  const [lastUpdate, setLastUpdate] = useState(null);

  // Subscribe to real-time diagnostic events
  useEffect(() => {
    if (!device) return;

    const unsubscribe = base44.entities.DeviceDiagnostic.subscribe((event) => {
      if (event.type === 'create' && event.data?.device_registry_id === device.id) {
        setLastUpdate(new Date());
      }
    });

    return unsubscribe;
  }, [device?.id]);

  // Generate simulated sensor data stream
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveSensorData(prev => {
        const newPoint = {
          time: Date.now(),
          voltage: 2.6 + Math.random() * 0.2,
          impedance: 450 + Math.random() * 50,
          temperature: 36.8 + Math.random() * 0.5,
          label: new Date().toLocaleTimeString()
        };
        return [...prev, newPoint].slice(-30);
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const recentDiagnostics = diagnostics
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 10);

  const criticalIssues = diagnostics.filter(d => d.severity === 'critical' && !d.resolved);
  const unresolvedIssues = diagnostics.filter(d => !d.resolved);

  return (
    <div className="space-y-4">
      {/* Status Banner */}
      <Card className={`${
        criticalIssues.length > 0 
          ? 'bg-red-900/10 border-red-700' 
          : 'bg-slate-900/50 border-slate-700'
      }`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Radio className={`w-5 h-5 ${criticalIssues.length > 0 ? 'text-red-400' : 'text-teal-400'}`} />
              <div>
                <p className="text-xs text-slate-400">Device Status</p>
                <p className="text-lg font-bold text-white">
                  {device.device_id} - {criticalIssues.length > 0 ? 'Critical Issues' : 'Operational'}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Last Update</p>
              <p className="text-sm text-teal-400">
                {lastUpdate ? lastUpdate.toLocaleTimeString() : 'Live'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Issue Summary */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="bg-red-900/20 border-red-700/50">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-red-400 mb-1">Critical</p>
                <p className="text-2xl font-bold text-white">{criticalIssues.length}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-orange-900/20 border-orange-700/50">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-orange-400 mb-1">Unresolved</p>
                <p className="text-2xl font-bold text-white">{unresolvedIssues.length}</p>
              </div>
              <Activity className="w-8 h-8 text-orange-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-900/20 border-green-700/50">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-green-400 mb-1">Resolved</p>
                <p className="text-2xl font-bold text-white">
                  {diagnostics.filter(d => d.resolved).length}
                </p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Sensor Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              Battery Voltage (Live)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={liveSensorData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" hide />
                <YAxis stroke="#94a3b8" domain={[2.4, 2.9]} tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  formatter={(value) => [value?.toFixed(2) + ' V', 'Voltage']}
                />
                <ReferenceLine y={2.4} stroke="#ef4444" strokeDasharray="3 3" />
                <Line type="monotone" dataKey="voltage" stroke="#fbbf24" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-purple-400" />
              Impedance (Live)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={liveSensorData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" hide />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  formatter={(value) => [value?.toFixed(0) + ' Ω', 'Impedance']}
                />
                <Line type="monotone" dataKey="impedance" stroke="#a855f7" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-red-400" />
              Temperature (Live)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={liveSensorData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" hide />
                <YAxis stroke="#94a3b8" domain={[36, 38]} tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  formatter={(value) => [value?.toFixed(1) + ' °C', 'Temp']}
                />
                <ReferenceLine y={38} stroke="#ef4444" strokeDasharray="3 3" />
                <Line type="monotone" dataKey="temperature" stroke="#f87171" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Error Log */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Diagnostic Events</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px] pr-4">
            {recentDiagnostics.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <CheckCircle2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No diagnostic events</p>
              </div>
            ) : (
              <div className="space-y-2">
                {recentDiagnostics.map((diagnostic, idx) => (
                  <DiagnosticEventCard key={idx} diagnostic={diagnostic} />
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

function DiagnosticEventCard({ diagnostic }) {
  const severityColors = {
    low: 'bg-blue-900/20 border-blue-700/50 text-blue-400',
    medium: 'bg-yellow-900/20 border-yellow-700/50 text-yellow-400',
    high: 'bg-orange-900/20 border-orange-700/50 text-orange-400',
    critical: 'bg-red-900/20 border-red-700/50 text-red-400'
  };

  const typeIcons = {
    error: AlertCircle,
    warning: Activity,
    anomaly: Activity,
    critical: AlertCircle,
    info: CheckCircle2
  };

  const Icon = typeIcons[diagnostic.event_type] || Activity;

  return (
    <Card className={`${severityColors[diagnostic.severity]} border`}>
      <CardContent className="p-3">
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-start gap-2">
            <Icon className="w-4 h-4 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-white">{diagnostic.description}</p>
              {diagnostic.error_code && (
                <p className="text-xs opacity-70">Code: {diagnostic.error_code}</p>
              )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge variant="outline" className={`text-xs ${severityColors[diagnostic.severity]}`}>
              {diagnostic.severity}
            </Badge>
            {diagnostic.resolved && (
              <Badge variant="outline" className="text-xs border-green-700/50 text-green-400">
                Resolved
              </Badge>
            )}
          </div>
        </div>
        <p className="text-xs opacity-70">{format(new Date(diagnostic.timestamp), 'MMM d, yyyy HH:mm:ss')}</p>
      </CardContent>
    </Card>
  );
}