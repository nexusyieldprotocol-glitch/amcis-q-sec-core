// Soul Circuit - Real-time Telemetry Simulator
// Generates realistic device telemetry from SimulationEngine outputs

import { SimulationState, BATTERY_MODELS } from '../simulation/SimulationEngine';
import { PROTOTYPE_LIBRARY } from '../simulation/PrototypeLibrary';

export class TelemetrySimulator {
  constructor() {
    this.activeSimulations = new Map(); // device_id -> simulation state
  }
  
  /**
   * Initialize a virtual device with realistic parameters
   */
  initializeVirtualDevice(deviceConfig) {
    const {
      device_id,
      prototype_id = 'micra-vr',
      implant_date,
      pacing_config = {}
    } = deviceConfig;
    
    const prototype = PROTOTYPE_LIBRARY.find(p => p.id === prototype_id) || PROTOTYPE_LIBRARY[0];
    
    const config = {
      pacingRate: pacing_config.pacingRate || 70,
      pacingPercentage: pacing_config.pacingPercentage || 50,
      pulseAmplitude: pacing_config.pulseAmplitude || prototype.pulse_amplitude_v,
      pulseWidth: pacing_config.pulseWidth || prototype.pulse_width_ms,
      activityLevel: pacing_config.activityLevel || 'moderate',
      ambientTemp: 37,
      failureModes: pacing_config.failureModes || [],
      timeStepDays: 1 // Daily telemetry snapshots
    };
    
    const simulation = new SimulationState(prototype, config);
    
    // Fast-forward to current time since implant
    const daysSinceImplant = this.calculateDaysSinceImplant(implant_date);
    const years = daysSinceImplant / 365;
    
    // Run simulation to current state
    for (let i = 0; i < daysSinceImplant && simulation.state.isOperational; i++) {
      simulation.step();
    }
    
    this.activeSimulations.set(device_id, {
      simulation,
      prototype,
      implant_date,
      last_update: new Date()
    });
    
    return simulation.state;
  }
  
  /**
   * Generate telemetry snapshot for a device
   */
  generateTelemetrySnapshot(device_id) {
    const virtualDevice = this.activeSimulations.get(device_id);
    if (!virtualDevice) {
      throw new Error(`Device ${device_id} not initialized`);
    }
    
    const { simulation, prototype } = virtualDevice;
    const state = simulation.state;
    
    // Add realistic noise
    const voltageNoise = (Math.random() - 0.5) * 0.02;
    const impedanceNoise = (Math.random() - 0.5) * 5;
    
    return {
      device_id,
      timestamp: new Date().toISOString(),
      battery_voltage_v: parseFloat((state.voltage + voltageNoise).toFixed(3)),
      battery_impedance_ohms: parseFloat((state.internalResistance + impedanceNoise).toFixed(1)),
      lead_impedance_ohms: parseFloat((state.leadImpedance + (Math.random() - 0.5) * 10).toFixed(1)),
      pacing_threshold_v: parseFloat((1.5 + Math.random() * 0.5).toFixed(2)),
      pacing_burden_percent: simulation.config.pacingPercentage + (Math.random() - 0.5) * 5,
      days_since_implant: state.elapsedDays,
      soc: state.soc,
      temperature_c: state.temperature,
      total_paces: state.totalPaces,
      energy_delivered_j: state.energyDelivered,
      is_operational: state.isOperational
    };
  }
  
  /**
   * Advance simulation by one step and generate snapshot
   */
  stepAndSnapshot(device_id) {
    const virtualDevice = this.activeSimulations.get(device_id);
    if (!virtualDevice) {
      throw new Error(`Device ${device_id} not initialized`);
    }
    
    const { simulation } = virtualDevice;
    
    // Step simulation forward
    if (simulation.state.isOperational) {
      simulation.step();
    }
    
    virtualDevice.last_update = new Date();
    
    return this.generateTelemetrySnapshot(device_id);
  }
  
  /**
   * Batch initialize multiple virtual devices
   */
  async batchInitializeDevices(registryDevices) {
    const snapshots = [];
    
    for (const device of registryDevices) {
      try {
        const state = this.initializeVirtualDevice({
          device_id: device.device_id,
          prototype_id: this.mapToPrototypeId(device),
          implant_date: device.implant_date,
          pacing_config: {
            pacingPercentage: device.pacing_percentage || 50,
            activityLevel: 'moderate'
          }
        });
        
        const snapshot = this.generateTelemetrySnapshot(device.device_id);
        snapshots.push(snapshot);
      } catch (error) {
        console.error(`Failed to initialize device ${device.device_id}:`, error);
      }
    }
    
    return snapshots;
  }
  
  /**
   * Stream telemetry for active devices (generator function)
   */
  *streamTelemetry(device_ids, intervalMs = 5000) {
    while (true) {
      const snapshots = [];
      
      for (const device_id of device_ids) {
        try {
          const snapshot = this.stepAndSnapshot(device_id);
          snapshots.push(snapshot);
        } catch (error) {
          console.error(`Telemetry error for ${device_id}:`, error);
        }
      }
      
      yield {
        timestamp: new Date().toISOString(),
        snapshots
      };
      
      // In real implementation, this would be async with actual delays
      // For simulation, caller controls timing
    }
  }
  
  /**
   * Helper: calculate days since implant
   */
  calculateDaysSinceImplant(implantDate) {
    const implant = new Date(implantDate);
    const now = new Date();
    return Math.floor((now - implant) / (1000 * 60 * 60 * 24));
  }
  
  /**
   * Helper: map registry device to prototype
   */
  mapToPrototypeId(device) {
    // Map manufacturer/model to prototype library
    const mapping = {
      'Medtronic': 'micra-vr',
      'Abbott': 'aveir-dr',
      'Boston Scientific': 'boston-accolade',
      'Biotronik': 'biotronik-edora',
      'Base44 Labs': 'base44-nexus'
    };
    
    return mapping[device.manufacturer] || 'classic-transvenous';
  }
}

export default TelemetrySimulator;