import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AreaChart, Area, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Battery, AlertTriangle, Clock, Activity } from 'lucide-react';

export default function FleetMetricsPanel({ registryData, snapshots }) {
  const metrics = useMemo(() => {
    if (!registryData.length || !snapshots.length) return null;

    // Calculate average RUL
    const activeDevices = registryData.filter(d => d.status === 'active');
    const rulValues = activeDevices.map(device => {
      const snapshot = snapshots.find(s => s.device_registry_id === device.id);
      return snapshot?.predicted_rul_days || 0;
    }).filter(v => v > 0);
    const avgRUL = rulValues.length ? rulValues.reduce((a, b) => a + b, 0) / rulValues.length : 0;

    // Failure rates by component
    const failuresByComponent = {
      battery: 0,
      lead: 0,
      capacitor: 0,
      other: 0
    };
    
    snapshots.forEach(snapshot => {
      if (snapshot.anomaly_flags) {
        snapshot.anomaly_flags.forEach(flag => {
          if (flag.toLowerCase().includes('battery')) failuresByComponent.battery++;
          else if (flag.toLowerCase().includes('lead')) failuresByComponent.lead++;
          else if (flag.toLowerCase().includes('capacitor')) failuresByComponent.capacitor++;
          else failuresByComponent.other++;
        });
      }
    });

    // Battery degradation curve over fleet
    const degradationByAge = {};
    snapshots.forEach(snapshot => {
      const age = Math.floor(snapshot.days_since_implant / 365);
      if (!degradationByAge[age]) {
        degradationByAge[age] = { totalVoltage: 0, count: 0, totalResistance: 0 };
      }
      if (snapshot.battery_voltage_v) {
        degradationByAge[age].totalVoltage += snapshot.battery_voltage_v;
        degradationByAge[age].count++;
      }
      if (snapshot.battery_impedance_ohms) {
        degradationByAge[age].totalResistance += snapshot.battery_impedance_ohms;
      }
    });

    const degradationCurve = Object.keys(degradationByAge)
      .map(age => ({
        age: parseInt(age),
        avgVoltage: degradationByAge[age].count ? (degradationByAge[age].totalVoltage / degradationByAge[age].count).toFixed(2) : 0,
        avgResistance: degradationByAge[age].count ? (degradationByAge[age].totalResistance / degradationByAge[age].count).toFixed(1) : 0
      }))
      .sort((a, b) => a.age - b.age);

    return {
      avgRUL,
      activeDevices: activeDevices.length,
      totalDevices: registryData.length,
      failuresByComponent,
      degradationCurve
    };
  }, [registryData, snapshots]);

  if (!metrics) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="py-12 text-center text-slate-500">
          <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No fleet data available</p>
        </CardContent>
      </Card>
    );
  }

  const totalFailures = Object.values(metrics.failuresByComponent).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6">
      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-teal-900/20 to-teal-800/10 border-teal-700/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-teal-400 mb-1">Avg Fleet RUL</p>
                <p className="text-2xl font-bold text-white">{Math.round(metrics.avgRUL)} days</p>
              </div>
              <Clock className="w-8 h-8 text-teal-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-700/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-blue-400 mb-1">Active Devices</p>
                <p className="text-2xl font-bold text-white">{metrics.activeDevices}</p>
              </div>
              <Battery className="w-8 h-8 text-blue-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-900/20 to-orange-800/10 border-orange-700/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-orange-400 mb-1">Total Anomalies</p>
                <p className="text-2xl font-bold text-white">{totalFailures}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-400 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-900/20 to-purple-800/10 border-purple-700/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-purple-400 mb-1">Fleet Size</p>
                <p className="text-2xl font-bold text-white">{metrics.totalDevices}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Component Failure Breakdown */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Failure Distribution by Component</CardTitle>
          <CardDescription>Anomaly detection across device components</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(metrics.failuresByComponent).map(([component, count]) => {
              const percentage = totalFailures > 0 ? ((count / totalFailures) * 100).toFixed(1) : 0;
              return (
                <div key={component} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300 capitalize">{component}</span>
                    <span className="text-white font-medium">{count} ({percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        component === 'battery' ? 'bg-yellow-500' :
                        component === 'lead' ? 'bg-orange-500' :
                        component === 'capacitor' ? 'bg-red-500' : 'bg-slate-500'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Battery Degradation Curve */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Fleet-Wide Battery Degradation</CardTitle>
          <CardDescription>Average voltage and resistance trends by device age</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={metrics.degradationCurve}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="age" stroke="#94a3b8" label={{ value: 'Years Since Implant', position: 'insideBottom', offset: -5 }} />
              <YAxis yAxisId="left" stroke="#94a3b8" label={{ value: 'Voltage (V)', angle: -90, position: 'insideLeft' }} />
              <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" label={{ value: 'Resistance (Ω)', angle: 90, position: 'insideRight' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                labelStyle={{ color: '#f1f5f9' }}
              />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="avgVoltage" stroke="#14b8a6" name="Avg Voltage" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="avgResistance" stroke="#f97316" name="Avg Resistance" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}