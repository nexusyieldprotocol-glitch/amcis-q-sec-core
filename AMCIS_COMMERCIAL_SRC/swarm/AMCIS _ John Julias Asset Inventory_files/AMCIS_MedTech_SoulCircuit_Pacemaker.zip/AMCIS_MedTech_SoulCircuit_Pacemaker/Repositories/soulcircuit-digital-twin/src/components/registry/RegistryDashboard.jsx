import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter 
} from 'recharts';
import { 
  Database, TrendingUp, AlertTriangle, Clock, 
  Zap, Activity, CheckCircle2 
} from 'lucide-react';
import LongevityModel from './LongevityModel';

export default function RegistryDashboard() {
  const [longevityModel] = useState(() => new LongevityModel());
  const [selectedManufacturer, setSelectedManufacturer] = useState('all');
  
  // Fetch registry data
  const { data: registryData = [], isLoading } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list('-implant_date', 100)
  });
  
  // Fetch longevity snapshots
  const { data: snapshots = [] } = useQuery({
    queryKey: ['longevitySnapshots'],
    queryFn: () => base44.entities.LongevitySnapshot.list('-snapshot_date', 500)
  });
  
  // Calculate cohort statistics
  const cohortStats = longevityModel.generateCohortStats(registryData);
  
  // Filter by manufacturer
  const filteredData = selectedManufacturer === 'all' 
    ? registryData 
    : registryData.filter(d => d.manufacturer === selectedManufacturer);
  
  // Status breakdown
  const statusBreakdown = filteredData.reduce((acc, device) => {
    acc[device.status] = (acc[device.status] || 0) + 1;
    return acc;
  }, {});
  
  // Chemistry distribution
  const chemistryData = cohortStats.map(cohort => ({
    name: `${cohort.manufacturer} ${cohort.chemistry}`,
    median: cohort.median?.toFixed(1),
    mean: cohort.mean?.toFixed(1),
    count: cohort.count,
    p25: cohort.p25,
    p75: cohort.p75
  }));
  
  // Risk distribution
  const highRiskDevices = filteredData.filter(d => {
    const snapshot = snapshots.find(s => s.device_registry_id === d.id);
    return snapshot && snapshot.risk_score > 50;
  });
  
  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Device Longevity Registry</h1>
            <p className="text-sm text-slate-400 mt-1">FDA PMA-credible registry & RUL analytics</p>
          </div>
          <Badge variant="outline" className="border-teal-500/30 text-teal-400">
            <Database className="w-3 h-3 mr-1" />
            {registryData.length} devices tracked
          </Badge>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Active Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{statusBreakdown.active || 0}</div>
              <p className="text-xs text-slate-500 mt-1">Operational status</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Median Longevity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-teal-400">
                {cohortStats[0]?.median?.toFixed(1) || '--'} yr
              </div>
              <p className="text-xs text-slate-500 mt-1">All chemistries</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">High Risk Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-400">{highRiskDevices.length}</div>
              <p className="text-xs text-slate-500 mt-1">Risk score &gt; 50</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">ERI/EOL Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-400">
                {(statusBreakdown.eri || 0) + (statusBreakdown.eol || 0)}
              </div>
              <p className="text-xs text-slate-500 mt-1">Replacement pending</p>
            </CardContent>
          </Card>
        </div>
        
        {/* Tabs */}
        <Tabs defaultValue="cohorts" className="space-y-4">
          <TabsList className="bg-slate-800/30 border border-slate-700/50">
            <TabsTrigger value="cohorts">Cohort Analysis</TabsTrigger>
            <TabsTrigger value="rul">RUL Predictions</TabsTrigger>
            <TabsTrigger value="risk">Risk Stratification</TabsTrigger>
          </TabsList>
          
          {/* Cohort Analysis */}
          <TabsContent value="cohorts" className="space-y-4">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Longevity by Chemistry & Manufacturer</CardTitle>
                <CardDescription>Median lifespan with quartile ranges</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={chemistryData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="name" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
                    <YAxis stroke="#94a3b8" label={{ value: 'Years', angle: -90, position: 'insideLeft' }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                      labelStyle={{ color: '#f1f5f9' }}
                    />
                    <Legend />
                    <Bar dataKey="median" fill="#14b8a6" name="Median Longevity (years)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* RUL Predictions */}
          <TabsContent value="rul" className="space-y-4">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Remaining Useful Life Distribution</CardTitle>
                <CardDescription>Predicted EOL timeline for active devices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {filteredData.slice(0, 10).map(device => {
                    const snapshot = snapshots.find(s => s.device_registry_id === device.id);
                    const rulYears = snapshot?.predicted_rul_days ? (snapshot.predicted_rul_days / 365).toFixed(1) : null;
                    
                    return (
                      <div key={device.id} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="border-slate-700">
                            {device.manufacturer}
                          </Badge>
                          <span className="text-sm text-slate-300">{device.model}</span>
                          <Badge className="bg-purple-900/30 text-purple-400 border-purple-700/50">
                            {device.battery_chemistry}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4">
                          {rulYears && (
                            <>
                              <div className="text-right">
                                <div className="text-sm font-medium text-white">{rulYears} years</div>
                                <div className="text-xs text-slate-500">RUL estimate</div>
                              </div>
                              {snapshot.risk_score > 50 && (
                                <AlertTriangle className="w-4 h-4 text-orange-400" />
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Risk Stratification */}
          <TabsContent value="risk" className="space-y-4">
            <Card className="bg-slate-900/50 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Risk Score Distribution</CardTitle>
                <CardDescription>Early failure risk assessment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {highRiskDevices.map(device => {
                    const snapshot = snapshots.find(s => s.device_registry_id === device.id);
                    return (
                      <div key={device.id} className="p-4 bg-slate-800/30 rounded-lg border border-orange-900/30">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4 text-orange-400" />
                            <span className="text-sm font-medium text-white">{device.device_id}</span>
                            <Badge variant="outline">{device.manufacturer}</Badge>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-orange-400">
                              {snapshot?.risk_score || 0}
                            </div>
                            <div className="text-xs text-slate-500">Risk Score</div>
                          </div>
                        </div>
                        {snapshot?.anomaly_flags && snapshot.anomaly_flags.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {snapshot.anomaly_flags.map((flag, idx) => (
                              <Badge key={idx} variant="outline" className="border-orange-700/50 text-orange-400 text-xs">
                                {flag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}