// ML Model Training and Learning System
import { base44 } from '@/api/base44Client';
import BatteryDegradationModel from './BatteryDegradationModel';
import FailureModePredictor from './FailureModePredictor';
import { BatteryFailureModel, LeadFailureModel, HarvesterFailureModel } from './ComponentFailureModels';
import RULRefinementModel from './RULRefinementModel';
import ModelExplainability from './ModelExplainability';

export class ModelTrainer {
  constructor() {
    this.batteryModel = new BatteryDegradationModel();
    this.failurePredictor = new FailureModePredictor();
    this.batteryFailureModel = new BatteryFailureModel();
    this.leadFailureModel = new LeadFailureModel();
    this.harvesterFailureModel = new HarvesterFailureModel();
    this.rulRefinementModel = new RULRefinementModel();
    this.explainability = new ModelExplainability();
    this.isTraining = false;
    this.trainingProgress = 0;
  }

  /**
   * Collect training data from a completed simulation
   */
  async collectSimulationData(simulation, prototype) {
    if (!simulation.finalState || !simulation.timeSeries) return;

    try {
      const trainingData = {
        prototype_id: prototype.id || prototype.name,
        battery_chemistry: prototype.battery_chemistry,
        simulation_config: simulation.config,
        time_series: simulation.timeSeries,
        final_state: simulation.finalState,
        failures_occurred: simulation.finalState.failures || [],
        actual_eol: simulation.finalState.elapsedYears,
        timestamp: new Date().toISOString()
      };

      await base44.entities.MLTrainingData.create(trainingData);
      
      return trainingData;
    } catch (error) {
      console.error('Failed to collect simulation data:', error);
      return null;
    }
  }

  /**
   * Fetch all historical training data
   */
  async fetchTrainingData(limit = 100) {
    try {
      const data = await base44.entities.MLTrainingData.list('-created_date', limit);
      return data;
    } catch (error) {
      console.error('Failed to fetch training data:', error);
      return [];
    }
  }

  /**
   * Train battery degradation model
   */
  async trainBatteryModel(historicalData, epochs = 50, onProgress) {
    if (historicalData.length < 5) {
      console.warn('Need at least 5 simulations for training');
      return { success: false, message: 'Insufficient training data' };
    }

    try {
      onProgress?.({ phase: 'battery', progress: 0, status: 'Building model...' });
      
      await this.batteryModel.buildModel();
      
      onProgress?.({ phase: 'battery', progress: 20, status: 'Training LSTM...' });
      
      const history = await this.batteryModel.train(historicalData, epochs);
      
      onProgress?.({ phase: 'battery', progress: 80, status: 'Saving model...' });
      
      await this.batteryModel.saveModel();
      
      onProgress?.({ phase: 'battery', progress: 100, status: 'Complete!' });

      return {
        success: true,
        history,
        message: `Trained on ${historicalData.length} simulations`
      };
    } catch (error) {
      console.error('Battery model training failed:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Train failure mode predictors
   */
  async trainFailureModels(historicalData, epochs = 30, onProgress) {
    if (historicalData.length < 10) {
      console.warn('Need at least 10 simulations for failure prediction training');
      return { success: false, message: 'Insufficient training data' };
    }

    try {
      onProgress?.({ phase: 'failure', progress: 0, status: 'Initializing...' });

      const results = await this.failurePredictor.trainAll(historicalData, epochs);
      
      onProgress?.({ phase: 'failure', progress: 80, status: 'Saving models...' });
      
      await this.failurePredictor.saveModels();
      
      onProgress?.({ phase: 'failure', progress: 100, status: 'Complete!' });

      return {
        success: true,
        results,
        message: `Trained 5 failure mode classifiers on ${historicalData.length} simulations`
      };
    } catch (error) {
      console.error('Failure model training failed:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Full training pipeline
   */
  async trainAllModels(onProgress) {
    if (this.isTraining) {
      return { success: false, message: 'Training already in progress' };
    }

    this.isTraining = true;
    this.trainingProgress = 0;

    try {
      onProgress?.({ phase: 'init', progress: 0, status: 'Fetching training data...' });
      
      const historicalData = await this.fetchTrainingData(100);
      
      if (historicalData.length === 0) {
        this.isTraining = false;
        return { 
          success: false, 
          message: 'No training data available. Run some simulations first!' 
        };
      }

      onProgress?.({ 
        phase: 'init', 
        progress: 10, 
        status: `Found ${historicalData.length} training examples` 
      });

      // Train battery model
      const batteryResult = await this.trainBatteryModel(
        historicalData, 
        50, 
        (progress) => onProgress?.({ ...progress, overall: 10 + (progress.progress * 0.4) })
      );

      if (!batteryResult.success) {
        this.isTraining = false;
        return batteryResult;
      }

      // Train failure models
      const failureResult = await this.trainFailureModels(
        historicalData,
        30,
        (progress) => onProgress?.({ ...progress, overall: 50 + (progress.progress * 0.3) })
      );

      // Train component-specific models
      onProgress?.({ phase: 'components', progress: 0, overall: 80, status: 'Training component models...' });
      await this.batteryFailureModel.buildModel();
      await this.batteryFailureModel.train(historicalData.map(d => this.extractBatteryFeatures(d)));
      
      await this.leadFailureModel.buildModel();
      await this.leadFailureModel.train(historicalData.map(d => this.extractLeadFeatures(d)));
      
      await this.harvesterFailureModel.buildModel();
      await this.harvesterFailureModel.train(historicalData.map(d => this.extractHarvesterFeatures(d)));

      // Train RUL refinement model
      onProgress?.({ phase: 'rul', progress: 0, overall: 90, status: 'Training RUL refinement...' });
      const telemetryData = await this.fetchTelemetrySequences();
      if (telemetryData.length > 0) {
        await this.rulRefinementModel.buildModel();
        await this.rulRefinementModel.train(telemetryData);
      }

      this.isTraining = false;
      this.trainingProgress = 100;

      onProgress?.({ 
        phase: 'complete', 
        progress: 100, 
        overall: 100,
        status: 'All models trained successfully!' 
      });

      return {
        success: true,
        battery: batteryResult,
        failure: failureResult,
        trainingDataCount: historicalData.length
      };

    } catch (error) {
      this.isTraining = false;
      console.error('Training pipeline failed:', error);
      return { success: false, message: error.message };
    }
  }

  /**
   * Load pre-trained models
   */
  async loadModels() {
    try {
      const batteryLoaded = await this.batteryModel.loadModel();
      await this.failurePredictor.loadModels();
      
      return {
        batteryModelLoaded: batteryLoaded,
        failureModelsLoaded: Object.keys(this.failurePredictor.models).length > 0
      };
    } catch (error) {
      console.error('Failed to load models:', error);
      return { batteryModelLoaded: false, failureModelsLoaded: false };
    }
  }

  /**
   * Check if models are available
   */
  isModelsReady() {
    return this.batteryModel.isModelReady && 
           Object.keys(this.failurePredictor.models).length > 0;
  }

  /**
   * Get battery degradation prediction
   */
  async predictBatteryDegradation(timeSeries, stepsAhead = 10) {
    if (!this.batteryModel.isModelReady) {
      await this.batteryModel.loadModel();
    }
    return this.batteryModel.predict(timeSeries, stepsAhead);
  }

  /**
   * Get EOL prediction
   */
  async predictEOL(timeSeries, cutoffVoltage) {
    if (!this.batteryModel.isModelReady) {
      await this.batteryModel.loadModel();
    }
    return this.batteryModel.predictEOL(timeSeries, cutoffVoltage);
  }

  /**
   * Get failure predictions
   */
  async predictFailures(currentState, config) {
    if (Object.keys(this.failurePredictor.models).length === 0) {
      await this.failurePredictor.loadModels();
    }
    return this.failurePredictor.predictFailures(currentState, config);
  }

  /**
   * Get top failure risks
   */
  async getTopRisks(currentState, config, topN = 3) {
    if (Object.keys(this.failurePredictor.models).length === 0) {
      await this.failurePredictor.loadModels();
    }
    return this.failurePredictor.getTopRisks(currentState, config, topN);
  }

  /**
   * Get comprehensive prediction with explainability
   */
  async getPredictionWithExplainability(currentState, timeSeries) {
    const eolPrediction = await this.predictEOL(timeSeries, 2.0);
    const failures = await this.predictFailures(currentState, {});
    
    const batteryFailures = this.batteryFailureModel.isReady ? 
      this.batteryFailureModel.predict(currentState) : null;
    const leadFailures = this.leadFailureModel.isReady ? 
      this.leadFailureModel.predict(currentState) : null;
    const harvesterFailures = this.harvesterFailureModel.isReady ? 
      this.harvesterFailureModel.predict(currentState) : null;
    
    let refinedRUL = null;
    if (this.rulRefinementModel.isReady && this.rulRefinementModel.telemetryHistory.length > 0) {
      refinedRUL = this.rulRefinementModel.predictRUL();
    }
    
    const shapValues = this.explainability.calculateSHAPValues(
      currentState,
      { rul_days: eolPrediction?.days || 0, rul_years: (eolPrediction?.days || 0) / 365 },
      null
    );
    
    const clinicalSummary = this.explainability.generateClinicalSummary(
      shapValues,
      refinedRUL || { rul_days: eolPrediction?.days || 0, rul_years: (eolPrediction?.days || 0) / 365 }
    );
    
    return {
      eol: eolPrediction,
      failures,
      componentFailures: {
        battery: batteryFailures,
        lead: leadFailures,
        harvester: harvesterFailures
      },
      refinedRUL,
      shapValues,
      clinicalSummary
    };
  }

  /**
   * Extract battery features for training
   */
  extractBatteryFeatures(data) {
    const finalState = data.final_state;
    return {
      voltage: finalState.voltage,
      soc: finalState.soc,
      internalResistance: finalState.internalResistance,
      years: finalState.elapsedYears,
      temperature: finalState.temperature || 37,
      pacingPercentage: data.simulation_config?.pacingPercentage || 50,
      chemistry: data.battery_chemistry,
      energyHarvesting: data.simulation_config?.energyHarvesting || false,
      voltageSag: finalState.voltage < 2.5,
      impedanceGrowth: finalState.internalResistance > 150,
      prematureDepletion: finalState.soc < 0.1 && finalState.elapsedYears < 8,
      swelling: finalState.temperature > 39
    };
  }

  /**
   * Extract lead features for training
   */
  extractLeadFeatures(data) {
    const finalState = data.final_state;
    return {
      leadImpedance: finalState.leadImpedance || 500,
      pacingThreshold: 2.0,
      years: finalState.elapsedYears,
      pacingPercentage: data.simulation_config?.pacingPercentage || 50,
      modelType: data.prototype_id?.includes('leadless') ? 'leadless' : 'transvenous',
      temperature: finalState.temperature || 37,
      fracture: Math.random() < 0.02,
      insulationBreach: Math.random() < 0.01,
      impedanceAnomaly: finalState.leadImpedance > 1000 || finalState.leadImpedance < 300
    };
  }

  /**
   * Extract harvester features for training
   */
  extractHarvesterFeatures(data) {
    const finalState = data.final_state;
    return {
      harvestedEnergy: finalState.harvestedEnergy || 0,
      supercapCapacitance: finalState.supercapCapacitance || 0.1,
      years: finalState.elapsedYears,
      temperature: finalState.temperature || 37,
      activityLevel: data.simulation_config?.activityLevel || 'moderate',
      harvestingType: data.simulation_config?.harvestingType || 'none',
      thermalCycles: finalState.elapsedYears * 365,
      piezoDegradation: Math.random() < 0.05,
      capacitorFailure: Math.random() < 0.03,
      harvesterDisconnect: Math.random() < 0.02
    };
  }

  /**
   * Fetch telemetry sequences for RUL training
   */
  async fetchTelemetrySequences() {
    try {
      const snapshots = await base44.entities.LongevitySnapshot.list('-snapshot_date', 500);
      
      const deviceSequences = {};
      snapshots.forEach(snapshot => {
        if (!deviceSequences[snapshot.device_registry_id]) {
          deviceSequences[snapshot.device_registry_id] = [];
        }
        deviceSequences[snapshot.device_registry_id].push({
          voltage: snapshot.battery_voltage_v,
          soc: (snapshot.estimated_capacity_remaining_mah || 1000) / 1000,
          internalResistance: snapshot.battery_impedance_ohms || 100,
          leadImpedance: snapshot.lead_impedance_ohms || 500,
          temperature: 37,
          harvestedEnergy: 0,
          pacingPercentage: snapshot.cumulative_pacing_burden_percent || 50
        });
      });
      
      const sequences = Object.values(deviceSequences)
        .filter(seq => seq.length >= 10)
        .map(seq => ({
          sequence: seq,
          rul_days: seq[seq.length - 1]?.predicted_rul_days || 3650
        }));
      
      return sequences;
    } catch (error) {
      console.error('Error fetching telemetry sequences:', error);
      return [];
    }
  }

  /**
   * Add telemetry snapshot for real-time RUL refinement
   */
  addTelemetrySnapshot(snapshot) {
    if (this.rulRefinementModel.isReady) {
      this.rulRefinementModel.addTelemetry(snapshot);
    }
  }

  /**
   * Cleanup
   */
  dispose() {
    this.batteryModel.dispose();
    this.failurePredictor.dispose();
    this.batteryFailureModel.dispose();
    this.leadFailureModel.dispose();
    this.harvesterFailureModel.dispose();
    this.rulRefinementModel.dispose();
  }
}

export default ModelTrainer;