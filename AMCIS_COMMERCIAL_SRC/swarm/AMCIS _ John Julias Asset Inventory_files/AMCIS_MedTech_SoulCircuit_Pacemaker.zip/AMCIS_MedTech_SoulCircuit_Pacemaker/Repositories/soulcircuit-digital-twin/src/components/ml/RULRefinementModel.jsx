// Soul Circuit - Real-time RUL Refinement Model
// Adaptive RUL prediction using streaming telemetry

import * as tf from '@tensorflow/tfjs';

export class RULRefinementModel {
  constructor() {
    this.model = null;
    this.isReady = false;
    this.telemetryHistory = []; // Rolling window of telemetry
    this.windowSize = 30; // 30 snapshots
  }
  
  async buildModel() {
    // LSTM-based model for time-series RUL prediction
    this.model = tf.sequential({
      layers: [
        tf.layers.lstm({ 
          units: 64, 
          inputShape: [this.windowSize, 7], 
          returnSequences: true 
        }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.lstm({ units: 32 }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 16, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'linear' }) // RUL in days
      ]
    });
    
    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['mae']
    });
    
    this.isReady = true;
  }
  
  async train(telemetrySequences) {
    // telemetrySequences: array of { sequence: [...], rul_days: number }
    const sequences = telemetrySequences.map(seq => 
      seq.sequence.slice(-this.windowSize).map(s => [
        s.voltage,
        s.soc,
        s.internalResistance,
        s.leadImpedance || 500,
        s.temperature,
        s.harvestedEnergy || 0,
        s.pacingPercentage || 50
      ])
    );
    
    // Pad sequences if needed
    const paddedSequences = sequences.map(seq => {
      while (seq.length < this.windowSize) {
        seq.unshift([0, 0, 0, 0, 0, 0, 0]);
      }
      return seq;
    });
    
    const labels = telemetrySequences.map(seq => seq.rul_days);
    
    const xs = tf.tensor3d(paddedSequences);
    const ys = tf.tensor2d(labels, [labels.length, 1]);
    
    await this.model.fit(xs, ys, {
      epochs: 100,
      batchSize: 16,
      validationSplit: 0.2,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          if (epoch % 10 === 0) {
            console.log(`RUL Refinement Epoch ${epoch}: loss=${logs.loss.toFixed(4)}, mae=${logs.mae.toFixed(2)} days`);
          }
        }
      }
    });
    
    xs.dispose();
    ys.dispose();
  }
  
  /**
   * Add new telemetry snapshot to history
   */
  addTelemetry(snapshot) {
    this.telemetryHistory.push(snapshot);
    
    // Maintain rolling window
    if (this.telemetryHistory.length > this.windowSize) {
      this.telemetryHistory.shift();
    }
  }
  
  /**
   * Predict refined RUL based on recent telemetry trends
   */
  predictRUL() {
    if (!this.isReady || this.telemetryHistory.length === 0) return null;
    
    // Prepare sequence
    const sequence = this.telemetryHistory.slice(-this.windowSize).map(s => [
      s.voltage,
      s.soc,
      s.internalResistance,
      s.leadImpedance || 500,
      s.temperature,
      s.harvestedEnergy || 0,
      s.pacingPercentage || 50
    ]);
    
    // Pad if needed
    while (sequence.length < this.windowSize) {
      sequence.unshift([0, 0, 0, 0, 0, 0, 0]);
    }
    
    const input = tf.tensor3d([sequence]);
    const prediction = this.model.predict(input);
    const rulDays = prediction.arraySync()[0][0];
    
    input.dispose();
    prediction.dispose();
    
    return {
      rul_days: Math.max(0, Math.round(rulDays)),
      rul_years: (rulDays / 365).toFixed(2),
      confidence: this.calculateConfidence(),
      trend: this.analyzeTrend()
    };
  }
  
  /**
   * Calculate confidence based on telemetry stability
   */
  calculateConfidence() {
    if (this.telemetryHistory.length < 5) return 0.5;
    
    const recentVoltages = this.telemetryHistory.slice(-10).map(s => s.voltage);
    const mean = recentVoltages.reduce((a, b) => a + b, 0) / recentVoltages.length;
    const variance = recentVoltages.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / recentVoltages.length;
    const stdDev = Math.sqrt(variance);
    
    // Lower variance = higher confidence
    const confidence = Math.max(0.5, Math.min(0.95, 1 - (stdDev * 5)));
    return confidence;
  }
  
  /**
   * Analyze degradation trend
   */
  analyzeTrend() {
    if (this.telemetryHistory.length < 10) return 'insufficient_data';
    
    const recent = this.telemetryHistory.slice(-10);
    const voltages = recent.map(s => s.voltage);
    
    // Linear regression slope
    const n = voltages.length;
    const xMean = (n - 1) / 2;
    const yMean = voltages.reduce((a, b) => a + b, 0) / n;
    
    let numerator = 0;
    let denominator = 0;
    
    for (let i = 0; i < n; i++) {
      numerator += (i - xMean) * (voltages[i] - yMean);
      denominator += Math.pow(i - xMean, 2);
    }
    
    const slope = numerator / denominator;
    
    if (slope < -0.005) return 'accelerating_degradation';
    if (slope < -0.001) return 'normal_degradation';
    if (slope < 0.001) return 'stable';
    return 'anomalous_increase'; // voltage increasing is unusual
  }
  
  /**
   * Get feature importance for current prediction
   */
  getFeatureImportance() {
    if (this.telemetryHistory.length === 0) return null;
    
    const latest = this.telemetryHistory[this.telemetryHistory.length - 1];
    
    // Simplified SHAP-like attribution
    return {
      voltage: this.calculateFeatureImpact('voltage', latest.voltage),
      soc: this.calculateFeatureImpact('soc', latest.soc),
      internalResistance: this.calculateFeatureImpact('resistance', latest.internalResistance),
      leadImpedance: this.calculateFeatureImpact('leadImpedance', latest.leadImpedance || 500),
      temperature: this.calculateFeatureImpact('temperature', latest.temperature),
      harvestedEnergy: this.calculateFeatureImpact('harvested', latest.harvestedEnergy || 0)
    };
  }
  
  calculateFeatureImpact(feature, value) {
    // Normalized impact score based on feature ranges
    const impacts = {
      voltage: value < 2.5 ? -0.8 : value < 2.7 ? -0.4 : 0.1,
      soc: value < 0.2 ? -0.9 : value < 0.5 ? -0.5 : 0.1,
      resistance: value > 150 ? -0.7 : value > 120 ? -0.3 : 0.0,
      leadImpedance: (value > 1000 || value < 300) ? -0.5 : 0.0,
      temperature: value > 39 ? -0.4 : 0.0,
      harvested: value > 0.01 ? 0.3 : 0.0
    };
    
    return impacts[feature] || 0;
  }
  
  dispose() {
    if (this.model) {
      this.model.dispose();
    }
  }
}

export default RULRefinementModel;