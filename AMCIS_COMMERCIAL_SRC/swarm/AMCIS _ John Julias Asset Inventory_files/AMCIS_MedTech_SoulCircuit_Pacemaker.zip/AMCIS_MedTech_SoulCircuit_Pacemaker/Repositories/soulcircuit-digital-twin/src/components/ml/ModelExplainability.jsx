// Soul Circuit - ML Model Explainability Engine
// SHAP-inspired feature attribution for clinical interpretability

/**
 * Model Explainability Class
 * Provides SHAP-like values and clinical insights
 */
export class ModelExplainability {
  constructor() {
    this.baselineValues = {
      voltage: 2.8,
      soc: 1.0,
      internalResistance: 100,
      leadImpedance: 500,
      temperature: 37,
      pacingPercentage: 50,
      years: 0
    };
  }
  
  /**
   * Calculate SHAP values for a prediction
   * @param {Object} currentState - Current device state
   * @param {Object} prediction - Model prediction output
   * @param {Function} modelPredict - Model prediction function
   * @returns {Object} SHAP values for each feature
   */
  calculateSHAPValues(currentState, prediction, modelPredict) {
    const features = [
      'voltage', 'soc', 'internalResistance', 'leadImpedance', 
      'temperature', 'pacingPercentage', 'years'
    ];
    
    const shapValues = {};
    
    // Calculate marginal contribution for each feature
    features.forEach(feature => {
      const contribution = this.calculateMarginalContribution(
        feature, 
        currentState, 
        modelPredict
      );
      
      shapValues[feature] = {
        value: contribution,
        impact: this.categorizeImpact(contribution),
        clinicalInterpretation: this.getClinicalInterpretation(feature, contribution, currentState)
      };
    });
    
    return shapValues;
  }
  
  /**
   * Calculate marginal contribution of a feature
   */
  calculateMarginalContribution(feature, state, modelPredict) {
    // Create baseline state
    const baselineState = { ...this.baselineValues };
    
    // Create state with current feature value
    const perturbedState = { ...baselineState, [feature]: state[feature] };
    
    // Predict with baseline
    const baselinePrediction = this.mockPredict(baselineState);
    
    // Predict with perturbed
    const perturbedPrediction = this.mockPredict(perturbedState);
    
    // Marginal contribution
    return perturbedPrediction - baselinePrediction;
  }
  
  /**
   * Mock prediction for SHAP calculation (replace with actual model)
   */
  mockPredict(state) {
    // Simplified RUL prediction formula
    const voltageImpact = (state.voltage - 2.0) / 0.8 * 5; // 0-5 years
    const socImpact = state.soc * 8; // 0-8 years
    const resistanceImpact = (200 - state.internalResistance) / 100 * 2; // -2 to +2 years
    const ageImpact = -(state.years * 0.5); // Negative impact of age
    
    return Math.max(0, voltageImpact + socImpact + resistanceImpact + ageImpact + 2);
  }
  
  /**
   * Categorize impact magnitude
   */
  categorizeImpact(value) {
    if (Math.abs(value) < 0.5) return 'minimal';
    if (Math.abs(value) < 1.5) return 'moderate';
    return 'significant';
  }
  
  /**
   * Get clinical interpretation for feature contribution
   */
  getClinicalInterpretation(feature, contribution, state) {
    const interpretations = {
      voltage: () => {
        if (contribution < -1) return `Low voltage (${state.voltage.toFixed(2)}V) is significantly reducing predicted RUL. Consider replacement planning.`;
        if (contribution > 1) return `Voltage is healthy, contributing positively to longevity.`;
        return `Voltage is within expected range for device age.`;
      },
      soc: () => {
        if (contribution < -1.5) return `Battery capacity depleted (${(state.soc * 100).toFixed(0)}%), major RUL reducer. Replacement imminent.`;
        if (contribution > 2) return `High state of charge indicates significant remaining capacity.`;
        return `Battery capacity aligned with expected degradation curve.`;
      },
      internalResistance: () => {
        if (contribution < -0.8) return `Elevated internal resistance (${state.internalResistance.toFixed(0)}Ω) indicates battery aging. Monitor closely.`;
        if (contribution > 0.5) return `Internal resistance is low, indicating healthy battery chemistry.`;
        return `Internal resistance within normal range for device age.`;
      },
      leadImpedance: () => {
        if (state.leadImpedance > 1000) return `High lead impedance (${state.leadImpedance.toFixed(0)}Ω) may indicate lead issue. Verify capture thresholds.`;
        if (state.leadImpedance < 300) return `Low lead impedance may indicate insulation breach. Clinical evaluation recommended.`;
        return `Lead impedance stable and within therapeutic range.`;
      },
      temperature: () => {
        if (state.temperature > 39) return `Elevated temperature (${state.temperature.toFixed(1)}°C) may accelerate degradation.`;
        return `Temperature within normal physiological range.`;
      },
      pacingPercentage: () => {
        if (state.pacingPercentage > 80) return `High pacing burden (${state.pacingPercentage.toFixed(0)}%) increases energy consumption.`;
        return `Pacing burden within expected parameters.`;
      },
      years: () => {
        if (contribution < -2) return `Device age (${state.years.toFixed(1)} years) is a significant factor. Consider proactive replacement.`;
        return `Device age aligned with expected lifetime trajectory.`;
      }
    };
    
    return interpretations[feature] ? interpretations[feature]() : 'No specific interpretation available.';
  }
  
  /**
   * Generate feature importance ranking
   */
  rankFeatures(shapValues) {
    const features = Object.keys(shapValues).map(key => ({
      name: key,
      contribution: shapValues[key].value,
      absContribution: Math.abs(shapValues[key].value),
      impact: shapValues[key].impact
    }));
    
    return features.sort((a, b) => b.absContribution - a.absContribution);
  }
  
  /**
   * Generate clinical summary
   */
  generateClinicalSummary(shapValues, prediction) {
    const topFeatures = this.rankFeatures(shapValues).slice(0, 3);
    
    const riskLevel = prediction.rul_days < 180 ? 'HIGH' : 
                      prediction.rul_days < 730 ? 'MODERATE' : 'LOW';
    
    const summary = {
      riskLevel,
      predictedRUL: `${prediction.rul_days} days (${prediction.rul_years} years)`,
      primaryDrivers: topFeatures.map(f => ({
        feature: this.humanizeFeatureName(f.name),
        contribution: f.contribution.toFixed(2),
        impact: f.impact,
        interpretation: shapValues[f.name].clinicalInterpretation
      })),
      actionableRecommendations: this.generateRecommendations(shapValues, prediction)
    };
    
    return summary;
  }
  
  /**
   * Generate actionable clinical recommendations
   */
  generateRecommendations(shapValues, prediction) {
    const recommendations = [];
    
    if (shapValues.voltage.value < -1) {
      recommendations.push({
        priority: 'high',
        action: 'Schedule device replacement consultation',
        reason: 'Battery voltage approaching EOL threshold'
      });
    }
    
    if (shapValues.leadImpedance && (shapValues.leadImpedance.value < -0.5)) {
      recommendations.push({
        priority: 'moderate',
        action: 'Verify pacing capture thresholds',
        reason: 'Lead impedance anomaly detected'
      });
    }
    
    if (shapValues.internalResistance.value < -0.8) {
      recommendations.push({
        priority: 'moderate',
        action: 'Increase follow-up frequency',
        reason: 'Accelerated battery degradation observed'
      });
    }
    
    if (prediction.rul_days < 180) {
      recommendations.push({
        priority: 'high',
        action: 'Initiate replacement planning',
        reason: 'RUL < 6 months, approaching ERI'
      });
    }
    
    if (recommendations.length === 0) {
      recommendations.push({
        priority: 'low',
        action: 'Continue routine follow-up',
        reason: 'Device performance within expected parameters'
      });
    }
    
    return recommendations;
  }
  
  /**
   * Humanize feature names for clinical display
   */
  humanizeFeatureName(feature) {
    const names = {
      voltage: 'Battery Voltage',
      soc: 'State of Charge',
      internalResistance: 'Internal Resistance',
      leadImpedance: 'Lead Impedance',
      temperature: 'Temperature',
      pacingPercentage: 'Pacing Burden',
      years: 'Device Age'
    };
    return names[feature] || feature;
  }
}

export default ModelExplainability;