import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Stethoscope, 
  Users, 
  AlertTriangle, 
  TrendingUp, 
  Calendar,
  FileText,
  Activity,
  Clock,
  Battery,
  Shield
} from 'lucide-react';

// Clinical Components
import PatientFilter from '../components/clinical/PatientFilter';
import RiskReportGenerator from '../components/clinical/RiskReportGenerator';
import FollowUpScheduler from '../components/clinical/FollowUpScheduler';
import ExplainabilityPanel from '../components/ml/ExplainabilityPanel';
import RealtimeMonitor from '../components/monitoring/RealtimeMonitor';

export default function ClinicalConsole() {
  const [filters, setFilters] = useState({
    riskLevel: 'all',
    deviceStatus: 'all',
    manufacturer: 'all',
    rulRange: 'all',
    patientId: ''
  });
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [reportPatient, setReportPatient] = useState(null);
  const [schedulePatient, setSchedulePatient] = useState(null);

  // Fetch registry data
  const { data: registryData = [], isLoading } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list()
  });

  // Fetch latest snapshots
  const { data: snapshots = [] } = useQuery({
    queryKey: ['longevitySnapshots'],
    queryFn: () => base44.entities.LongevitySnapshot.list('-snapshot_date', 500)
  });

  // Fetch appointments
  const { data: appointments = [] } = useQuery({
    queryKey: ['followUpAppointments'],
    queryFn: () => base44.entities.FollowUpAppointment.filter({ status: 'scheduled' })
  });

  // Enrich registry data with latest snapshots
  const enrichedPatients = useMemo(() => {
    return registryData.map(device => {
      const latestSnapshot = snapshots
        .filter(s => s.device_registry_id === device.id)
        .sort((a, b) => new Date(b.snapshot_date) - new Date(a.snapshot_date))[0];

      return {
        ...device,
        ...latestSnapshot,
        risk_score: latestSnapshot?.risk_score || 0,
        predicted_rul_days: latestSnapshot?.predicted_rul_days || 0,
        battery_voltage_v: latestSnapshot?.battery_voltage_v || device.nominal_voltage || 0,
        days_since_implant: latestSnapshot?.days_since_implant || 0
      };
    });
  }, [registryData, snapshots]);

  // Apply filters
  const filteredPatients = useMemo(() => {
    return enrichedPatients.filter(patient => {
      // Risk level filter
      if (filters.riskLevel !== 'all') {
        const risk = patient.risk_score;
        if (filters.riskLevel === 'critical' && risk < 80) return false;
        if (filters.riskLevel === 'high' && (risk < 60 || risk >= 80)) return false;
        if (filters.riskLevel === 'moderate' && (risk < 40 || risk >= 60)) return false;
        if (filters.riskLevel === 'low' && risk >= 40) return false;
      }

      // Device status filter
      if (filters.deviceStatus !== 'all' && patient.status !== filters.deviceStatus) {
        return false;
      }

      // Manufacturer filter
      if (filters.manufacturer !== 'all' && patient.manufacturer !== filters.manufacturer) {
        return false;
      }

      // RUL filter
      if (filters.rulRange !== 'all') {
        const rul = patient.predicted_rul_days;
        if (filters.rulRange === 'critical' && rul >= 90) return false;
        if (filters.rulRange === 'warning' && (rul < 90 || rul >= 180)) return false;
        if (filters.rulRange === 'moderate' && (rul < 180 || rul >= 365)) return false;
        if (filters.rulRange === 'good' && rul <= 365) return false;
      }

      // Patient ID search
      if (filters.patientId && !patient.patient_id?.toLowerCase().includes(filters.patientId.toLowerCase())) {
        return false;
      }

      return true;
    });
  }, [enrichedPatients, filters]);

  // Calculate statistics
  const stats = useMemo(() => {
    const critical = filteredPatients.filter(p => p.risk_score >= 80).length;
    const high = filteredPatients.filter(p => p.risk_score >= 60 && p.risk_score < 80).length;
    const eriDevices = filteredPatients.filter(p => p.status === 'eri').length;
    const upcomingAppointments = appointments.filter(a => {
      const daysUntil = Math.floor((new Date(a.scheduled_date) - new Date()) / (1000 * 60 * 60 * 24));
      return daysUntil <= 7 && daysUntil >= 0;
    }).length;

    return { critical, high, eriDevices, upcomingAppointments };
  }, [filteredPatients, appointments]);

  const handleClearFilters = () => {
    setFilters({
      riskLevel: 'all',
      deviceStatus: 'all',
      manufacturer: 'all',
      rulRange: 'all',
      patientId: ''
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Stethoscope className="w-8 h-8 text-teal-400" />
              Clinical Console
            </h1>
            <p className="text-slate-400 mt-1">
              Patient monitoring and risk management dashboard
            </p>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-red-900/20 to-red-800/10 border-red-700/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-red-400 mb-1">Critical Risk</p>
                  <p className="text-2xl font-bold text-white">{stats.critical}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-400 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/20 to-orange-800/10 border-orange-700/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-orange-400 mb-1">High Risk</p>
                  <p className="text-2xl font-bold text-white">{stats.high}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-orange-400 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-900/20 to-yellow-800/10 border-yellow-700/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-yellow-400 mb-1">ERI Devices</p>
                  <p className="text-2xl font-bold text-white">{stats.eriDevices}</p>
                </div>
                <Battery className="w-8 h-8 text-yellow-400 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-teal-900/20 to-teal-800/10 border-teal-700/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-teal-400 mb-1">Next 7 Days</p>
                  <p className="text-2xl font-bold text-white">{stats.upcomingAppointments}</p>
                </div>
                <Calendar className="w-8 h-8 text-teal-400 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <PatientFilter
              filters={filters}
              onFilterChange={setFilters}
              onClearFilters={handleClearFilters}
              totalPatients={enrichedPatients.length}
              filteredCount={filteredPatients.length}
            />
          </div>

          {/* Patient List & Details */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="patients" className="space-y-4">
              <TabsList className="bg-slate-900 border border-slate-700">
                <TabsTrigger value="patients" className="data-[state=active]:bg-teal-900/30">
                  <Users className="w-4 h-4 mr-2" />
                  Patients ({filteredPatients.length})
                </TabsTrigger>
                <TabsTrigger value="appointments" className="data-[state=active]:bg-teal-900/30">
                  <Calendar className="w-4 h-4 mr-2" />
                  Appointments ({appointments.length})
                </TabsTrigger>
                <TabsTrigger value="insights" className="data-[state=active]:bg-teal-900/30">
                  <Activity className="w-4 h-4 mr-2" />
                  Clinical Insights
                </TabsTrigger>
              </TabsList>

              {/* Patients Tab */}
              <TabsContent value="patients">
                <Card className="bg-slate-900/50 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Patient Registry</CardTitle>
                    <CardDescription>
                      {filteredPatients.length} patients match current filters
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[600px] pr-4">
                      <div className="space-y-3">
                        {isLoading ? (
                          <div className="text-center py-12 text-slate-500">
                            <Activity className="w-8 h-8 mx-auto mb-2 animate-pulse" />
                            Loading patients...
                          </div>
                        ) : filteredPatients.length === 0 ? (
                          <div className="text-center py-12 text-slate-500">
                            <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            No patients match current filters
                          </div>
                        ) : (
                          filteredPatients.map(patient => (
                            <PatientCard
                              key={patient.id}
                              patient={patient}
                              isSelected={selectedPatient?.id === patient.id}
                              onSelect={setSelectedPatient}
                              onGenerateReport={setReportPatient}
                              onScheduleFollowUp={setSchedulePatient}
                            />
                          ))
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Appointments Tab */}
              <TabsContent value="appointments">
                <Card className="bg-slate-900/50 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">Scheduled Appointments</CardTitle>
                    <CardDescription>
                      Upcoming follow-up appointments and consultations
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[600px] pr-4">
                      <div className="space-y-3">
                        {appointments.length === 0 ? (
                          <div className="text-center py-12 text-slate-500">
                            <Calendar className="w-8 h-8 mx-auto mb-2 opacity-50" />
                            No scheduled appointments
                          </div>
                        ) : (
                          appointments
                            .sort((a, b) => new Date(a.scheduled_date) - new Date(b.scheduled_date))
                            .map(appointment => (
                              <AppointmentCard key={appointment.id} appointment={appointment} />
                            ))
                        )}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Insights Tab */}
              <TabsContent value="insights">
                {selectedPatient ? (
                  <div className="space-y-6">
                    <RealtimeMonitor deviceId={selectedPatient.id} />
                    <ExplainabilityPanel
                      shapValues={generateMockShapValues(selectedPatient)}
                      clinicalSummary={generateClinicalSummary(selectedPatient)}
                      currentState={selectedPatient}
                    />
                  </div>
                ) : (
                  <Card className="bg-slate-900/50 border-slate-700">
                    <CardContent className="p-12 text-center text-slate-500">
                      <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Select a patient to view real-time insights</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <RiskReportGenerator
        patient={reportPatient}
        isOpen={!!reportPatient}
        onClose={() => setReportPatient(null)}
      />

      <FollowUpScheduler
        patient={schedulePatient}
        isOpen={!!schedulePatient}
        onClose={() => setSchedulePatient(null)}
      />
    </div>
  );
}

// Patient Card Component
function PatientCard({ patient, isSelected, onSelect, onGenerateReport, onScheduleFollowUp }) {
  const riskColor = patient.risk_score >= 80 ? 'border-red-700 bg-red-900/10' :
                    patient.risk_score >= 60 ? 'border-orange-700 bg-orange-900/10' :
                    patient.risk_score >= 40 ? 'border-yellow-700 bg-yellow-900/10' :
                    'border-green-700 bg-green-900/10';

  return (
    <Card 
      className={`cursor-pointer transition-all ${isSelected ? 'ring-2 ring-teal-500' : ''} ${riskColor} border-2`}
      onClick={() => onSelect(patient)}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h4 className="font-semibold text-white mb-1">Patient {patient.patient_id}</h4>
            <p className="text-xs text-slate-400">{patient.manufacturer} {patient.model}</p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge className={getRiskBadgeClass(patient.risk_score)}>
              Risk: {patient.risk_score}
            </Badge>
            <Badge variant="outline" className="text-xs border-slate-600">
              {patient.status}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
          <div>
            <p className="text-slate-500">RUL</p>
            <p className="text-white font-medium">{patient.predicted_rul_days}d</p>
          </div>
          <div>
            <p className="text-slate-500">Voltage</p>
            <p className="text-white font-medium">{patient.battery_voltage_v?.toFixed(2)}V</p>
          </div>
          <div>
            <p className="text-slate-500">Days</p>
            <p className="text-white font-medium">{patient.days_since_implant}</p>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={(e) => {
              e.stopPropagation();
              onGenerateReport(patient);
            }}
            className="flex-1 border-slate-700 text-xs"
          >
            <FileText className="w-3 h-3 mr-1" />
            Report
          </Button>
          <Button
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onScheduleFollowUp(patient);
            }}
            className="flex-1 bg-teal-600 hover:bg-teal-700 text-xs"
          >
            <Calendar className="w-3 h-3 mr-1" />
            Schedule
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Appointment Card Component
function AppointmentCard({ appointment }) {
  const priorityColors = {
    low: 'text-blue-400',
    medium: 'text-yellow-400',
    high: 'text-orange-400',
    critical: 'text-red-400'
  };

  const daysUntil = Math.floor((new Date(appointment.scheduled_date) - new Date()) / (1000 * 60 * 60 * 24));

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h4 className="font-semibold text-white">Patient {appointment.patient_id}</h4>
            <p className="text-xs text-slate-400">{appointment.appointment_type.replace(/_/g, ' ')}</p>
          </div>
          <Badge className={priorityColors[appointment.priority]}>
            {appointment.priority}
          </Badge>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-slate-300 mb-2">
          <Clock className="w-4 h-4" />
          {new Date(appointment.scheduled_date).toLocaleDateString()} - {daysUntil} days
        </div>
        
        {appointment.reason && (
          <p className="text-xs text-slate-500 line-clamp-2">{appointment.reason}</p>
        )}
      </CardContent>
    </Card>
  );
}

function getRiskBadgeClass(score) {
  if (score >= 80) return 'bg-red-900/30 text-red-400';
  if (score >= 60) return 'bg-orange-900/30 text-orange-400';
  if (score >= 40) return 'bg-yellow-900/30 text-yellow-400';
  return 'bg-green-900/30 text-green-400';
}

function generateMockShapValues(patient) {
  return {
    battery_voltage: -0.35,
    lead_impedance: -0.22,
    pacing_burden: 0.18,
    days_since_implant: 0.28,
    battery_impedance: -0.15
  };
}

function generateClinicalSummary(patient) {
  return {
    primaryDrivers: [
      `Battery voltage (${patient.battery_voltage_v?.toFixed(2)}V) showing degradation trend`,
      `Device has been implanted for ${patient.days_since_implant} days`,
      `Lead impedance at ${patient.lead_impedance_ohms}Ω within acceptable range`
    ],
    recommendations: [
      patient.risk_score >= 80 ? 'Schedule urgent evaluation' : 'Continue standard monitoring',
      patient.predicted_rul_days < 90 ? 'Begin replacement planning' : 'Routine follow-up adequate',
      'Review pacing parameters for optimization'
    ]
  };
}