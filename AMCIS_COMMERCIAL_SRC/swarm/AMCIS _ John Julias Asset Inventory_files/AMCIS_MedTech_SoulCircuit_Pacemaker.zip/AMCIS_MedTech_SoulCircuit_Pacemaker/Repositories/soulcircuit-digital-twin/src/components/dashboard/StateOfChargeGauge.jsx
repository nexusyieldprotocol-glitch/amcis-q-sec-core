import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Battery, BatteryFull, BatteryLow, BatteryMedium, BatteryWarning } from 'lucide-react';

export default function StateOfChargeGauge({ soc, voltage, capacityRemaining, initialCapacity }) {
  const percentage = Math.round(soc * 100);
  
  const getColorClass = (pct) => {
    if (pct > 60) return { stroke: '#22C55E', bg: 'from-green-500/20 to-green-500/5', text: 'text-green-400' };
    if (pct > 30) return { stroke: '#F59E0B', bg: 'from-yellow-500/20 to-yellow-500/5', text: 'text-yellow-400' };
    if (pct > 10) return { stroke: '#F97316', bg: 'from-orange-500/20 to-orange-500/5', text: 'text-orange-400' };
    return { stroke: '#EF4444', bg: 'from-red-500/20 to-red-500/5', text: 'text-red-400' };
  };

  const colors = getColorClass(percentage);
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (soc * circumference);

  const BatteryIcon = percentage > 75 ? BatteryFull 
    : percentage > 50 ? BatteryMedium 
    : percentage > 20 ? BatteryLow 
    : BatteryWarning;

  return (
    <Card className={`bg-gradient-to-br ${colors.bg} border-slate-700/50 backdrop-blur-sm`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
          <BatteryIcon className={`w-4 h-4 ${colors.text}`} />
          State of Charge
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center">
          <div className="relative w-32 h-32">
            {/* Background circle */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="45"
                fill="none"
                stroke="#334155"
                strokeWidth="8"
              />
              {/* Progress circle */}
              <circle
                cx="64"
                cy="64"
                r="45"
                fill="none"
                stroke={colors.stroke}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            {/* Center text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-3xl font-bold ${colors.text}`}>{percentage}%</span>
              <span className="text-xs text-slate-500">SOC</span>
            </div>
          </div>
        </div>
        
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Current Voltage</span>
            <span className="text-slate-200 font-medium">{voltage?.toFixed(3) || '—'}V</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Capacity Remaining</span>
            <span className="text-slate-200 font-medium">{capacityRemaining?.toFixed(1) || '—'} mAh</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-500">Initial Capacity</span>
            <span className="text-slate-200 font-medium">{initialCapacity || '—'} mAh</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}