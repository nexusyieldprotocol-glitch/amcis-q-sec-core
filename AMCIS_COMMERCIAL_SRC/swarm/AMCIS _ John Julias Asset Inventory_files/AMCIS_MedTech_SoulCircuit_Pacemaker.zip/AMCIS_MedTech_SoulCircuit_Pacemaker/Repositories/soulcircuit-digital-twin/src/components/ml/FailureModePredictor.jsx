// ML-based Failure Mode Prediction
import * as tf from '@tensorflow/tfjs';

export class FailureModePredictor {
  constructor() {
    this.models = {};
    this.failureModes = [
      'battery_swelling',
      'capacitor_failure',
      'thermal_spike',
      'lead_impedance',
      'voltage_sag'
    ];
    this.featureNames = [
      'voltage', 'soc', 'temperature', 'internalResistance', 
      'elapsedYears', 'pacingRate', 'pacingPercentage',
      'pulseAmplitude', 'energyDelivered'
    ];
  }

  /**
   * Build a binary classifier for each failure mode
   */
  buildClassifier(failureMode) {
    const model = tf.sequential({
      layers: [
        tf.layers.dense({
          units: 32,
          activation: 'relu',
          inputShape: [this.featureNames.length]
        }),
        tf.layers.dropout({ rate: 0.3 }),
        tf.layers.dense({ units: 16, activation: 'relu' }),
        tf.layers.dropout({ rate: 0.2 }),
        tf.layers.dense({ units: 8, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'sigmoid' }) // Binary classification
      ]
    });

    model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });

    this.models[failureMode] = model;
    return model;
  }

  /**
   * Extract features from simulation state
   */
  extractFeatures(state, config) {
    return [
      state.voltage || 0,
      state.soc || 0,
      state.temperature || 0,
      state.internalResistance || 0,
      state.elapsedYears || 0,
      config.pacingRate || 70,
      config.pacingPercentage || 50,
      config.pulseAmplitude || 2.5,
      state.energyDelivered || 0
    ];
  }

  /**
   * Prepare training data for a specific failure mode
   */
  prepareTrainingData(historicalData, failureMode) {
    const features = [];
    const labels = [];

    for (const simulation of historicalData) {
      if (!simulation.final_state || !simulation.simulation_config) continue;

      const feature = this.extractFeatures(
        simulation.final_state,
        simulation.simulation_config
      );

      // Check if this failure occurred
      const failureOccurred = simulation.failures_occurred?.some(
        f => f.type === failureMode
      ) ? 1 : 0;

      features.push(feature);
      labels.push(failureOccurred);
    }

    if (features.length === 0) return null;

    // Handle class imbalance with data augmentation for positive cases
    const positiveIndices = labels.map((l, i) => l === 1 ? i : -1).filter(i => i !== -1);
    const positiveCount = positiveIndices.length;
    const negativeCount = labels.length - positiveCount;

    // Augment positive cases if they're underrepresented
    if (positiveCount > 0 && negativeCount > positiveCount * 3) {
      const augmentations = Math.min(negativeCount - positiveCount, positiveCount * 2);
      for (let i = 0; i < augmentations; i++) {
        const idx = positiveIndices[i % positiveCount];
        const augmentedFeature = features[idx].map(f => f + (Math.random() - 0.5) * 0.1);
        features.push(augmentedFeature);
        labels.push(1);
      }
    }

    const X = tf.tensor2d(features);
    const y = tf.tensor2d(labels, [labels.length, 1]);

    return { X, y };
  }

  /**
   * Train classifier for a specific failure mode
   */
  async trainFailureMode(failureMode, historicalData, epochs = 30) {
    if (!this.models[failureMode]) {
      this.buildClassifier(failureMode);
    }

    const trainingData = this.prepareTrainingData(historicalData, failureMode);
    if (!trainingData) {
      console.warn(`Insufficient training data for ${failureMode}`);
      return null;
    }

    const { X, y } = trainingData;

    const history = await this.models[failureMode].fit(X, y, {
      epochs: epochs,
      validationSplit: 0.2,
      batchSize: 16,
      shuffle: true,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          if (epoch % 10 === 0) {
            console.log(`${failureMode} - Epoch ${epoch}: loss = ${logs.loss.toFixed(4)}, acc = ${logs.acc.toFixed(4)}`);
          }
        }
      }
    });

    X.dispose();
    y.dispose();

    return history;
  }

  /**
   * Train all failure mode classifiers
   */
  async trainAll(historicalData, epochs = 30) {
    const results = {};
    
    for (const failureMode of this.failureModes) {
      console.log(`Training ${failureMode} predictor...`);
      const history = await this.trainFailureMode(failureMode, historicalData, epochs);
      results[failureMode] = history;
    }

    return results;
  }

  /**
   * Predict probability of each failure mode
   */
  async predictFailures(currentState, config) {
    const features = this.extractFeatures(currentState, config);
    const inputTensor = tf.tensor2d([features]);

    const predictions = {};

    for (const failureMode of this.failureModes) {
      if (!this.models[failureMode]) {
        predictions[failureMode] = { probability: 0, confidence: 'low' };
        continue;
      }

      const prediction = this.models[failureMode].predict(inputTensor);
      const probability = (await prediction.data())[0];
      
      prediction.dispose();

      // Determine confidence level
      let confidence = 'low';
      if (probability > 0.7 || probability < 0.3) confidence = 'high';
      else if (probability > 0.6 || probability < 0.4) confidence = 'medium';

      predictions[failureMode] = {
        probability,
        confidence,
        risk: probability > 0.5 ? 'high' : probability > 0.3 ? 'medium' : 'low'
      };
    }

    inputTensor.dispose();

    return predictions;
  }

  /**
   * Get top failure risks
   */
  async getTopRisks(currentState, config, topN = 3) {
    const predictions = await this.predictFailures(currentState, config);
    
    const sorted = Object.entries(predictions)
      .sort(([, a], [, b]) => b.probability - a.probability)
      .slice(0, topN);

    return sorted.map(([mode, pred]) => ({
      mode,
      ...pred
    }));
  }

  /**
   * Save all models
   */
  async saveModels() {
    for (const failureMode of this.failureModes) {
      if (this.models[failureMode]) {
        await this.models[failureMode].save(`localstorage://failure-${failureMode}`);
      }
    }
  }

  /**
   * Load all models
   */
  async loadModels() {
    for (const failureMode of this.failureModes) {
      try {
        this.models[failureMode] = await tf.loadLayersModel(`localstorage://failure-${failureMode}`);
      } catch (error) {
        console.warn(`No saved model for ${failureMode}`);
      }
    }
  }

  /**
   * Cleanup
   */
  dispose() {
    for (const model of Object.values(this.models)) {
      if (model) model.dispose();
    }
    this.models = {};
  }
}

export default FailureModePredictor;