import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { 
  Activity, TrendingUp, AlertTriangle, Clock, 
  Play, Pause, Database, Radio
} from 'lucide-react';
import TelemetrySimulator from './TelemetrySimulator';
import LongevityModel from './LongevityModel';

export default function RealtimeRegistryDashboard() {
  const [isStreaming, setIsStreaming] = useState(false);
  const [telemetrySimulator] = useState(() => new TelemetrySimulator());
  const [longevityModel] = useState(() => new LongevityModel());
  const [liveData, setLiveData] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState(null);
  
  // Fetch registry data
  const { data: registryData = [], refetch: refetchRegistry } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list('-implant_date', 50)
  });
  
  // Subscribe to real-time snapshot updates
  useEffect(() => {
    const unsubscribe = base44.entities.LongevitySnapshot.subscribe((event) => {
      if (event.type === 'create') {
        setLiveData(prev => {
          const updated = [...prev, {
            timestamp: new Date(event.data.snapshot_date).getTime(),
            voltage: event.data.battery_voltage_v,
            risk_score: event.data.risk_score,
            rul_days: event.data.predicted_rul_days,
            device_id: event.data.device_registry_id
          }];
          // Keep last 50 data points
          return updated.slice(-50);
        });
      }
    });
    
    return unsubscribe;
  }, []);
  
  // Initialize simulator with registry devices
  useEffect(() => {
    if (registryData.length > 0 && !isStreaming) {
      telemetrySimulator.batchInitializeDevices(registryData)
        .then(snapshots => {
          console.log(`Initialized ${snapshots.length} virtual devices`);
        });
    }
  }, [registryData, telemetrySimulator, isStreaming]);
  
  // Streaming loop
  useEffect(() => {
    if (!isStreaming || registryData.length === 0) return;
    
    const deviceIds = registryData.slice(0, 10).map(d => d.device_id);
    
    const streamInterval = setInterval(async () => {
      for (const device_id of deviceIds) {
        try {
          const snapshot = telemetrySimulator.stepAndSnapshot(device_id);
          
          // Send to backend API
          const response = await base44.functions.invoke('deviceTelemetry', snapshot);
          
          if (response.data.success) {
            console.log(`Telemetry processed for ${device_id}: RUL ${response.data.rul_days} days`);
          }
        } catch (error) {
          console.error(`Streaming error for ${device_id}:`, error);
        }
      }
      
      // Refetch registry to update status
      refetchRegistry();
    }, 3000); // Update every 3 seconds
    
    return () => clearInterval(streamInterval);
  }, [isStreaming, registryData, telemetrySimulator, refetchRegistry]);
  
  // Device status summary
  const statusSummary = registryData.reduce((acc, device) => {
    acc[device.status] = (acc[device.status] || 0) + 1;
    return acc;
  }, {});
  
  // Chart data from live stream
  const chartData = liveData.map((point, idx) => ({
    index: idx,
    voltage: point.voltage,
    risk: point.risk_score
  }));
  
  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Radio className={`w-6 h-6 ${isStreaming ? 'text-green-400 animate-pulse' : 'text-slate-600'}`} />
              Real-time Device Registry
            </h1>
            <p className="text-sm text-slate-400 mt-1">Live telemetry streaming & RUL monitoring</p>
          </div>
          
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="border-teal-500/30 text-teal-400">
              <Database className="w-3 h-3 mr-1" />
              {registryData.length} devices
            </Badge>
            
            <Button
              onClick={() => setIsStreaming(!isStreaming)}
              className={isStreaming ? 'bg-orange-600 hover:bg-orange-700' : 'bg-teal-600 hover:bg-teal-700'}
            >
              {isStreaming ? (
                <>
                  <Pause className="w-4 h-4 mr-2" />
                  Stop Stream
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Start Stream
                </>
              )}
            </Button>
          </div>
        </div>
        
        {/* Live Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Active Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400">{statusSummary.active || 0}</div>
              <p className="text-xs text-slate-500 mt-1">Operational</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Streaming Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-teal-400">
                {isStreaming ? '3s' : '--'}
              </div>
              <p className="text-xs text-slate-500 mt-1">Update interval</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Data Points</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-400">{liveData.length}</div>
              <p className="text-xs text-slate-500 mt-1">Live snapshots</p>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-900/50 border-slate-800">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400">Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-400">
                {(statusSummary.eri || 0) + (statusSummary.eol || 0)}
              </div>
              <p className="text-xs text-slate-500 mt-1">ERI/EOL devices</p>
            </CardContent>
          </Card>
        </div>
        
        {/* Live Telemetry Chart */}
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-teal-400" />
              Live Telemetry Stream
            </CardTitle>
            <CardDescription>Real-time voltage and risk tracking</CardDescription>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="index" stroke="#94a3b8" label={{ value: 'Sample', position: 'insideBottom' }} />
                  <YAxis yAxisId="left" stroke="#14b8a6" label={{ value: 'Voltage (V)', angle: -90, position: 'insideLeft' }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#f97316" label={{ value: 'Risk Score', angle: 90, position: 'insideRight' }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                    labelStyle={{ color: '#f1f5f9' }}
                  />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="voltage" stroke="#14b8a6" name="Battery Voltage (V)" dot={false} strokeWidth={2} />
                  <Line yAxisId="right" type="monotone" dataKey="risk" stroke="#f97316" name="Risk Score" dot={false} strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                <Activity className="w-12 h-12 mb-4 opacity-50" />
                <p className="text-sm">Start streaming to view live telemetry data</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Device List with Live Updates */}
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Device Fleet Status</CardTitle>
            <CardDescription>Click device for detailed view</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {registryData.slice(0, 20).map(device => {
                const isActive = device.status === 'active';
                const isAlert = device.status === 'eri' || device.status === 'eol';
                
                return (
                  <div
                    key={device.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedDevice?.id === device.id
                        ? 'bg-teal-900/30 border-teal-700'
                        : 'bg-slate-800/30 border-slate-700/50 hover:border-slate-600'
                    }`}
                    onClick={() => setSelectedDevice(device)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${
                          isActive ? 'bg-green-400 animate-pulse' : 
                          isAlert ? 'bg-orange-400 animate-pulse' : 'bg-slate-600'
                        }`} />
                        <div>
                          <div className="text-sm font-medium text-white">{device.device_id}</div>
                          <div className="text-xs text-slate-400">
                            {device.manufacturer} • {device.battery_chemistry}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={
                          isActive ? 'border-green-700/50 text-green-400' :
                          isAlert ? 'border-orange-700/50 text-orange-400' :
                          'border-slate-700 text-slate-400'
                        }>
                          {device.status}
                        </Badge>
                        {isAlert && <AlertTriangle className="w-4 h-4 text-orange-400" />}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}