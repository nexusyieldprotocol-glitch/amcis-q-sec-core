import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { GitCompare, TrendingUp, Award } from 'lucide-react';

export default function ComparativeAnalysis({ registryData, snapshots }) {
  const [comparisonMode, setComparisonMode] = useState('manufacturer');
  const [selectedMetric, setSelectedMetric] = useState('longevity');

  const comparisonData = useMemo(() => {
    if (!registryData.length) return [];

    const groups = {};
    
    registryData.forEach(device => {
      const key = comparisonMode === 'manufacturer' ? device.manufacturer : device.battery_chemistry;
      if (!groups[key]) {
        groups[key] = {
          devices: [],
          snapshots: []
        };
      }
      groups[key].devices.push(device);
      
      const deviceSnapshots = snapshots.filter(s => s.device_registry_id === device.id);
      groups[key].snapshots.push(...deviceSnapshots);
    });

    return Object.keys(groups).map(key => {
      const group = groups[key];
      const activeDevices = group.devices.filter(d => d.status === 'active');
      
      // Calculate metrics
      const rulValues = group.snapshots
        .map(s => s.predicted_rul_days)
        .filter(v => v > 0);
      const avgRUL = rulValues.length ? rulValues.reduce((a, b) => a + b, 0) / rulValues.length : 0;
      
      const voltages = group.snapshots
        .map(s => s.battery_voltage_v)
        .filter(v => v > 0);
      const avgVoltage = voltages.length ? voltages.reduce((a, b) => a + b, 0) / voltages.length : 0;
      
      const riskScores = group.snapshots
        .map(s => s.risk_score)
        .filter(v => v >= 0);
      const avgRisk = riskScores.length ? riskScores.reduce((a, b) => a + b, 0) / riskScores.length : 0;

      const longevityValues = group.devices
        .filter(d => d.actual_longevity_years)
        .map(d => d.actual_longevity_years);
      const avgLongevity = longevityValues.length ? longevityValues.reduce((a, b) => a + b, 0) / longevityValues.length : 0;

      const revisionRate = group.devices.length > 0 
        ? (group.devices.filter(d => d.revision_flag).length / group.devices.length) * 100 
        : 0;

      return {
        name: key,
        deviceCount: group.devices.length,
        activeCount: activeDevices.length,
        avgRUL: Math.round(avgRUL),
        avgVoltage: avgVoltage.toFixed(2),
        avgRisk: Math.round(avgRisk),
        avgLongevity: avgLongevity.toFixed(1),
        revisionRate: revisionRate.toFixed(1),
        reliability: 100 - revisionRate
      };
    }).sort((a, b) => b.deviceCount - a.deviceCount);
  }, [registryData, snapshots, comparisonMode]);

  // Radar chart data for multi-metric comparison
  const radarData = useMemo(() => {
    const maxValues = {
      avgRUL: Math.max(...comparisonData.map(d => d.avgRUL), 1),
      avgVoltage: Math.max(...comparisonData.map(d => parseFloat(d.avgVoltage)), 1),
      reliability: 100,
      avgLongevity: Math.max(...comparisonData.map(d => parseFloat(d.avgLongevity)), 1)
    };

    return comparisonData.slice(0, 5).map(item => ({
      category: item.name,
      RUL: ((item.avgRUL / maxValues.avgRUL) * 100).toFixed(0),
      Voltage: ((parseFloat(item.avgVoltage) / maxValues.avgVoltage) * 100).toFixed(0),
      Reliability: item.reliability.toFixed(0),
      Longevity: ((parseFloat(item.avgLongevity) / maxValues.avgLongevity) * 100).toFixed(0)
    }));
  }, [comparisonData]);

  const metricConfigs = {
    longevity: { key: 'avgLongevity', label: 'Avg Longevity (years)', color: '#14b8a6' },
    rul: { key: 'avgRUL', label: 'Avg RUL (days)', color: '#3b82f6' },
    risk: { key: 'avgRisk', label: 'Avg Risk Score', color: '#f97316' },
    reliability: { key: 'reliability', label: 'Reliability (%)', color: '#10b981' }
  };

  const currentMetric = metricConfigs[selectedMetric];

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="text-xs text-slate-400 mb-1 block">Compare By</label>
              <Select value={comparisonMode} onValueChange={setComparisonMode}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="manufacturer">Manufacturer</SelectItem>
                  <SelectItem value="battery_chemistry">Battery Chemistry</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="text-xs text-slate-400 mb-1 block">Primary Metric</label>
              <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="longevity">Longevity</SelectItem>
                  <SelectItem value="rul">Remaining Useful Life</SelectItem>
                  <SelectItem value="risk">Risk Score</SelectItem>
                  <SelectItem value="reliability">Reliability</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Comparative Bar Chart */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-teal-400" />
            {comparisonMode === 'manufacturer' ? 'Manufacturer' : 'Chemistry'} Comparison
          </CardTitle>
          <CardDescription>{currentMetric.label} across different groups</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={comparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                labelStyle={{ color: '#f1f5f9' }}
              />
              <Legend />
              <Bar dataKey={currentMetric.key} fill={currentMetric.color} name={currentMetric.label} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Multi-Metric Radar */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-400" />
            Multi-Metric Performance Radar
          </CardTitle>
          <CardDescription>Normalized performance across key metrics (top 5 groups)</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="#334155" />
              <PolarAngleAxis dataKey="category" stroke="#94a3b8" />
              <PolarRadiusAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                labelStyle={{ color: '#f1f5f9' }}
              />
              <Legend />
              <Radar name="RUL" dataKey="RUL" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.3} />
              <Radar name="Voltage" dataKey="Voltage" stroke="#14b8a6" fill="#14b8a6" fillOpacity={0.3} />
              <Radar name="Reliability" dataKey="Reliability" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
              <Radar name="Longevity" dataKey="Longevity" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.3} />
            </RadarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Detailed Comparison Table */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Detailed Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {comparisonData.map((item, idx) => (
              <div key={item.name} className="p-3 bg-slate-800/30 rounded-lg border border-slate-700/50">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs border-teal-700/50 text-teal-400">
                      #{idx + 1}
                    </Badge>
                    <span className="font-medium text-white">{item.name}</span>
                    <Badge variant="outline" className="text-xs border-slate-600">
                      {item.deviceCount} devices
                    </Badge>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-slate-500 text-xs">Avg RUL</p>
                    <p className="text-white font-medium">{item.avgRUL}d</p>
                  </div>
                  <div>
                    <p className="text-slate-500 text-xs">Longevity</p>
                    <p className="text-white font-medium">{item.avgLongevity}y</p>
                  </div>
                  <div>
                    <p className="text-slate-500 text-xs">Reliability</p>
                    <p className="text-white font-medium">{item.reliability}%</p>
                  </div>
                  <div>
                    <p className="text-slate-500 text-xs">Risk Score</p>
                    <p className="text-white font-medium">{item.avgRisk}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}