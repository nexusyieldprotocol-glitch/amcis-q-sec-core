import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { GitBranch, CheckCircle2, RotateCcw, TrendingUp, Activity, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function ModelVersionManager() {
  const queryClient = useQueryClient();
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [rollbackDialogOpen, setRollbackDialogOpen] = useState(false);

  const { data: versions = [], isLoading } = useQuery({
    queryKey: ['mlModelVersions'],
    queryFn: () => base44.entities.MLModelVersion.list('-training_date', 50)
  });

  const { data: trainingData = [] } = useQuery({
    queryKey: ['mlTrainingData'],
    queryFn: () => base44.entities.MLTrainingData.list()
  });

  const rollbackMutation = useMutation({
    mutationFn: async (versionId) => {
      const version = versions.find(v => v.id === versionId);
      
      // Deactivate current active version
      const currentActive = versions.find(v => v.is_active);
      if (currentActive) {
        await base44.entities.MLModelVersion.update(currentActive.id, { is_active: false });
      }
      
      // Activate selected version
      return base44.entities.MLModelVersion.update(versionId, { is_active: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['mlModelVersions']);
      toast.success('Model rolled back successfully');
      setRollbackDialogOpen(false);
    }
  });

  const activeVersion = versions.find(v => v.is_active);
  const latestDataCount = trainingData.length;
  const newDataSinceLastTrain = activeVersion 
    ? latestDataCount - activeVersion.training_data_count 
    : latestDataCount;

  return (
    <div className="space-y-6">
      {/* Status Banner */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Activity className="w-4 h-4 text-teal-400" />
                <span className="text-sm text-slate-400">Active Model Version</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold text-white">
                  {activeVersion?.version || 'No model trained'}
                </span>
                {activeVersion && (
                  <Badge variant="outline" className="border-green-700/50 text-green-400">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                )}
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400 mb-1">New Training Data</p>
              <div className="flex items-center gap-2">
                <span className={`text-xl font-bold ${newDataSinceLastTrain >= 10 ? 'text-orange-400' : 'text-white'}`}>
                  {newDataSinceLastTrain}
                </span>
                {newDataSinceLastTrain >= 10 && (
                  <AlertCircle className="w-4 h-4 text-orange-400" />
                )}
              </div>
              {newDataSinceLastTrain >= 10 && (
                <p className="text-xs text-orange-400 mt-1">Retraining recommended</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Version History */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-purple-400" />
            Model Version History
          </CardTitle>
          <CardDescription>
            Track model performance across versions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {isLoading ? (
                <div className="text-center py-8 text-slate-500">
                  <Activity className="w-8 h-8 mx-auto mb-2 animate-pulse" />
                  Loading versions...
                </div>
              ) : versions.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <GitBranch className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  No model versions yet
                </div>
              ) : (
                versions.map((version, idx) => (
                  <VersionCard
                    key={version.id}
                    version={version}
                    isLatest={idx === 0}
                    onSelect={setSelectedVersion}
                    onRollback={() => {
                      setSelectedVersion(version);
                      setRollbackDialogOpen(true);
                    }}
                  />
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Performance Comparison */}
      {selectedVersion && (
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Training History - v{selectedVersion.version}</CardTitle>
            <CardDescription>Loss and accuracy over training epochs</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={selectedVersion.training_history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="epoch" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelStyle={{ color: '#f1f5f9' }}
                />
                <Legend />
                <Line type="monotone" dataKey="loss" stroke="#f97316" name="Training Loss" strokeWidth={2} />
                <Line type="monotone" dataKey="val_loss" stroke="#ef4444" name="Validation Loss" strokeWidth={2} />
                <Line type="monotone" dataKey="accuracy" stroke="#14b8a6" name="Training Accuracy" strokeWidth={2} />
                <Line type="monotone" dataKey="val_accuracy" stroke="#10b981" name="Validation Accuracy" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Rollback Confirmation */}
      <Dialog open={rollbackDialogOpen} onOpenChange={setRollbackDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <RotateCcw className="w-5 h-5 text-orange-400" />
              Rollback to v{selectedVersion?.version}
            </DialogTitle>
            <DialogDescription>
              This will make version {selectedVersion?.version} the active model. Current predictions will use this model.
            </DialogDescription>
          </DialogHeader>
          {selectedVersion && (
            <div className="space-y-3">
              <div className="p-3 bg-slate-800/50 rounded-lg">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-slate-400 text-xs">Accuracy</p>
                    <p className="text-white font-medium">
                      {(selectedVersion.performance_metrics.accuracy * 100).toFixed(1)}%
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs">Val Accuracy</p>
                    <p className="text-white font-medium">
                      {(selectedVersion.performance_metrics.val_accuracy * 100).toFixed(1)}%
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs">Training Data</p>
                    <p className="text-white font-medium">{selectedVersion.training_data_count}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-xs">Trained</p>
                    <p className="text-white font-medium">
                      {format(new Date(selectedVersion.training_date), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setRollbackDialogOpen(false)} className="border-slate-700">
              Cancel
            </Button>
            <Button
              onClick={() => rollbackMutation.mutate(selectedVersion.id)}
              disabled={rollbackMutation.isPending}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              {rollbackMutation.isPending ? 'Rolling back...' : 'Confirm Rollback'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function VersionCard({ version, isLatest, onSelect, onRollback }) {
  const metrics = version.performance_metrics;
  const isActive = version.is_active;

  return (
    <Card 
      className={`cursor-pointer transition-all ${
        isActive ? 'border-2 border-green-700 bg-green-900/10' : 'border border-slate-700 hover:border-slate-600'
      }`}
      onClick={() => onSelect(version)}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-lg font-bold text-white">v{version.version}</span>
              {isActive && (
                <Badge className="bg-green-900/30 text-green-400 border-green-700/50">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Active
                </Badge>
              )}
              {isLatest && !isActive && (
                <Badge variant="outline" className="border-blue-700/50 text-blue-400">
                  Latest
                </Badge>
              )}
            </div>
            <p className="text-xs text-slate-500">
              {format(new Date(version.training_date), 'MMM d, yyyy HH:mm')}
            </p>
          </div>
          {!isActive && (
            <Button
              size="sm"
              variant="outline"
              onClick={(e) => {
                e.stopPropagation();
                onRollback();
              }}
              className="border-orange-700/50 text-orange-400 hover:bg-orange-900/20"
            >
              <RotateCcw className="w-3 h-3 mr-1" />
              Rollback
            </Button>
          )}
        </div>

        <div className="grid grid-cols-4 gap-2 text-xs mb-2">
          <div>
            <p className="text-slate-500">Accuracy</p>
            <p className="text-white font-medium">{(metrics.accuracy * 100).toFixed(1)}%</p>
          </div>
          <div>
            <p className="text-slate-500">Loss</p>
            <p className="text-white font-medium">{metrics.loss.toFixed(3)}</p>
          </div>
          <div>
            <p className="text-slate-500">MAE</p>
            <p className="text-white font-medium">{metrics.mae.toFixed(1)}</p>
          </div>
          <div>
            <p className="text-slate-500">Samples</p>
            <p className="text-white font-medium">{version.training_data_count}</p>
          </div>
        </div>

        {version.notes && (
          <p className="text-xs text-slate-400 line-clamp-2">{version.notes}</p>
        )}
      </CardContent>
    </Card>
  );
}