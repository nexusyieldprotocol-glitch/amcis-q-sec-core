import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Settings, Activity, AlertTriangle } from 'lucide-react';

import ActiveAlertsPanel from '../components/alerts/ActiveAlertsPanel';
import AlertConfigForm from '../components/alerts/AlertConfigForm';
import AlertDashboard from '../components/alerts/AlertDashboard';

export default function AlertManagement() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => base44.entities.Alert.list('-triggered_at', 500)
  });

  const { data: configs = [] } = useQuery({
    queryKey: ['alertConfigs'],
    queryFn: () => base44.entities.AlertConfiguration.list('-created_date', 100)
  });

  const activeAlerts = alerts.filter(a => !a.acknowledged && !a.resolved);
  const criticalAlerts = activeAlerts.filter(a => a.severity === 'critical');

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Bell className="w-8 h-8 text-teal-400" />
              Alert Management
            </h1>
            <p className="text-slate-400 mt-1">
              Real-time monitoring and notification system
            </p>
          </div>
          <div className="flex gap-4 text-sm">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-400">{criticalAlerts.length}</p>
              <p className="text-xs text-slate-500">Critical</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-400">{activeAlerts.length}</p>
              <p className="text-xs text-slate-500">Active</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-teal-400">{configs.filter(c => c.enabled).length}</p>
              <p className="text-xs text-slate-500">Configured</p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-slate-900 border border-slate-700">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-teal-900/30">
              <Activity className="w-4 h-4 mr-2" />
              Alert Dashboard
            </TabsTrigger>
            <TabsTrigger value="active" className="data-[state=active]:bg-teal-900/30">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Active Alerts ({activeAlerts.length})
            </TabsTrigger>
            <TabsTrigger value="config" className="data-[state=active]:bg-teal-900/30">
              <Settings className="w-4 h-4 mr-2" />
              Configuration
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <AlertDashboard alerts={alerts} configs={configs} />
          </TabsContent>

          <TabsContent value="active">
            <ActiveAlertsPanel alerts={activeAlerts} />
          </TabsContent>

          <TabsContent value="config">
            <AlertConfigForm configs={configs} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}