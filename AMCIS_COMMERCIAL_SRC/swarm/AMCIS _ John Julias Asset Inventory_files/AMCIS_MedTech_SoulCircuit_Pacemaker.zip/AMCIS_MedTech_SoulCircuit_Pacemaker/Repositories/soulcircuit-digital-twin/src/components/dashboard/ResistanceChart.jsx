import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, ComposedChart } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity } from 'lucide-react';

export default function ResistanceChart({ data, initialResistance }) {
  if (!data || data.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-purple-400" />
            Internal Resistance
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64 flex items-center justify-center">
          <p className="text-slate-500 text-sm">Run simulation to view data</p>
        </CardContent>
      </Card>
    );
  }

  const chartData = data.map(d => ({
    years: d.years.toFixed(2),
    resistance: d.internalResistance
  }));

  const currentResistance = chartData[chartData.length - 1]?.resistance || initialResistance;
  const resistanceIncrease = ((currentResistance - initialResistance) / initialResistance * 100).toFixed(1);

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-purple-400" />
            Internal Resistance Degradation
          </CardTitle>
          <Badge variant="outline" className="text-xs border-purple-500/50 text-purple-400">
            +{resistanceIncrease}% from baseline
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="resistanceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#A855F7" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#A855F7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis 
                dataKey="years" 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
              />
              <YAxis 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
                domain={['auto', 'auto']}
                label={{ value: 'Resistance (Ω)', angle: -90, position: 'insideLeft', fill: '#64748B', fontSize: 10 }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1E293B', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
                labelStyle={{ color: '#94A3B8' }}
                formatter={(value) => [value.toFixed(2) + 'Ω', 'Resistance']}
                labelFormatter={(label) => `Year ${label}`}
              />
              <Area
                type="monotone"
                dataKey="resistance"
                fill="url(#resistanceGradient)"
                stroke="none"
              />
              <Line 
                type="monotone" 
                dataKey="resistance" 
                stroke="#A855F7" 
                strokeWidth={2}
                dot={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}