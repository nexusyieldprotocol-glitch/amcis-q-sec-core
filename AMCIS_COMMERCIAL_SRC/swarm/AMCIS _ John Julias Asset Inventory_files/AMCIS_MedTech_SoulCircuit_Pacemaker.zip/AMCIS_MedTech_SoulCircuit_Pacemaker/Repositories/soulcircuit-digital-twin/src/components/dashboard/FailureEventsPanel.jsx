import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertTriangle, AlertCircle, Info, CheckCircle, Clock, XCircle } from 'lucide-react';

export default function FailureEventsPanel({ failures = [], warnings = [], isOperational, eolReached, predictedEOL }) {
  const severityConfig = {
    critical: { 
      icon: XCircle, 
      color: 'text-red-400', 
      bg: 'bg-red-500/10', 
      border: 'border-red-500/30' 
    },
    moderate: { 
      icon: AlertTriangle, 
      color: 'text-yellow-400', 
      bg: 'bg-yellow-500/10', 
      border: 'border-yellow-500/30' 
    },
    warning: { 
      icon: AlertCircle, 
      color: 'text-orange-400', 
      bg: 'bg-orange-500/10', 
      border: 'border-orange-500/30' 
    },
    info: { 
      icon: Info, 
      color: 'text-blue-400', 
      bg: 'bg-blue-500/10', 
      border: 'border-blue-500/30' 
    }
  };

  const allEvents = [
    ...failures.map(f => ({ ...f, eventType: 'failure' })),
    ...warnings.map(w => ({ ...w, severity: 'warning', eventType: 'warning' }))
  ].sort((a, b) => (a.detectedAt || 0) - (b.detectedAt || 0));

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            Failure Mode Analysis
          </CardTitle>
          {isOperational !== undefined && (
            <Badge 
              variant="outline" 
              className={`text-xs ${
                isOperational 
                  ? 'border-green-500/50 text-green-400' 
                  : 'border-red-500/50 text-red-400'
              }`}
            >
              {isOperational ? (
                <><CheckCircle className="w-3 h-3 mr-1" /> Operational</>
              ) : (
                <><XCircle className="w-3 h-3 mr-1" /> Non-Operational</>
              )}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {/* EOL Status */}
        {predictedEOL !== undefined && (
          <div className="mb-4 p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-400" />
                <span className="text-xs text-slate-400">Predicted End of Life</span>
              </div>
              <span className="text-sm font-semibold text-teal-400">
                {predictedEOL.toFixed(1)} years
              </span>
            </div>
            {eolReached && (
              <div className="mt-2 text-xs text-red-400 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                EOL threshold reached
              </div>
            )}
          </div>
        )}

        {/* Events List */}
        <ScrollArea className="h-48">
          {allEvents.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-slate-500">
              <CheckCircle className="w-8 h-8 mb-2 text-green-500/50" />
              <p className="text-xs">No failure events detected</p>
              <p className="text-xs text-slate-600">System operating normally</p>
            </div>
          ) : (
            <div className="space-y-2">
              {allEvents.map((event, index) => {
                const config = severityConfig[event.severity] || severityConfig.info;
                const Icon = config.icon;
                
                return (
                  <div
                    key={index}
                    className={`p-3 rounded-lg ${config.bg} border ${config.border} transition-all`}
                  >
                    <div className="flex items-start gap-2">
                      <Icon className={`w-4 h-4 ${config.color} mt-0.5`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-medium ${config.color}`}>
                            {event.name}
                          </span>
                          <Badge 
                            variant="outline" 
                            className={`text-[10px] ${config.border} ${config.color}`}
                          >
                            {event.severity}
                          </Badge>
                        </div>
                        {event.detectedAt !== undefined && (
                          <p className="text-[10px] text-slate-500 mt-1">
                            Detected at year {event.detectedAt.toFixed(2)} (day {event.detectedDays})
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}