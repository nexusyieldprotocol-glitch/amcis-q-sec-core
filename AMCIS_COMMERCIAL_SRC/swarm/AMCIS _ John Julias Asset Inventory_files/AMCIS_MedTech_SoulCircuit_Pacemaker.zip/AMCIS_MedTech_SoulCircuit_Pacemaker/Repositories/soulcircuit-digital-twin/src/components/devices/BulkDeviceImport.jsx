import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Upload, CheckCircle2, AlertTriangle, Download } from 'lucide-react';
import { toast } from 'sonner';

export default function BulkDeviceImport({ onSuccess }) {
  const queryClient = useQueryClient();
  const [importState, setImportState] = useState({
    uploading: false,
    progress: 0,
    errors: [],
    recordsImported: 0
  });

  const importMutation = useMutation({
    mutationFn: async (file) => {
      setImportState({ uploading: true, progress: 10, errors: [], recordsImported: 0 });

      // Upload file
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setImportState(prev => ({ ...prev, progress: 30 }));

      // Extract data
      const jsonSchema = {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            device_id: { type: 'string' },
            patient_id: { type: 'string' },
            manufacturer: { type: 'string' },
            model: { type: 'string' },
            implant_date: { type: 'string' },
            battery_chemistry: { type: 'string' },
            status: { type: 'string' }
          },
          required: ['device_id', 'manufacturer', 'model', 'implant_date', 'battery_chemistry']
        }
      };

      const extractResult = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: jsonSchema
      });

      if (extractResult.status === 'error') {
        throw new Error(extractResult.details || 'Failed to parse CSV');
      }

      setImportState(prev => ({ ...prev, progress: 50 }));

      const devices = extractResult.output;
      const errors = [];

      // Validate
      devices.forEach((device, idx) => {
        const validManufacturers = ['Medtronic', 'Abbott', 'Boston Scientific', 'Biotronik', 'Base44 Labs'];
        if (!validManufacturers.includes(device.manufacturer)) {
          errors.push(`Row ${idx + 1}: Invalid manufacturer`);
        }
      });

      if (errors.length > 0) {
        setImportState({ uploading: false, progress: 0, errors, recordsImported: 0 });
        throw new Error('Validation failed');
      }

      // Bulk insert
      const insertPromises = devices.map(device => 
        base44.entities.DeviceRegistry.create({
          ...device,
          status: device.status || 'active',
          pacing_mode: device.pacing_mode || 'DDD',
          energy_harvesting_enabled: device.energy_harvesting_enabled || false,
          revision_flag: device.revision_flag || false
        })
      );

      await Promise.all(insertPromises);
      setImportState(prev => ({ ...prev, progress: 100, recordsImported: devices.length }));

      return devices.length;
    },
    onSuccess: (count) => {
      queryClient.invalidateQueries(['deviceRegistry']);
      toast.success(`${count} devices imported successfully`);
      setTimeout(() => {
        onSuccess();
      }, 2000);
    },
    onError: (error) => {
      toast.error(error.message || 'Import failed');
      setImportState(prev => ({ ...prev, uploading: false }));
    }
  });

  const downloadTemplate = () => {
    const template = `device_id,patient_id,manufacturer,model,implant_date,battery_chemistry,status,pacing_mode,cohort_name,clinical_study_id
DEV-001,PT-001,Medtronic,Azure XT DR,2023-01-15,Li-I2,active,DDD,High Risk,STUDY-2024-001
DEV-002,PT-002,Abbott,Assurity MRI,2023-02-20,Li-CFx,active,VVI,Standard Care,`;
    
    const blob = new Blob([template], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'device_import_template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      toast.error('Please upload a CSV file');
      return;
    }

    importMutation.mutate(file);
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Upload className="w-5 h-5 text-teal-400" />
          Bulk Device Import
        </CardTitle>
        <CardDescription>
          Import multiple devices from a CSV file
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress */}
        {importState.uploading && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-300">Importing devices...</span>
              <span className="text-teal-400">{importState.progress}%</span>
            </div>
            <Progress value={importState.progress} />
          </div>
        )}

        {/* Errors */}
        {importState.errors.length > 0 && (
          <Alert className="bg-red-900/20 border-red-700/50">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <AlertDescription className="text-red-200">
              <strong>Validation Errors:</strong>
              <ul className="list-disc list-inside mt-2 text-xs">
                {importState.errors.slice(0, 5).map((error, idx) => (
                  <li key={idx}>{error}</li>
                ))}
              </ul>
            </AlertDescription>
          </Alert>
        )}

        {/* Success */}
        {importState.progress === 100 && (
          <Alert className="bg-green-900/20 border-green-700/50">
            <CheckCircle2 className="w-4 h-4 text-green-400" />
            <AlertDescription className="text-green-200">
              Successfully imported {importState.recordsImported} devices!
            </AlertDescription>
          </Alert>
        )}

        {/* Upload Area */}
        <div className="border-2 border-dashed border-slate-700 rounded-lg p-8 text-center hover:border-teal-600 transition-colors">
          <input
            type="file"
            accept=".csv"
            onChange={handleFileSelect}
            disabled={importState.uploading}
            className="hidden"
            id="bulk-upload"
          />
          <label htmlFor="bulk-upload" className="cursor-pointer">
            <Upload className="w-12 h-12 mx-auto mb-3 text-slate-600" />
            <p className="text-white font-medium mb-1">
              {importState.uploading ? 'Processing...' : 'Click to upload CSV'}
            </p>
            <p className="text-xs text-slate-500">
              Maximum file size: 10MB
            </p>
          </label>
        </div>

        {/* Template Download */}
        <div className="flex justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={downloadTemplate}
            className="border-slate-700"
          >
            <Download className="w-4 h-4 mr-2" />
            Download CSV Template
          </Button>
        </div>

        {/* Instructions */}
        <div className="bg-slate-800/30 rounded-lg p-4 text-xs text-slate-400 space-y-2">
          <p className="font-medium text-slate-300">CSV Format Requirements:</p>
          <ul className="list-disc list-inside space-y-1">
            <li>Required: device_id, manufacturer, model, implant_date, battery_chemistry</li>
            <li>Optional: patient_id, status, pacing_mode, cohort_name, clinical_study_id</li>
            <li>Valid manufacturers: Medtronic, Abbott, Boston Scientific, Biotronik, Base44 Labs</li>
            <li>Date format: YYYY-MM-DD</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}