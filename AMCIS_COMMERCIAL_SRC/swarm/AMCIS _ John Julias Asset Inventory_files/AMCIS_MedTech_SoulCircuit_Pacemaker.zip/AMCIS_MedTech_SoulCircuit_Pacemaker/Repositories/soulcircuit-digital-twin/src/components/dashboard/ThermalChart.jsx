import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Thermometer, AlertTriangle, CheckCircle } from 'lucide-react';
import { THERMAL_THRESHOLDS } from '../simulation/SimulationEngine';

export default function ThermalChart({ data, maxTemp }) {
  if (!data || data.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-orange-400" />
            Thermal Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64 flex items-center justify-center">
          <p className="text-slate-500 text-sm">Run simulation to view data</p>
        </CardContent>
      </Card>
    );
  }

  const chartData = data.map(d => ({
    years: d.years.toFixed(2),
    temperature: d.temperature
  }));

  const currentTemp = chartData[chartData.length - 1]?.temperature || 37;
  const isCompliant = currentTemp <= THERMAL_THRESHOLDS.elevated.max;

  const getTempColor = (temp) => {
    if (temp <= 39) return '#22C55E';
    if (temp <= 41) return '#F59E0B';
    if (temp <= 43) return '#EF4444';
    return '#DC2626';
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-orange-400" />
            Thermal Dissipation (ISO 14708-1)
          </CardTitle>
          <div className="flex items-center gap-2">
            {isCompliant ? (
              <Badge variant="outline" className="text-xs border-green-500/50 text-green-400">
                <CheckCircle className="w-3 h-3 mr-1" />
                Compliant
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs border-red-500/50 text-red-400">
                <AlertTriangle className="w-3 h-3 mr-1" />
                Warning
              </Badge>
            )}
            <Badge 
              variant="outline" 
              className="text-xs"
              style={{ borderColor: getTempColor(currentTemp) + '80', color: getTempColor(currentTemp) }}
            >
              {currentTemp.toFixed(1)}°C
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#F97316" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#F97316" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis 
                dataKey="years" 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
              />
              <YAxis 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
                domain={[35, 45]}
                label={{ value: 'Temp (°C)', angle: -90, position: 'insideLeft', fill: '#64748B', fontSize: 10 }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1E293B', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
                labelStyle={{ color: '#94A3B8' }}
                formatter={(value) => [value.toFixed(2) + '°C', 'Temperature']}
                labelFormatter={(label) => `Year ${label}`}
              />
              <ReferenceLine y={39} stroke="#22C55E" strokeDasharray="3 3" strokeOpacity={0.5} />
              <ReferenceLine y={41} stroke="#F59E0B" strokeDasharray="3 3" strokeOpacity={0.5} />
              <ReferenceLine y={43} stroke="#EF4444" strokeDasharray="3 3" strokeOpacity={0.5} />
              <Area
                type="monotone"
                dataKey="temperature"
                stroke="#F97316"
                strokeWidth={2}
                fill="url(#tempGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-center gap-4 mt-2">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-xs text-slate-500">Normal ≤39°C</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-yellow-500" />
            <span className="text-xs text-slate-500">Elevated ≤41°C</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-red-500" />
            <span className="text-xs text-slate-500">Critical &gt;43°C</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}