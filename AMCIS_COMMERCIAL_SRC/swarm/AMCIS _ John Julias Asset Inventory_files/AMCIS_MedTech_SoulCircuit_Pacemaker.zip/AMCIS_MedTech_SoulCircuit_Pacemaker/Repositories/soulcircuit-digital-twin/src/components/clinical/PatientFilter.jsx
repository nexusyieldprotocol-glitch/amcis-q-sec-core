import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Filter, X, Users, AlertTriangle, Activity } from 'lucide-react';

export default function PatientFilter({ filters, onFilterChange, onClearFilters, totalPatients, filteredCount }) {
  const handleFilterUpdate = (key, value) => {
    onFilterChange({ ...filters, [key]: value });
  };

  const activeFilterCount = Object.values(filters).filter(v => v && v !== 'all').length;

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Filter className="w-4 h-4 text-teal-400" />
            Patient Filters
          </CardTitle>
          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-3 h-3 mr-1" />
              Clear ({activeFilterCount})
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filter Stats */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-slate-800/50 rounded-lg p-2">
            <div className="flex items-center gap-1 mb-1">
              <Users className="w-3 h-3 text-blue-400" />
              <span className="text-xs text-slate-400">Total</span>
            </div>
            <p className="text-lg font-semibold text-white">{totalPatients}</p>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-2">
            <div className="flex items-center gap-1 mb-1">
              <Activity className="w-3 h-3 text-green-400" />
              <span className="text-xs text-slate-400">Filtered</span>
            </div>
            <p className="text-lg font-semibold text-white">{filteredCount}</p>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-2">
            <div className="flex items-center gap-1 mb-1">
              <AlertTriangle className="w-3 h-3 text-yellow-400" />
              <span className="text-xs text-slate-400">Active</span>
            </div>
            <p className="text-lg font-semibold text-white">{activeFilterCount}</p>
          </div>
        </div>

        {/* Risk Level Filter */}
        <div>
          <Label className="text-slate-400 text-xs mb-1">Risk Level</Label>
          <Select value={filters.riskLevel || 'all'} onValueChange={(value) => handleFilterUpdate('riskLevel', value)}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="All Risk Levels" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risk Levels</SelectItem>
              <SelectItem value="critical">Critical (≥80)</SelectItem>
              <SelectItem value="high">High (60-79)</SelectItem>
              <SelectItem value="moderate">Moderate (40-59)</SelectItem>
              <SelectItem value="low">Low (&lt;40)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Device Status Filter */}
        <div>
          <Label className="text-slate-400 text-xs mb-1">Device Status</Label>
          <Select value={filters.deviceStatus || 'all'} onValueChange={(value) => handleFilterUpdate('deviceStatus', value)}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="eri">ERI (Elective Replacement)</SelectItem>
              <SelectItem value="eol">EOL (End of Life)</SelectItem>
              <SelectItem value="explanted">Explanted</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Manufacturer Filter */}
        <div>
          <Label className="text-slate-400 text-xs mb-1">Manufacturer</Label>
          <Select value={filters.manufacturer || 'all'} onValueChange={(value) => handleFilterUpdate('manufacturer', value)}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="All Manufacturers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Manufacturers</SelectItem>
              <SelectItem value="Medtronic">Medtronic</SelectItem>
              <SelectItem value="Abbott">Abbott</SelectItem>
              <SelectItem value="Boston Scientific">Boston Scientific</SelectItem>
              <SelectItem value="Biotronik">Biotronik</SelectItem>
              <SelectItem value="Base44 Labs">Base44 Labs</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* RUL Filter */}
        <div>
          <Label className="text-slate-400 text-xs mb-1">Remaining Useful Life</Label>
          <Select value={filters.rulRange || 'all'} onValueChange={(value) => handleFilterUpdate('rulRange', value)}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="All RUL Ranges" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All RUL Ranges</SelectItem>
              <SelectItem value="critical">&lt; 90 days</SelectItem>
              <SelectItem value="warning">90-180 days</SelectItem>
              <SelectItem value="moderate">180-365 days</SelectItem>
              <SelectItem value="good">&gt; 365 days</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Search by Patient ID */}
        <div>
          <Label className="text-slate-400 text-xs mb-1">Search Patient ID</Label>
          <Input
            placeholder="Enter patient ID..."
            value={filters.patientId || ''}
            onChange={(e) => handleFilterUpdate('patientId', e.target.value)}
            className="bg-slate-800 border-slate-700 text-white"
          />
        </div>

        {/* Active Filters */}
        {activeFilterCount > 0 && (
          <div className="pt-2 border-t border-slate-700">
            <Label className="text-slate-400 text-xs mb-2">Active Filters</Label>
            <div className="flex flex-wrap gap-1">
              {Object.entries(filters).map(([key, value]) => {
                if (!value || value === 'all') return null;
                return (
                  <Badge key={key} variant="outline" className="text-xs bg-teal-900/30 border-teal-700/50 text-teal-400">
                    {value}
                  </Badge>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}