import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { Activity, Zap, AlertTriangle, TrendingDown, TrendingUp, Radio } from 'lucide-react';

export default function RealtimeMonitor({ deviceId }) {
  const [liveSnapshots, setLiveSnapshots] = useState([]);
  const [lastUpdate, setLastUpdate] = useState(null);

  // Subscribe to real-time updates
  useEffect(() => {
    if (!deviceId) return;

    const unsubscribe = base44.entities.LongevitySnapshot.subscribe((event) => {
      if (event.type === 'create' && event.data?.device_registry_id === deviceId) {
        setLiveSnapshots(prev => {
          const updated = [...prev, event.data].slice(-50); // Keep last 50 points
          return updated.sort((a, b) => 
            new Date(a.snapshot_date) - new Date(b.snapshot_date)
          );
        });
        setLastUpdate(new Date());
      }
    });

    return unsubscribe;
  }, [deviceId]);

  // Initial load
  const { data: device } = useQuery({
    queryKey: ['deviceRegistry', deviceId],
    queryFn: () => base44.entities.DeviceRegistry.filter({ id: deviceId }).then(r => r[0]),
    enabled: !!deviceId
  });

  const { data: snapshots = [] } = useQuery({
    queryKey: ['longevitySnapshots', deviceId],
    queryFn: () => base44.entities.LongevitySnapshot.filter(
      { device_registry_id: deviceId },
      '-snapshot_date',
      50
    ),
    enabled: !!deviceId
  });

  // Merge initial and live data
  useEffect(() => {
    if (snapshots.length > 0 && liveSnapshots.length === 0) {
      setLiveSnapshots(snapshots);
    }
  }, [snapshots]);

  const latestSnapshot = liveSnapshots[liveSnapshots.length - 1] || snapshots[snapshots.length - 1];

  if (!device || !latestSnapshot) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-8 text-center text-slate-500">
          <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No device data available</p>
        </CardContent>
      </Card>
    );
  }

  const voltageData = liveSnapshots.map(s => ({
    time: new Date(s.snapshot_date).getTime(),
    voltage: s.battery_voltage_v || 0,
    label: new Date(s.snapshot_date).toLocaleTimeString()
  }));

  const impedanceData = liveSnapshots.map(s => ({
    time: new Date(s.snapshot_date).getTime(),
    impedance: s.battery_impedance_ohms || 0,
    leadImpedance: s.lead_impedance_ohms || 0,
    label: new Date(s.snapshot_date).toLocaleTimeString()
  }));

  const riskLevel = latestSnapshot.risk_score >= 80 ? 'critical' : 
                    latestSnapshot.risk_score >= 60 ? 'high' : 
                    latestSnapshot.risk_score >= 40 ? 'medium' : 'low';

  const riskColors = {
    critical: 'bg-red-900/30 text-red-400 border-red-700',
    high: 'bg-orange-900/30 text-orange-400 border-orange-700',
    medium: 'bg-yellow-900/30 text-yellow-400 border-yellow-700',
    low: 'bg-green-900/30 text-green-400 border-green-700'
  };

  return (
    <div className="space-y-4">
      {/* Live Status Header */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Radio className="w-5 h-5 text-teal-400" />
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-teal-400 rounded-full animate-pulse" />
              </div>
              <div>
                <p className="text-xs text-slate-400">Live Monitoring</p>
                <p className="text-sm font-medium text-white">
                  {device.device_id} - {device.model}
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400">Last Update</p>
              <p className="text-sm text-teal-400">
                {lastUpdate ? lastUpdate.toLocaleTimeString() : 'Waiting...'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Real-time Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <MetricCard
          label="Battery Voltage"
          value={latestSnapshot.battery_voltage_v?.toFixed(2) || 'N/A'}
          unit="V"
          icon={Zap}
          trend={calculateTrend(liveSnapshots, 'battery_voltage_v')}
        />
        <MetricCard
          label="RUL"
          value={latestSnapshot.predicted_rul_days || 'N/A'}
          unit="days"
          icon={Activity}
          trend={calculateTrend(liveSnapshots, 'predicted_rul_days')}
        />
        <MetricCard
          label="Risk Score"
          value={latestSnapshot.risk_score?.toFixed(0) || 'N/A'}
          unit="%"
          icon={AlertTriangle}
          badge={<Badge className={riskColors[riskLevel]}>{riskLevel}</Badge>}
        />
        <MetricCard
          label="Lead Impedance"
          value={latestSnapshot.lead_impedance_ohms?.toFixed(0) || 'N/A'}
          unit="Ω"
          icon={Activity}
          trend={calculateTrend(liveSnapshots, 'lead_impedance_ohms')}
        />
      </div>

      {/* Live Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              Battery Voltage (Live)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={voltageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                  dataKey="time" 
                  stroke="#94a3b8"
                  tick={{ fontSize: 10 }}
                  tickFormatter={(time) => new Date(time).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} domain={['dataMin - 0.1', 'dataMax + 0.1']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelFormatter={(time) => new Date(time).toLocaleString()}
                  formatter={(value) => [value?.toFixed(2) + ' V', 'Voltage']}
                />
                <ReferenceLine y={2.4} stroke="#ef4444" strokeDasharray="3 3" label="EOL" />
                <Line 
                  type="monotone" 
                  dataKey="voltage" 
                  stroke="#fbbf24" 
                  strokeWidth={2}
                  dot={{ r: 2 }}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-purple-400" />
              Impedance Trends (Live)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={impedanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                  dataKey="time" 
                  stroke="#94a3b8"
                  tick={{ fontSize: 10 }}
                  tickFormatter={(time) => new Date(time).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelFormatter={(time) => new Date(time).toLocaleString()}
                />
                <Line 
                  type="monotone" 
                  dataKey="impedance" 
                  stroke="#a855f7" 
                  strokeWidth={2}
                  name="Battery"
                  dot={{ r: 2 }}
                  isAnimationActive={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="leadImpedance" 
                  stroke="#14b8a6" 
                  strokeWidth={2}
                  name="Lead"
                  dot={{ r: 2 }}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Anomaly Flags */}
      {latestSnapshot.anomaly_flags && latestSnapshot.anomaly_flags.length > 0 && (
        <Card className="bg-red-900/10 border-red-700/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-red-300 mb-2">Active Anomalies</p>
                <div className="flex flex-wrap gap-2">
                  {latestSnapshot.anomaly_flags.map((flag, idx) => (
                    <Badge key={idx} variant="outline" className="border-red-700/50 text-red-400">
                      {flag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function MetricCard({ label, value, unit, icon: Icon, trend, badge }) {
  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardContent className="p-3">
        <div className="flex items-center justify-between mb-2">
          <Icon className="w-4 h-4 text-slate-400" />
          {badge || (trend && (
            <div className={`flex items-center gap-1 text-xs ${
              trend > 0 ? 'text-green-400' : trend < 0 ? 'text-red-400' : 'text-slate-500'
            }`}>
              {trend > 0 ? <TrendingUp className="w-3 h-3" /> : 
               trend < 0 ? <TrendingDown className="w-3 h-3" /> : null}
              {trend !== 0 && Math.abs(trend).toFixed(1)}%
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-400 mb-1">{label}</p>
        <p className="text-xl font-bold text-white">
          {value} <span className="text-sm text-slate-400 font-normal">{unit}</span>
        </p>
      </CardContent>
    </Card>
  );
}

function calculateTrend(snapshots, field) {
  if (snapshots.length < 2) return 0;
  const recent = snapshots.slice(-5);
  const first = recent[0]?.[field];
  const last = recent[recent.length - 1]?.[field];
  if (!first || !last) return 0;
  return ((last - first) / first) * 100;
}