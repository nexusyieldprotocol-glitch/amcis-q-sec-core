import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Battery, 
  Cpu, 
  Zap, 
  Clock, 
  Thermometer,
  Radio,
  CheckCircle,
  AlertCircle,
  Settings
} from 'lucide-react';
import { cn } from "@/lib/utils";

export default function PrototypeCard({ prototype, isSelected, onClick, onConfigure }) {
  const statusColors = {
    concept: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    prototype: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    clinical_trial: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    approved: 'bg-green-500/20 text-green-400 border-green-500/30',
    legacy: 'bg-slate-500/20 text-slate-400 border-slate-500/30'
  };

  const modelTypeIcons = {
    leadless: <Radio className="w-3 h-3" />,
    transvenous: <Cpu className="w-3 h-3" />,
    subcutaneous: <Cpu className="w-3 h-3" />,
    hybrid: <Zap className="w-3 h-3" />
  };

  return (
    <Card 
      className={cn(
        "cursor-pointer transition-all duration-300 hover:scale-[1.02] border-2",
        "bg-gradient-to-br from-slate-900/80 to-slate-800/50 backdrop-blur-sm",
        isSelected 
          ? "border-teal-500/70 shadow-lg shadow-teal-500/20" 
          : "border-slate-700/50 hover:border-slate-600/70"
      )}
      onClick={onClick}
    >
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <div 
                className="w-2 h-2 rounded-full" 
                style={{ backgroundColor: prototype.color || '#6B7280' }}
              />
              <h3 className="font-semibold text-slate-100 text-sm">{prototype.name}</h3>
            </div>
            <p className="text-xs text-slate-500">{prototype.manufacturer}</p>
          </div>
          <div className="flex items-center gap-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={(e) => {
                e.stopPropagation();
                onConfigure?.(prototype);
              }}
              className="h-7 w-7 p-0 hover:bg-teal-900/30"
            >
              <Settings className="w-3 h-3 text-slate-400 hover:text-teal-400" />
            </Button>
            <Badge variant="outline" className={cn("text-[10px] px-2", statusColors[prototype.status])}>
              {prototype.status?.replace('_', ' ')}
            </Badge>
          </div>
        </div>

        {/* Key Specs Grid */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg px-2 py-1.5">
            <Battery className="w-3 h-3 text-teal-400" />
            <div>
              <p className="text-[10px] text-slate-500">Capacity</p>
              <p className="text-xs text-slate-200 font-medium">{prototype.energy_capacity_mah} mAh</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg px-2 py-1.5">
            <Zap className="w-3 h-3 text-yellow-400" />
            <div>
              <p className="text-[10px] text-slate-500">Voltage</p>
              <p className="text-xs text-slate-200 font-medium">{prototype.nominal_voltage}V</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg px-2 py-1.5">
            <Clock className="w-3 h-3 text-purple-400" />
            <div>
              <p className="text-[10px] text-slate-500">Lifetime</p>
              <p className="text-xs text-slate-200 font-medium">{prototype.expected_lifetime_years} yrs</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg px-2 py-1.5">
            <Thermometer className="w-3 h-3 text-orange-400" />
            <div>
              <p className="text-[10px] text-slate-500">Volume</p>
              <p className="text-xs text-slate-200 font-medium">{prototype.volume_cc} cc</p>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="flex flex-wrap gap-1.5">
          <Badge variant="outline" className="text-[10px] bg-slate-800/50 border-slate-600/50 text-slate-400">
            {modelTypeIcons[prototype.model_type]}
            <span className="ml-1">{prototype.model_type}</span>
          </Badge>
          <Badge variant="outline" className="text-[10px] bg-slate-800/50 border-slate-600/50 text-slate-400">
            {prototype.battery_chemistry}
          </Badge>
          {prototype.energy_harvesting_enabled && (
            <Badge variant="outline" className="text-[10px] bg-green-900/30 border-green-600/30 text-green-400">
              <Zap className="w-2 h-2 mr-1" />
              Harvesting
            </Badge>
          )}
          {prototype.supercapacitor_enabled && (
            <Badge variant="outline" className="text-[10px] bg-blue-900/30 border-blue-600/30 text-blue-400">
              SuperCap
            </Badge>
          )}
          {prototype.mri_conditional && (
            <Badge variant="outline" className="text-[10px] bg-purple-900/30 border-purple-600/30 text-purple-400">
              MRI Safe
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}