import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, Activity, TrendingUp, GitCompare, Download } from 'lucide-react';

// Analytics Components
import FleetMetricsPanel from '../components/analytics/FleetMetricsPanel';
import ComparativeAnalysis from '../components/analytics/ComparativeAnalysis';
import PredictiveAnalytics from '../components/analytics/PredictiveAnalytics';
import ReportExporter from '../components/analytics/ReportExporter';
import FleetLiveStatus from '../components/monitoring/FleetLiveStatus';

export default function AdvancedAnalytics() {
  const [activeTab, setActiveTab] = useState('fleet');

  // Fetch registry data
  const { data: registryData = [], isLoading: loadingRegistry } = useQuery({
    queryKey: ['deviceRegistry'],
    queryFn: () => base44.entities.DeviceRegistry.list()
  });

  // Fetch longevity snapshots
  const { data: snapshots = [], isLoading: loadingSnapshots } = useQuery({
    queryKey: ['longevitySnapshots'],
    queryFn: () => base44.entities.LongevitySnapshot.list('-snapshot_date', 1000)
  });

  const isLoading = loadingRegistry || loadingSnapshots;

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <BarChart3 className="w-8 h-8 text-teal-400" />
              Advanced Analytics Dashboard
            </h1>
            <p className="text-slate-400 mt-1">
              Population-level insights, trends, and predictive analytics
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <Activity className="w-4 h-4" />
            <span>{registryData.length} devices</span>
            <span className="mx-2">•</span>
            <span>{snapshots.length} snapshots</span>
          </div>
        </div>

        {/* Main Content */}
        {isLoading ? (
          <div className="flex items-center justify-center py-24">
            <div className="text-center">
              <Activity className="w-12 h-12 mx-auto mb-4 text-teal-400 animate-pulse" />
              <p className="text-slate-400">Loading analytics data...</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Main Analytics Area */}
            <div className="lg:col-span-3">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList className="bg-slate-900 border border-slate-700">
                  <TabsTrigger value="fleet" className="data-[state=active]:bg-teal-900/30">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Fleet Metrics
                  </TabsTrigger>
                  <TabsTrigger value="comparative" className="data-[state=active]:bg-teal-900/30">
                    <GitCompare className="w-4 h-4 mr-2" />
                    Comparative
                  </TabsTrigger>
                  <TabsTrigger value="predictive" className="data-[state=active]:bg-teal-900/30">
                    <Activity className="w-4 h-4 mr-2" />
                    Predictive
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="fleet" className="space-y-4">
                  <FleetMetricsPanel 
                    registryData={registryData} 
                    snapshots={snapshots} 
                  />
                </TabsContent>

                <TabsContent value="comparative" className="space-y-4">
                  <ComparativeAnalysis 
                    registryData={registryData} 
                    snapshots={snapshots} 
                  />
                </TabsContent>

                <TabsContent value="predictive" className="space-y-4">
                  <PredictiveAnalytics 
                    registryData={registryData} 
                    snapshots={snapshots} 
                  />
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar - Export & Tools */}
            <div className="lg:col-span-1 space-y-6">
              <FleetLiveStatus />
              <ReportExporter 
                registryData={registryData} 
                snapshots={snapshots} 
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}