import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, Cell 
} from 'recharts';
import { 
  TrendingDown, TrendingUp, Lightbulb, AlertTriangle, 
  CheckCircle2, MinusCircle, Activity 
} from 'lucide-react';

export default function ExplainabilityPanel({ 
  shapValues, 
  clinicalSummary, 
  currentState 
}) {
  if (!shapValues || !clinicalSummary) {
    return (
      <Card className="bg-slate-900/50 border-slate-800">
        <CardContent className="py-12 text-center text-slate-500">
          <Lightbulb className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>Run a prediction to view model explainability</p>
        </CardContent>
      </Card>
    );
  }
  
  // Prepare chart data
  const featureData = Object.keys(shapValues).map(key => ({
    name: humanizeFeatureName(key),
    contribution: shapValues[key].value,
    impact: shapValues[key].impact
  })).sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
  
  const riskColors = {
    HIGH: 'text-red-400 bg-red-900/30 border-red-700/50',
    MODERATE: 'text-orange-400 bg-orange-900/30 border-orange-700/50',
    LOW: 'text-green-400 bg-green-900/30 border-green-700/50'
  };
  
  return (
    <div className="space-y-4">
      {/* Risk Level Banner */}
      <Card className={`border ${riskColors[clinicalSummary.riskLevel]} bg-opacity-50`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                {clinicalSummary.riskLevel === 'HIGH' && <AlertTriangle className="w-5 h-5" />}
                {clinicalSummary.riskLevel === 'MODERATE' && <MinusCircle className="w-5 h-5" />}
                {clinicalSummary.riskLevel === 'LOW' && <CheckCircle2 className="w-5 h-5" />}
                Risk Level: {clinicalSummary.riskLevel}
              </CardTitle>
              <CardDescription className="text-slate-400">
                Predicted RUL: {clinicalSummary.predictedRUL}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>
      
      {/* SHAP Feature Importance */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-teal-400" />
            Feature Importance (SHAP Values)
          </CardTitle>
          <CardDescription>
            Contribution of each parameter to RUL prediction
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={featureData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis type="number" stroke="#94a3b8" />
              <YAxis type="category" dataKey="name" stroke="#94a3b8" width={130} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                labelStyle={{ color: '#f1f5f9' }}
              />
              <Bar dataKey="contribution" name="SHAP Value">
                {featureData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.contribution > 0 ? '#14b8a6' : '#f97316'} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          
          <div className="mt-4 flex items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-teal-500 rounded" />
              <span className="text-slate-400">Positive Impact (extends RUL)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-orange-500 rounded" />
              <span className="text-slate-400">Negative Impact (reduces RUL)</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Clinical Interpretations */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white">Primary Prediction Drivers</CardTitle>
          <CardDescription>Clinical interpretation of key factors</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {clinicalSummary.primaryDrivers.map((driver, idx) => (
            <div 
              key={idx} 
              className="p-4 bg-slate-800/30 rounded-lg border border-slate-700/50"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  {parseFloat(driver.contribution) > 0 ? 
                    <TrendingUp className="w-4 h-4 text-teal-400" /> : 
                    <TrendingDown className="w-4 h-4 text-orange-400" />
                  }
                  <span className="font-medium text-white">{driver.feature}</span>
                </div>
                <Badge variant="outline" className={
                  driver.impact === 'significant' ? 'border-orange-700/50 text-orange-400' :
                  driver.impact === 'moderate' ? 'border-yellow-700/50 text-yellow-400' :
                  'border-slate-700/50 text-slate-400'
                }>
                  {driver.impact}
                </Badge>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed">
                {driver.interpretation}
              </p>
              <div className="mt-2">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span>Contribution: {driver.contribution} years</span>
                </div>
                <Progress 
                  value={Math.min(100, Math.abs(parseFloat(driver.contribution)) * 20)} 
                  className="h-1"
                />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
      
      {/* Actionable Recommendations */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-400" />
            Clinical Recommendations
          </CardTitle>
          <CardDescription>Actionable insights based on prediction</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {clinicalSummary.actionableRecommendations.map((rec, idx) => (
            <div 
              key={idx}
              className={`p-3 rounded-lg border ${
                rec.priority === 'high' ? 'bg-red-900/20 border-red-700/50' :
                rec.priority === 'moderate' ? 'bg-orange-900/20 border-orange-700/50' :
                'bg-green-900/20 border-green-700/50'
              }`}
            >
              <div className="flex items-start gap-3">
                <Badge variant="outline" className={
                  rec.priority === 'high' ? 'border-red-700/50 text-red-400' :
                  rec.priority === 'moderate' ? 'border-orange-700/50 text-orange-400' :
                  'border-green-700/50 text-green-400'
                }>
                  {rec.priority}
                </Badge>
                <div className="flex-1">
                  <p className="text-sm font-medium text-white">{rec.action}</p>
                  <p className="text-xs text-slate-400 mt-1">{rec.reason}</p>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function humanizeFeatureName(feature) {
  const names = {
    voltage: 'Battery Voltage',
    soc: 'State of Charge',
    internalResistance: 'Internal Resistance',
    leadImpedance: 'Lead Impedance',
    temperature: 'Temperature',
    pacingPercentage: 'Pacing Burden',
    years: 'Device Age'
  };
  return names[feature] || feature;
}