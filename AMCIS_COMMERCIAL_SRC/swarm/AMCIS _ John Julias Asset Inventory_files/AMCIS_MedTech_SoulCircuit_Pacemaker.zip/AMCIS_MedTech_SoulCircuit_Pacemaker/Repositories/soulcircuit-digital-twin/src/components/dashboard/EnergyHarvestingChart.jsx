import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, TrendingUp } from 'lucide-react';

export default function EnergyHarvestingChart({ data, harvestingType, totalHarvested }) {
  if (!data || data.length === 0 || harvestingType === 'none') {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            Energy Harvesting
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64 flex items-center justify-center">
          <p className="text-slate-500 text-sm">
            {harvestingType === 'none' ? 'Harvesting not enabled for this prototype' : 'Run simulation to view data'}
          </p>
        </CardContent>
      </Card>
    );
  }

  // Sample data at intervals for readability
  const sampleInterval = Math.max(1, Math.floor(data.length / 20));
  const chartData = data
    .filter((_, i) => i % sampleInterval === 0)
    .map(d => ({
      year: d.years.toFixed(1),
      harvested: d.harvestedEnergy * 1000 // Convert to µAh for better visualization
    }));

  const getHarvestingColor = (type) => {
    switch(type) {
      case 'piezoelectric': return '#8B5CF6';
      case 'thermoelectric': return '#F97316';
      case 'inductive': return '#3B82F6';
      case 'hybrid': return '#10B981';
      default: return '#6B7280';
    }
  };

  const color = getHarvestingColor(harvestingType);

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            Energy Harvesting - {harvestingType?.charAt(0).toUpperCase() + harvestingType?.slice(1)}
          </CardTitle>
          <Badge variant="outline" className="text-xs border-yellow-500/50 text-yellow-400">
            <TrendingUp className="w-3 h-3 mr-1" />
            {totalHarvested?.toFixed(2) || 0} mAh total
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis 
                dataKey="year" 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
              />
              <YAxis 
                stroke="#64748B" 
                fontSize={10}
                tickLine={false}
                label={{ value: 'Harvested (µAh)', angle: -90, position: 'insideLeft', fill: '#64748B', fontSize: 10 }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1E293B', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
                labelStyle={{ color: '#94A3B8' }}
                formatter={(value) => [(value / 1000).toFixed(4) + ' mAh', 'Harvested']}
                labelFormatter={(label) => `Year ${label}`}
              />
              <Bar dataKey="harvested" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={color} fillOpacity={0.7 + (index / chartData.length) * 0.3} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}