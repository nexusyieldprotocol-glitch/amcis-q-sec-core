import React, { useRef, useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Box, RotateCcw, ZoomIn, ZoomOut, Pause, Play } from 'lucide-react';
import * as THREE from 'three';

export default function Device3DViewer({ prototype }) {
  const containerRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const meshRef = useRef(null);
  const animationRef = useRef(null);
  
  const [isRotating, setIsRotating] = useState(true);
  const [zoom, setZoom] = useState(3);

  useEffect(() => {
    if (!containerRef.current || !prototype) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(50, containerRef.current.clientWidth / containerRef.current.clientHeight, 0.1, 1000);
    camera.position.z = zoom;
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0x14b8a6, 0.5, 10);
    pointLight.position.set(-2, 2, 2);
    scene.add(pointLight);

    // Create device geometry based on prototype dimensions
    let geometry;
    const dims = prototype.dimensions_mm || {};
    
    if (dims.diameter) {
      // Cylindrical (leadless) device
      const radius = (dims.diameter / 2) / 20; // Scale down
      const height = (dims.length || 30) / 20;
      geometry = new THREE.CapsuleGeometry(radius, height - radius * 2, 8, 16);
    } else if (dims.length && dims.width) {
      // Box-shaped (transvenous) device
      const width = (dims.width || 40) / 40;
      const height = (dims.thickness || 8) / 40;
      const depth = (dims.length || 50) / 40;
      geometry = new THREE.BoxGeometry(width, height, depth);
      // Add rounded edges effect with a second mesh
      const edgeGeometry = new THREE.EdgesGeometry(geometry);
      const edgeMaterial = new THREE.LineBasicMaterial({ color: 0x14b8a6, opacity: 0.5, transparent: true });
      const edges = new THREE.LineSegments(edgeGeometry, edgeMaterial);
      scene.add(edges);
    } else {
      // Default capsule shape
      geometry = new THREE.CapsuleGeometry(0.3, 0.8, 8, 16);
    }

    // Material with gradient-like effect
    const color = new THREE.Color(prototype.color || '#6B7280');
    const material = new THREE.MeshPhysicalMaterial({
      color: color,
      metalness: 0.8,
      roughness: 0.2,
      clearcoat: 0.3,
      clearcoatRoughness: 0.2,
      envMapIntensity: 1
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.rotation.z = Math.PI / 2; // Orient horizontally
    scene.add(mesh);
    meshRef.current = mesh;

    // Add wireframe overlay
    const wireframeMaterial = new THREE.MeshBasicMaterial({
      color: 0x14b8a6,
      wireframe: true,
      opacity: 0.1,
      transparent: true
    });
    const wireframeMesh = new THREE.Mesh(geometry.clone(), wireframeMaterial);
    wireframeMesh.rotation.z = Math.PI / 2;
    wireframeMesh.scale.set(1.02, 1.02, 1.02);
    scene.add(wireframeMesh);

    // Add grid helper
    const gridHelper = new THREE.GridHelper(4, 20, 0x334155, 0x1e293b);
    gridHelper.position.y = -1;
    scene.add(gridHelper);

    // Animation loop
    const animate = () => {
      animationRef.current = requestAnimationFrame(animate);
      
      if (isRotating && meshRef.current) {
        meshRef.current.rotation.y += 0.005;
        wireframeMesh.rotation.y += 0.005;
      }
      
      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [prototype]);

  useEffect(() => {
    if (cameraRef.current) {
      cameraRef.current.position.z = zoom;
    }
  }, [zoom]);

  if (!prototype) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Box className="w-4 h-4 text-blue-400" />
            3D Device Visualization
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64 flex items-center justify-center">
          <p className="text-slate-500 text-sm">Select a prototype to view 3D model</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
            <Box className="w-4 h-4 text-blue-400" />
            3D Device Model
          </CardTitle>
          <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
            {prototype.model_type}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div 
          ref={containerRef} 
          className="h-64 rounded-lg overflow-hidden"
          style={{ background: 'linear-gradient(to bottom, #0f172a, #1e293b)' }}
        />
        
        {/* Controls */}
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-400 hover:text-slate-200"
              onClick={() => setIsRotating(!isRotating)}
            >
              {isRotating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-400 hover:text-slate-200"
              onClick={() => {
                if (meshRef.current) {
                  meshRef.current.rotation.y = 0;
                }
              }}
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="flex items-center gap-2 w-32">
            <ZoomOut className="w-3 h-3 text-slate-500" />
            <Slider
              value={[zoom]}
              onValueChange={(v) => setZoom(v[0])}
              min={1.5}
              max={6}
              step={0.1}
              className="w-full"
            />
            <ZoomIn className="w-3 h-3 text-slate-500" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}