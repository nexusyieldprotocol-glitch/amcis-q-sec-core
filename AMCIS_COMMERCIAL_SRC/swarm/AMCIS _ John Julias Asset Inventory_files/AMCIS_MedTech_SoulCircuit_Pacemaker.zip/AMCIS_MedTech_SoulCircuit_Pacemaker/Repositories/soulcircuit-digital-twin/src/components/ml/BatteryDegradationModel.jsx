// LSTM-based Battery Degradation Forecasting Model
import * as tf from '@tensorflow/tfjs';

export class BatteryDegradationModel {
  constructor() {
    this.model = null;
    this.isModelReady = false;
    this.sequenceLength = 20; // Number of time steps to look back
    this.features = ['voltage', 'soc', 'temperature', 'internalResistance', 'elapsedYears'];
  }

  /**
   * Build LSTM model for battery degradation prediction
   */
  async buildModel() {
    if (this.model) {
      this.model.dispose();
    }

    this.model = tf.sequential({
      layers: [
        // LSTM layer 1
        tf.layers.lstm({
          units: 64,
          returnSequences: true,
          inputShape: [this.sequenceLength, this.features.length]
        }),
        tf.layers.dropout({ rate: 0.2 }),
        
        // LSTM layer 2
        tf.layers.lstm({
          units: 32,
          returnSequences: false
        }),
        tf.layers.dropout({ rate: 0.2 }),
        
        // Dense layers
        tf.layers.dense({ units: 16, activation: 'relu' }),
        tf.layers.dense({ units: this.features.length }) // Predict next values
      ]
    });

    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['mae']
    });

    this.isModelReady = true;
    return this.model;
  }

  /**
   * Prepare training data from historical simulations
   */
  prepareTrainingData(historicalData) {
    const sequences = [];
    const targets = [];

    for (const simulation of historicalData) {
      if (!simulation.time_series || simulation.time_series.length < this.sequenceLength + 1) {
        continue;
      }

      const timeSeries = simulation.time_series;
      
      // Create sliding windows
      for (let i = 0; i < timeSeries.length - this.sequenceLength; i++) {
        const sequence = timeSeries.slice(i, i + this.sequenceLength);
        const target = timeSeries[i + this.sequenceLength];
        
        sequences.push(sequence.map(point => this.extractFeatures(point)));
        targets.push(this.extractFeatures(target));
      }
    }

    if (sequences.length === 0) {
      return null;
    }

    const X = tf.tensor3d(sequences);
    const y = tf.tensor2d(targets);

    return { X, y };
  }

  /**
   * Extract relevant features from a data point
   */
  extractFeatures(dataPoint) {
    return [
      dataPoint.voltage || 0,
      dataPoint.soc || 0,
      dataPoint.temperature || 0,
      dataPoint.internalResistance || 0,
      dataPoint.years || dataPoint.elapsedYears || 0
    ];
  }

  /**
   * Train the model with historical data
   */
  async train(historicalData, epochs = 50) {
    if (!this.model) {
      await this.buildModel();
    }

    const trainingData = this.prepareTrainingData(historicalData);
    if (!trainingData) {
      console.warn('Insufficient training data');
      return null;
    }

    const { X, y } = trainingData;

    const history = await this.model.fit(X, y, {
      epochs: epochs,
      validationSplit: 0.2,
      batchSize: 32,
      shuffle: true,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          if (epoch % 10 === 0) {
            console.log(`Epoch ${epoch}: loss = ${logs.loss.toFixed(4)}, mae = ${logs.mae.toFixed(4)}`);
          }
        }
      }
    });

    X.dispose();
    y.dispose();

    return history;
  }

  /**
   * Predict future battery state
   */
  async predict(recentTimeSeries, stepsAhead = 10) {
    if (!this.model || !this.isModelReady) {
      console.warn('Model not ready');
      return null;
    }

    if (recentTimeSeries.length < this.sequenceLength) {
      console.warn('Insufficient recent data for prediction');
      return null;
    }

    const predictions = [];
    let currentSequence = recentTimeSeries.slice(-this.sequenceLength);

    for (let i = 0; i < stepsAhead; i++) {
      // Prepare input
      const inputFeatures = currentSequence.map(point => this.extractFeatures(point));
      const inputTensor = tf.tensor3d([inputFeatures]);

      // Predict next step
      const prediction = this.model.predict(inputTensor);
      const predictionArray = await prediction.array();
      
      inputTensor.dispose();
      prediction.dispose();

      const [predictedValues] = predictionArray;
      const nextPoint = {
        voltage: predictedValues[0],
        soc: Math.max(0, Math.min(1, predictedValues[1])),
        temperature: predictedValues[2],
        internalResistance: predictedValues[3],
        years: predictedValues[4]
      };

      predictions.push(nextPoint);

      // Update sequence for next prediction
      currentSequence = [...currentSequence.slice(1), nextPoint];
    }

    return predictions;
  }

  /**
   * Predict end-of-life with confidence interval
   */
  async predictEOL(recentTimeSeries, cutoffVoltage = 2.0) {
    const predictions = await this.predict(recentTimeSeries, 100);
    if (!predictions) return null;

    // Find when voltage drops below cutoff
    let eolSteps = predictions.findIndex(p => p.voltage < cutoffVoltage);
    if (eolSteps === -1) eolSteps = predictions.length;

    const lastKnownYear = recentTimeSeries[recentTimeSeries.length - 1].years || 0;
    const timeStepSize = recentTimeSeries.length > 1 
      ? (recentTimeSeries[recentTimeSeries.length - 1].years - recentTimeSeries[recentTimeSeries.length - 2].years)
      : 0.1;

    const predictedEOL = lastKnownYear + (eolSteps * timeStepSize);

    // Calculate confidence based on prediction stability
    const voltageVariance = predictions.slice(0, 10).reduce((sum, p, i) => {
      if (i === 0) return 0;
      return sum + Math.abs(p.voltage - predictions[i-1].voltage);
    }, 0) / 10;

    const confidence = Math.max(0.5, 1 - (voltageVariance * 10));

    return {
      predictedEOL,
      confidence,
      predictions
    };
  }

  /**
   * Save model to browser storage
   */
  async saveModel(modelName = 'battery-degradation-lstm') {
    if (!this.model) return false;
    await this.model.save(`localstorage://${modelName}`);
    return true;
  }

  /**
   * Load model from browser storage
   */
  async loadModel(modelName = 'battery-degradation-lstm') {
    try {
      this.model = await tf.loadLayersModel(`localstorage://${modelName}`);
      this.isModelReady = true;
      return true;
    } catch (error) {
      console.warn('No saved model found, will create new model');
      return false;
    }
  }

  /**
   * Cleanup
   */
  dispose() {
    if (this.model) {
      this.model.dispose();
      this.model = null;
      this.isModelReady = false;
    }
  }
}

export default BatteryDegradationModel;