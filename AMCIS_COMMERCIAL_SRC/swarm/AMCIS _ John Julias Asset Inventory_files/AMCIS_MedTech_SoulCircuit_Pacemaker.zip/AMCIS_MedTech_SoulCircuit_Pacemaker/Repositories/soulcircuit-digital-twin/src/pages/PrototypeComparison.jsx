import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend
} from 'recharts';
import { 
  Heart, 
  GitCompare, 
  Battery, 
  Zap, 
  Clock, 
  Box,
  Thermometer,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from "@/utils";

import { PROTOTYPE_LIBRARY } from '../components/simulation/PrototypeLibrary';

export default function PrototypeComparison() {
  const [selectedPrototypes, setSelectedPrototypes] = useState(
    PROTOTYPE_LIBRARY.slice(0, 3).map(p => p.id)
  );

  const togglePrototype = (id) => {
    setSelectedPrototypes(prev => 
      prev.includes(id) 
        ? prev.filter(p => p !== id)
        : [...prev, id]
    );
  };

  const selected = useMemo(() => 
    PROTOTYPE_LIBRARY.filter(p => selectedPrototypes.includes(p.id)),
    [selectedPrototypes]
  );

  // Comparison data for bar chart
  const comparisonData = useMemo(() => [
    {
      metric: 'Capacity (mAh)',
      ...Object.fromEntries(selected.map(p => [p.name, p.energy_capacity_mah]))
    },
    {
      metric: 'Lifetime (yrs)',
      ...Object.fromEntries(selected.map(p => [p.name, p.expected_lifetime_years]))
    },
    {
      metric: 'Volume (cc)',
      ...Object.fromEntries(selected.map(p => [p.name, p.volume_cc]))
    },
    {
      metric: 'Weight (g)',
      ...Object.fromEntries(selected.map(p => [p.name, p.weight_grams]))
    }
  ], [selected]);

  // Radar chart data (normalized 0-100)
  const radarData = useMemo(() => {
    const maxValues = {
      capacity: Math.max(...PROTOTYPE_LIBRARY.map(p => p.energy_capacity_mah)),
      lifetime: Math.max(...PROTOTYPE_LIBRARY.map(p => p.expected_lifetime_years)),
      voltage: Math.max(...PROTOTYPE_LIBRARY.map(p => p.nominal_voltage)),
      efficiency: 100,
      miniaturization: Math.max(...PROTOTYPE_LIBRARY.map(p => 1 / p.volume_cc))
    };

    return [
      { attribute: 'Capacity', fullMark: 100, ...Object.fromEntries(selected.map(p => [p.name, (p.energy_capacity_mah / maxValues.capacity) * 100])) },
      { attribute: 'Lifetime', fullMark: 100, ...Object.fromEntries(selected.map(p => [p.name, (p.expected_lifetime_years / maxValues.lifetime) * 100])) },
      { attribute: 'Voltage', fullMark: 100, ...Object.fromEntries(selected.map(p => [p.name, (p.nominal_voltage / maxValues.voltage) * 100])) },
      { attribute: 'Features', fullMark: 100, ...Object.fromEntries(selected.map(p => [p.name, ((p.energy_harvesting_enabled ? 30 : 0) + (p.supercapacitor_enabled ? 30 : 0) + (p.mri_conditional ? 20 : 0) + (p.rechargeable ? 20 : 0))])) },
      { attribute: 'Compact', fullMark: 100, ...Object.fromEntries(selected.map(p => [p.name, ((1 / p.volume_cc) / maxValues.miniaturization) * 100])) }
    ];
  }, [selected]);

  const colors = ['#14B8A6', '#8B5CF6', '#F59E0B', '#EC4899', '#3B82F6', '#6B7280'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800/50 bg-slate-900/30 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to={createPageUrl('Dashboard')}>
                <div className="relative">
                  <div className="absolute inset-0 bg-teal-500 blur-xl opacity-30" />
                  <Heart className="w-8 h-8 text-teal-400 relative" />
                </div>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight">Prototype Comparison</h1>
                <p className="text-xs text-slate-500">Compare device specifications side-by-side</p>
              </div>
            </div>
            
            <Link to={createPageUrl('Dashboard')}>
              <Button variant="outline" className="border-slate-700 text-slate-300 hover:bg-slate-800">
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Prototype Selector */}
          <div className="lg:col-span-3">
            <Card className="bg-slate-900/50 border-slate-700/50 sticky top-24">
              <CardHeader className="pb-3">
                <CardTitle className="text-slate-200 text-sm flex items-center gap-2">
                  <GitCompare className="w-4 h-4 text-teal-400" />
                  Select Prototypes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                  <div className="space-y-2">
                    {PROTOTYPE_LIBRARY.map((prototype) => (
                      <div
                        key={prototype.id}
                        className={`p-3 rounded-lg border transition-all cursor-pointer ${
                          selectedPrototypes.includes(prototype.id)
                            ? 'bg-slate-800/70 border-teal-500/50'
                            : 'bg-slate-800/30 border-slate-700/50 hover:border-slate-600'
                        }`}
                        onClick={() => togglePrototype(prototype.id)}
                      >
                        <div className="flex items-center gap-3">
                          <Checkbox
                            checked={selectedPrototypes.includes(prototype.id)}
                            onCheckedChange={() => togglePrototype(prototype.id)}
                          />
                          <div 
                            className="w-2 h-2 rounded-full" 
                            style={{ backgroundColor: prototype.color }}
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-slate-200 font-medium truncate">
                              {prototype.name}
                            </p>
                            <p className="text-xs text-slate-500">{prototype.manufacturer}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                <p className="text-xs text-slate-500 mt-3">
                  {selectedPrototypes.length} of {PROTOTYPE_LIBRARY.length} selected
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Comparison Content */}
          <div className="lg:col-span-9 space-y-6">
            {/* Bar Chart Comparison */}
            <Card className="bg-slate-900/50 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-slate-200 text-sm">Key Metrics Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={comparisonData} layout="vertical" margin={{ left: 80 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis type="number" stroke="#64748B" fontSize={10} />
                      <YAxis dataKey="metric" type="category" stroke="#64748B" fontSize={10} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1E293B',
                          border: '1px solid #334155',
                          borderRadius: '8px'
                        }}
                      />
                      <Legend />
                      {selected.map((p, idx) => (
                        <Bar
                          key={p.id}
                          dataKey={p.name}
                          fill={colors[idx % colors.length]}
                          radius={[0, 4, 4, 0]}
                        />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Radar Chart */}
            <Card className="bg-slate-900/50 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-slate-200 text-sm">Performance Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData}>
                      <PolarGrid stroke="#334155" />
                      <PolarAngleAxis dataKey="attribute" stroke="#64748B" fontSize={10} />
                      <PolarRadiusAxis stroke="#334155" fontSize={8} />
                      {selected.map((p, idx) => (
                        <Radar
                          key={p.id}
                          name={p.name}
                          dataKey={p.name}
                          stroke={colors[idx % colors.length]}
                          fill={colors[idx % colors.length]}
                          fillOpacity={0.2}
                        />
                      ))}
                      <Legend />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Detailed Comparison Table */}
            <Card className="bg-slate-900/50 border-slate-700/50">
              <CardHeader>
                <CardTitle className="text-slate-200 text-sm">Detailed Specifications</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 text-slate-400 font-medium">Specification</th>
                        {selected.map(p => (
                          <th key={p.id} className="text-center py-3 px-4 font-medium" style={{ color: p.color }}>
                            {p.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { label: 'Battery Chemistry', key: 'battery_chemistry' },
                        { label: 'Energy Capacity', key: 'energy_capacity_mah', suffix: ' mAh' },
                        { label: 'Nominal Voltage', key: 'nominal_voltage', suffix: 'V' },
                        { label: 'Internal Resistance', key: 'internal_resistance_ohms', suffix: 'Ω' },
                        { label: 'Volume', key: 'volume_cc', suffix: ' cc' },
                        { label: 'Weight', key: 'weight_grams', suffix: 'g' },
                        { label: 'Expected Lifetime', key: 'expected_lifetime_years', suffix: ' years' },
                        { label: 'Model Type', key: 'model_type' },
                        { label: 'Thermal Dissipation', key: 'thermal_dissipation_mw', suffix: ' mW' },
                        { label: 'Max Pacing Rate', key: 'max_pacing_rate_bpm', suffix: ' BPM' }
                      ].map((spec, idx) => (
                        <tr key={spec.key} className={idx % 2 === 0 ? 'bg-slate-800/20' : ''}>
                          <td className="py-2 px-4 text-slate-400">{spec.label}</td>
                          {selected.map(p => (
                            <td key={p.id} className="text-center py-2 px-4 text-slate-200">
                              {p[spec.key]}{spec.suffix || ''}
                            </td>
                          ))}
                        </tr>
                      ))}
                      
                      <tr className="border-t border-slate-700">
                        <td colSpan={selected.length + 1} className="py-2 px-4 text-slate-500 font-medium">
                          Features
                        </td>
                      </tr>
                      
                      {[
                        { label: 'Energy Harvesting', key: 'energy_harvesting_enabled' },
                        { label: 'Supercapacitor', key: 'supercapacitor_enabled' },
                        { label: 'Rechargeable', key: 'rechargeable' },
                        { label: 'MRI Conditional', key: 'mri_conditional' }
                      ].map((feature, idx) => (
                        <tr key={feature.key} className={idx % 2 === 0 ? 'bg-slate-800/20' : ''}>
                          <td className="py-2 px-4 text-slate-400">{feature.label}</td>
                          {selected.map(p => (
                            <td key={p.id} className="text-center py-2 px-4">
                              {p[feature.key] ? (
                                <CheckCircle className="w-4 h-4 text-green-400 mx-auto" />
                              ) : (
                                <XCircle className="w-4 h-4 text-slate-600 mx-auto" />
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}