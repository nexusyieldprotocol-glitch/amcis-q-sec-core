# AMCIS SoulCircuit: Digital Twin & Pacemaker Simulation Harness
**High-Fidelity MedTech Cybersecurity Validation Engine**

## Overview
SoulCircuit is the premier simulation environment for the AMCIS Bio-Identity portfolio. It provides a deterministic "Digital Twin" of critical medical devices—specifically the KIMI PI-1 Pacemaker. This harness allows for high-integrity security validation, adversarial simulation, and behavioral baseline generation without risking live patient equipment.

## Core Value
- **Deterministic Validation:** Matches real-time device telemetry against virtualized "Golden Child" states to detect unauthorized parameter changes.
- **Adversarial Stress Testing:** Built-in scenarios for battery drain attacks, overdrive suppression, and cryptographic replay detection.
- **KIMI-Class Telemetry:** Supports the full PI-1 medical telemetry specification (BPM, Lead Impedance, Lithium-Iodine Voltage models).
- **Audit-Ready Evidence:** Generates cryptographically signed evidence for FDA and HIPAA cybersecurity compliance.

## Technical Architecture
- **Simulator Implementation:** Python-based deterministic engine (`KIMI_DigitalTwin_Simulator.py`).
- **Frontend Dashboard:** Vite/Tailwind-based visualization portal for real-time telemetry monitoring.
- **Inference Integration:** Direct link to the AMCIS 8.0 Master Core for real-time anomaly inference.

## Getting Started
1. **Simulator Setup:** 
   ```bash
   cd simulator
   python KIMI_DigitalTwin_Simulator.py --mode monitor --patient PATIENT-ALPHA
   ```
2. **Dashboard Setup:**
   ```bash
   cd apps/web
   npm install
   npm run dev
   ```

## License
Proprietary Intellectual Property - NexusYield Protocol / John Julias. Refer to the included `LICENSE` file for terms.

---
*Certified for AMCIS 8.0 Ecosystem Integration*
