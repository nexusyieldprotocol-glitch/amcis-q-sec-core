import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get all enabled alert configurations
    const configs = await base44.asServiceRole.entities.AlertConfiguration.filter({ enabled: true });
    
    // Get all devices
    const devices = await base44.asServiceRole.entities.DeviceRegistry.list('-updated_date', 500);
    
    // Get latest snapshots for each device
    const snapshots = await base44.asServiceRole.entities.LongevitySnapshot.list('-snapshot_date', 1000);
    
    const triggeredAlerts = [];
    const now = new Date();

    for (const config of configs) {
      for (const device of devices) {
        // Apply device filter if configured
        if (config.device_filter) {
          if (config.device_filter.manufacturer && device.manufacturer !== config.device_filter.manufacturer) continue;
          if (config.device_filter.status && device.status !== config.device_filter.status) continue;
          if (config.device_filter.cohort_name && device.cohort_name !== config.device_filter.cohort_name) continue;
        }

        const latestSnapshot = snapshots
          .filter(s => s.device_registry_id === device.id)
          .sort((a, b) => new Date(b.snapshot_date) - new Date(a.snapshot_date))[0];

        if (!latestSnapshot) continue;

        // Get metric value
        let metricValue;
        switch (config.metric_type) {
          case 'battery_voltage':
            metricValue = latestSnapshot.battery_voltage_v;
            break;
          case 'risk_score':
            metricValue = latestSnapshot.risk_score;
            break;
          case 'rul_days':
            metricValue = latestSnapshot.predicted_rul_days;
            break;
          case 'battery_impedance':
            metricValue = latestSnapshot.battery_impedance_ohms;
            break;
          case 'lead_impedance':
            metricValue = latestSnapshot.lead_impedance_ohms;
            break;
          default:
            continue;
        }

        if (metricValue === undefined || metricValue === null) continue;

        // Check threshold
        let breached = false;
        if (config.threshold_operator === 'less_than' && metricValue < config.threshold_value) {
          breached = true;
        } else if (config.threshold_operator === 'greater_than' && metricValue > config.threshold_value) {
          breached = true;
        } else if (config.threshold_operator === 'equals' && metricValue === config.threshold_value) {
          breached = true;
        }

        if (!breached) continue;

        // Check for recent alerts (cooldown)
        const recentAlerts = await base44.asServiceRole.entities.Alert.filter({
          device_registry_id: device.id,
          alert_config_id: config.id,
          acknowledged: false
        });

        const cooldownMs = (config.cooldown_minutes || 60) * 60 * 1000;
        const hasRecentAlert = recentAlerts.some(alert => {
          const alertTime = new Date(alert.triggered_at);
          return (now - alertTime) < cooldownMs;
        });

        if (hasRecentAlert) continue;

        // Create alert
        const alertMessage = `${config.name}: ${config.metric_type.replace(/_/g, ' ')} is ${metricValue.toFixed(2)} (threshold: ${config.threshold_operator.replace(/_/g, ' ')} ${config.threshold_value})`;
        
        const alert = await base44.asServiceRole.entities.Alert.create({
          device_registry_id: device.id,
          alert_config_id: config.id,
          severity: config.severity,
          metric_type: config.metric_type,
          metric_value: metricValue,
          threshold_value: config.threshold_value,
          message: alertMessage,
          triggered_at: now.toISOString(),
          device_snapshot: {
            device_id: device.device_id,
            patient_id: device.patient_id,
            manufacturer: device.manufacturer,
            model: device.model,
            status: device.status
          }
        });

        // Send notifications
        if (config.notification_channels?.includes('email') && config.recipient_emails?.length > 0) {
          for (const email of config.recipient_emails) {
            try {
              await base44.asServiceRole.integrations.Core.SendEmail({
                to: email,
                subject: `[${config.severity.toUpperCase()}] Device Alert: ${device.device_id}`,
                body: `
Alert Triggered: ${alertMessage}

Device: ${device.device_id}
Patient: ${device.patient_id || 'N/A'}
Manufacturer: ${device.manufacturer}
Model: ${device.model}
Status: ${device.status}

Current Value: ${metricValue.toFixed(2)}
Threshold: ${config.threshold_operator.replace(/_/g, ' ')} ${config.threshold_value}
Severity: ${config.severity}

Please review this alert in the system dashboard.
                `.trim()
              });
            } catch (emailError) {
              console.error('Failed to send email:', emailError);
            }
          }

          await base44.asServiceRole.entities.Alert.update(alert.id, {
            notification_sent: true
          });
        }

        triggeredAlerts.push(alert);
      }
    }

    return Response.json({
      success: true,
      alerts_triggered: triggeredAlerts.length,
      alerts: triggeredAlerts
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});