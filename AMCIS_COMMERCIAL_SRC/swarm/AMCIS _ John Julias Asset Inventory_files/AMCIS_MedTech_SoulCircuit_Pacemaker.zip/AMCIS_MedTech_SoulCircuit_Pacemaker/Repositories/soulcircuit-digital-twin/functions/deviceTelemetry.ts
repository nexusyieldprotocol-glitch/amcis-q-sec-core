import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

/**
 * Soul Circuit - Device Telemetry Ingestion Endpoint
 * Real-time device data stream handler for registry & longevity tracking
 * 
 * Endpoint for future device telemetry integration
 * POST payload: { device_id, voltage, impedance, pacing_data, ... }
 */

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Authenticate request
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    // Parse telemetry payload
    const payload = await req.json();
    const {
      device_id,
      battery_voltage_v,
      battery_impedance_ohms,
      lead_impedance_ohms,
      pacing_threshold_v,
      pacing_burden_percent,
      timestamp
    } = payload;
    
    // Validate required fields
    if (!device_id || !battery_voltage_v) {
      return Response.json({ 
        error: 'Missing required fields: device_id, battery_voltage_v' 
      }, { status: 400 });
    }
    
    // Fetch device registry record
    const registryRecords = await base44.entities.DeviceRegistry.filter({ 
      device_id: device_id 
    });
    
    if (registryRecords.length === 0) {
      return Response.json({ 
        error: 'Device not found in registry' 
      }, { status: 404 });
    }
    
    const device = registryRecords[0];
    
    // Calculate days since implant
    const implantDate = new Date(device.implant_date);
    const currentDate = timestamp ? new Date(timestamp) : new Date();
    const daysSinceImplant = Math.floor((currentDate - implantDate) / (1000 * 60 * 60 * 24));
    
    // RUL prediction (simplified - use LongevityModel in production)
    const voltageRatio = battery_voltage_v / (device.nominal_voltage || 2.8);
    const estimatedSOC = Math.max(0, Math.min(1, (voltageRatio - 0.7) / 0.3));
    
    // Simple RUL estimation
    const baseLifetimeYears = device.expected_lifetime_years || 12;
    const rulYears = Math.max(0, (baseLifetimeYears - (daysSinceImplant / 365)) * estimatedSOC);
    const rulDays = Math.round(rulYears * 365);
    
    // Calculate risk score
    let riskScore = 0;
    const anomalyFlags = [];
    
    if (battery_voltage_v < 2.5) {
      riskScore += 30;
      anomalyFlags.push('low_voltage');
    }
    
    if (battery_impedance_ohms && battery_impedance_ohms > 150) {
      riskScore += 25;
      anomalyFlags.push('high_battery_impedance');
    }
    
    if (lead_impedance_ohms && (lead_impedance_ohms > 1200 || lead_impedance_ohms < 200)) {
      riskScore += 20;
      anomalyFlags.push('abnormal_lead_impedance');
    }
    
    if (pacing_threshold_v && pacing_threshold_v > 2.5) {
      riskScore += 15;
      anomalyFlags.push('elevated_pacing_threshold');
    }
    
    // Create longevity snapshot
    const snapshot = await base44.asServiceRole.entities.LongevitySnapshot.create({
      device_registry_id: device.id,
      snapshot_date: currentDate.toISOString(),
      days_since_implant: daysSinceImplant,
      battery_voltage_v: battery_voltage_v,
      battery_impedance_ohms: battery_impedance_ohms || null,
      pacing_threshold_v: pacing_threshold_v || null,
      lead_impedance_ohms: lead_impedance_ohms || null,
      cumulative_pacing_burden_percent: pacing_burden_percent || null,
      estimated_capacity_remaining_mah: device.initial_capacity_mah * estimatedSOC,
      predicted_rul_days: rulDays,
      predicted_eol_date: new Date(currentDate.getTime() + rulDays * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      risk_score: Math.min(100, riskScore),
      anomaly_flags: anomalyFlags
    });
    
    // Update device registry status if needed
    if (riskScore > 70 && device.status === 'active') {
      await base44.asServiceRole.entities.DeviceRegistry.update(device.id, {
        status: 'eri'
      });
    }
    
    return Response.json({
      success: true,
      snapshot_id: snapshot.id,
      rul_days: rulDays,
      risk_score: riskScore,
      anomaly_flags: anomalyFlags,
      message: 'Telemetry processed successfully'
    });
    
  } catch (error) {
    console.error('Telemetry processing error:', error);
    return Response.json({ 
      error: 'Internal server error', 
      details: error.message 
    }, { status: 500 });
  }
});